from pathlib import Path
from statistics import median
import subprocess
o=Path(__file__).resolve().parent
p=o/'recovered'
exe=p/'paired/target/release/control_pairs'
out=['| Workload | Historical µs | Recovered µs | Median paired change |','|---|---:|---:|---:|']
for case,cols,back in [('grid',s,b) for s in (12,97,257) for b in (True,False)]+[('free-center',0,False),('free-start',0,False)]:
 pairs=[]
 for labs in [('historical','recovered'),('recovered','historical')]:
  result=subprocess.check_output(['taskset','-c','6',exe,case,str(cols),str(int(back)),*labs],text=True)
  pair=[list(map(float,line.split())) for line in result.splitlines()]
  assert len(pair)==30
  pairs.extend(pair if labs[0]=='historical' else [v[::-1] for v in pair])
 label=f'grid {cols} columns backfill={str(back).lower()}' if case=='grid' else case.replace('-',' ')
 (p/f'control-paired-{case}-{cols}-{back}.tsv').write_text('\n'.join(f'{x}\t{y}' for x,y in pairs)+'\n')
 x,y=[median(v)/1000 for v in zip(*pairs)];ratio=median(b/a for a,b in pairs)
 out.append(f'| {label} | {x:.3f} | {y:.3f} | {(ratio-1)*100:+.1f}% |')
 print(out[-1],flush=True)
(p/'control-paired.md').write_text('\n'.join(out)+'\n')
