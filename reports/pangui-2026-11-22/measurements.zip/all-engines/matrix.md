# Full PanGUI engine comparison

The run completed all 162 supported entries. It covers all 13 shared workloads and all 11 peer configurations, including both Taffy versions. Three Keru rows distinguish the final checkout, the saved pre-structural workspace build, and the published crates.io version 0.1.0. Current Keru had the lowest mean among peer configurations on 13 workloads. Its equal-weight geometric mean layout time changed by -30.6% against the saved pre-structural solver on all 13 workloads and -64.5% against published 0.1.0 on the 10 it supports.

## Current Keru against the fastest peer

Each value is Criterion’s arithmetic mean time for one full solve in milliseconds. The rank compares current Keru with the peer adapters supporting that workload. The two historical Keru rows are excluded from the rank. Close point estimates can vary between runs.

| Workload | Current ms | Pre-structural ms | Published ms | Fastest peer | Peer ms | Rank |
|---|---:|---:|---:|---|---:|---:|
| expand_with_max_constraint | 0.1568 | 0.2276 | 0.3062 | Torin | 0.2642 | 1/12 |
| expand_with_min_constraint | 0.1498 | 0.2244 | 0.3064 | Torin | 0.2862 | 1/12 |
| fit_nesting | 5.5722 | 8.0504 | 14.4656 | Cephal | 13.2275 | 1/12 |
| flex_expand_equal_weights | 0.4398 | 1.3814 | 1.4620 | Torin | 1.3551 | 1/12 |
| flex_expand_weights | 0.4569 | 0.9646 | 1.3059 | Torin | 1.5465 | 1/10 |
| nested_vertical_stack | 0.2054 | 0.5067 | 0.8840 | Torin | 0.5672 | 1/12 |
| padding_and_margin | 0.0044 | 0.0066 | — | Torin | 0.0064 | 1/8 |
| percentage_and_ratio | 0.2437 | 0.6700 | 0.8858 | Morphorm | 0.9876 | 1/9 |
| perpendicular_expand_with_wrap | 0.8206 | 0.8120 | — | Torin | 1.1496 | 1/10 |
| pixels_with_min_expand_constraint | 2.7610 | 2.3012 | 3.4273 | Torin | 4.3821 | 1/9 |
| wide_no_wrap_simple_few | 0.0132 | 0.0114 | 0.0656 | Torin | 0.0479 | 1/12 |
| wide_no_wrap_simple_many | 2.8180 | 2.3555 | 9.2967 | Morphorm | 9.1283 | 1/11 |
| wide_wrapping | 0.6234 | 0.5710 | — | Morphorm | 0.8139 | 1/10 |

## Sizing and constraints

Arithmetic mean times in milliseconds. A dash marks an unsupported case.

| Engine | expand with max constraint | expand with min constraint | flex expand equal weights | flex expand weights | percentage and ratio | pixels with min expand constraint |
|---|---:|---:|---:|---:|---:|---:|
| Keru current | 0.1568 | 0.1498 | 0.4398 | 0.4569 | 0.2437 | 2.7610 |
| Keru pre-structural | 0.2276 | 0.2244 | 1.3814 | 0.9646 | 0.6700 | 2.3012 |
| Keru published 0.1.0 | 0.3062 | 0.3064 | 1.4620 | 1.3059 | 0.8858 | 3.4273 |
| Backer | 0.5210 | 0.4729 | 1.9570 | — | — | — |
| Cephal | 1.0459 | 0.9688 | 1.4189 | 3.8559 | 1.7697 | 11.2425 |
| Clay | 0.5867 | 0.8967 | 3.2479 | — | 2.9922 | — |
| hooke | 1.0998 | 1.1630 | 1.7171 | 3.1218 | 1.2457 | 15.9831 |
| Morphorm | 0.8816 | 0.8315 | 1.5852 | 1.7994 | 0.9876 | 6.2846 |
| Ply | 0.6271 | 0.7570 | 6.0141 | 6.3968 | 3.6168 | — |
| Taffy 0.3 | 1.4113 | 1.5491 | 5.3939 | 9.9994 | 2.6882 | 26.4067 |
| Taffy main | 1.7268 | 2.2276 | 5.4927 | 11.3473 | 3.5654 | 33.6344 |
| Torin | 0.2642 | 0.2862 | 1.3551 | 1.5465 | — | 4.3821 |
| ui_layout | 1.8798 | 1.7139 | 9.6632 | 13.1801 | — | 36.9335 |
| Yoga | 2.3226 | 2.1592 | 11.4582 | 14.2074 | 7.5411 | 27.4942 |

## Stacks, nesting and wrapping

Arithmetic mean times in milliseconds. A dash marks an unsupported case.

| Engine | fit nesting | nested vertical stack | padding and margin | perpendicular expand with wrap | wide no wrap simple few | wide no wrap simple many | wide wrapping |
|---|---:|---:|---:|---:|---:|---:|---:|
| Keru current | 5.5722 | 0.2054 | 0.0044 | 0.8206 | 0.0132 | 2.8180 | 0.6234 |
| Keru pre-structural | 8.0504 | 0.5067 | 0.0066 | 0.8120 | 0.0114 | 2.3555 | 0.5710 |
| Keru published 0.1.0 | 14.4656 | 0.8840 | — | — | 0.0656 | 9.2967 | — |
| Backer | 16.3907 | 1.2881 | — | — | 0.1319 | 18.8029 | — |
| Cephal | 13.2275 | 1.0102 | 0.0123 | 1.3901 | 0.1004 | 15.4216 | 1.0758 |
| Clay | 26.8767 | 2.0067 | — | — | 0.1692 | 21.0014 | — |
| hooke | 23.0464 | 1.1361 | 0.0130 | 2.1157 | 0.1267 | 18.4120 | 1.2836 |
| Morphorm | 74.3019 | 0.8600 | — | 2.1752 | 0.0841 | 9.1283 | 0.8139 |
| Ply | 44.4869 | 2.3847 | — | 6.3031 | 0.1827 | — | 4.5811 |
| Taffy 0.3 | 165.7700 | 3.5894 | 0.0219 | 4.9505 | 0.1582 | 34.7379 | 3.1108 |
| Taffy main | 42.4459 | 3.3179 | 0.0237 | 5.6438 | 0.2518 | 44.5502 | 3.1627 |
| Torin | 28.3758 | 0.5672 | 0.0064 | 1.1496 | 0.0479 | 14.3328 | 0.8362 |
| ui_layout | 103.1541 | 6.3415 | 0.0463 | 9.2142 | 0.3586 | 59.2094 | 8.0754 |
| Yoga | 127.8753 | 7.1585 | 0.0710 | 87.1836 | 0.4719 | 52.5074 | 25.2783 |

## Settings and coverage

The engine matrix used the original Criterion defaults of ten flat samples, a 300 ms warm-up and a one-second measurement target. Each group ran sequentially on logical CPU 6 of a Ryzen 7 5800H using Rust 1.97.0 release builds, default x86-64 code generation and the pinned PanGUI inputs. The primary target comparison uses four 12-sample processes per build and workload, and the native Keru confirmation uses 60 paired batches. Both are recorded in the recovery report. [Recovery report](../full-solve.md)

The current and pre-structural Keru builds use identical native adapters. The published adapter supports ten cases, with its existing limits for in-flow margins and wrapping. The optional Taffy 0.3 adapter uses the same compatibility adjustments as the earlier comparison. The peer adapters retain their own layout semantics and validation rules. Clay and Ply include native element declaration and render-command generation in layout timing.

[All means and 95% confidence intervals](timings.tsv) · [Peer log](peers.log) · [Published Keru log](published.log) · [Current and pre-structural Keru log](keru.log)

The final candidate ran again after the wrapping change. The 149 unchanged peer, published, and pre-structural measurements were retained from the previous pass. [Final candidate log](latest-keru.log)
