from pathlib import Path
import csv,json,math,statistics,collections
here=Path(__file__).resolve().parent; project=here.parents[2]
last=project/'target/full-pangui/criterion/PanGUI'
peers={'Backer','Cephal','Clay','hooke','Morphorm','Ply','Taffy 0.3','Taffy main','Torin','ui_layout','Yoga'}
new='Keru current';historical='Keru pre-structural';published='Keru published 0.1.0'
full={}
cases=sorted(x.stem for x in (project/'arewelayoutyet/benchmarks/pangui').glob('*.txt'))
def obj(p): return json.loads(p.read_text())
def meta(f):
 m=obj(f); case=m['function_id'];v=m['value_str']
 assert m['full_id']==f'PanGUI/{case}/{v}'
 return case,v
original={meta(f) for f in last.glob('*/*/new/benchmark.json')}
expected={(case,v) for case,v in original if v in peers}
expected|={(case,published) for case,v in original if v=='keru_layout'}
expected|={(case,v) for case in cases for v in (new,historical)}
assert len(cases)==13 and len(expected)==162
for grp in ['peers','published','keru']:
 for f in (here/grp/'PanGUI').glob('*/*/new/benchmark.json'):
  case,v=meta(f)
  if grp=='peers': assert v in peers
  if grp=='published':
   assert v=='keru_layout';v=published
  if grp=='keru':v={'keru_layout':new,'Keru baseline':historical}[v]
  sm=obj(f.with_name('sample.json'));est=obj(f.with_name('estimates.json'))['mean']
  mu=est['point_estimate'];lo=est['confidence_interval']['lower_bound'];hi=est['confidence_interval']['upper_bound']
  it,t=sm['iters'],sm['times']
  assert est['confidence_interval']['confidence_level']==0.95
  assert sm['sampling_mode']=='Flat' and len(it)==len(t)==10 and len(set(it))==1
  assert 0<lo<=mu<=hi<math.inf and math.isclose(statistics.fmean(x/y for x,y in zip(t,it)),mu,rel_tol=1e-8)
  assert (case,v) not in full
  full[case,v]=(mu/1e6,lo/1e6,hi/1e6,int(it[0]))
assert full.keys()==expected,(expected-full.keys(),full.keys()-expected)
with (here/'timings.tsv').open('w') as fx:
 wr=csv.writer(fx,delimiter='\t',lineterminator='\n')
 wr.writerow(['workload','engine','mean_ms','mean_ci95_low_ms','mean_ci95_high_ms','samples','iterations_per_sample'])
 for (c,v),(m,l,h,n) in sorted(full.items()): wr.writerow([c,v,f'{m:.8f}',f'{l:.8f}',f'{h:.8f}',10,n])
wins=collections.Counter();ranks={}
for c in cases:
 rank=1+sum(full[c,v][0]<full[c,new][0] for v in peers if (c,v) in full)
 ranks[c]=rank;wins[rank]+=1
def rel(c,v):return full[c,new][0]/full[c,v][0]
ch=lambda r:f'{(r-1)*100:+.1f}%'
g_mean=lambda v:statistics.geometric_mean(rel(c,v) for c in cases if (c,v) in full)
md=['# Full PanGUI engine comparison','',
f'The run completed all 162 supported entries. It covers all 13 shared workloads and all 11 peer configurations, including both Taffy versions. Three Keru rows distinguish the final checkout, the saved pre-structural workspace build, and the published crates.io version 0.1.0. Current Keru had the lowest mean among peer configurations on {wins[1]} workloads. Its equal-weight geometric mean layout time changed by {ch(g_mean(historical))} against the saved pre-structural solver on all 13 workloads and {ch(g_mean(published))} against published 0.1.0 on the 10 it supports.','',
'## Current Keru against the fastest peer','',
'Each value is Criterion’s arithmetic mean time for one full solve in milliseconds. The rank compares current Keru with the peer adapters supporting that workload. The two historical Keru rows are excluded from the rank. Close point estimates can vary between runs.','',
'| Workload | Current ms | Pre-structural ms | Published ms | Fastest peer | Peer ms | Rank |','|---|---:|---:|---:|---|---:|---:|']
for c in cases:
 available=[v for v in peers if (c,v) in full]; fast=min(available,key=lambda v:full[c,v][0])
 pub=f'{full[c,published][0]:.4f}' if (c,published) in full else '—'
 md.append(f'| {c} | {full[c,new][0]:.4f} | {full[c,historical][0]:.4f} | {pub} | {fast} | {full[c,fast][0]:.4f} | {ranks[c]}/{len(available)+1} |')
for name,group in [('Sizing and constraints', [cases[i] for i in [0,1,3,4,7,9]]),('Stacks, nesting and wrapping', [cases[i] for i in [2,5,6,8,10,11,12]])]:
 md.extend(['',f'## {name}','','Arithmetic mean times in milliseconds. A dash marks an unsupported case.','',
 '| Engine | '+' | '.join(c.replace('_',' ') for c in group)+' |','|---|'+'---:|'*len(group)])
 for v in [new,historical,published,*sorted(peers,key=str.casefold)]:
  vals=[f'{full[c,v][0]:.4f}' if (c,v) in full else '—' for c in group]
  md.append('| '+v+' | '+' | '.join(vals)+' |')
md.extend(['','## Settings and coverage','',
'The engine matrix used the original Criterion defaults of ten flat samples, a 300 ms warm-up and a one-second measurement target. Each group ran sequentially on logical CPU 6 of a Ryzen 7 5800H using Rust 1.97.0 release builds, default x86-64 code generation and the pinned PanGUI inputs. The primary target comparison uses four 12-sample processes per build and workload, and the native Keru confirmation uses 60 paired batches. Both are recorded in the recovery report. [Recovery report](../full-solve.md)','',
'The current and pre-structural Keru builds use identical native adapters. The published adapter supports ten cases, with its existing limits for in-flow margins and wrapping. The optional Taffy 0.3 adapter uses the same compatibility adjustments as the earlier comparison. The peer adapters retain their own layout semantics and validation rules. Clay and Ply include native element declaration and render-command generation in layout timing.','',
'[All means and 95% confidence intervals](timings.tsv) · [Peer log](peers.log) · [Published Keru log](published.log) · [Current and pre-structural Keru log](keru.log)',''])
if (here/'latest-keru.log').is_file():
 md.extend(["The final candidate ran again after the wrapping change. The 149 unchanged peer, published, and pre-structural measurements were retained from the previous pass. [Final candidate log](latest-keru.log)",""])
(here/'matrix.md').write_text('\n'.join(md))
print(f'Validated {len(full)} measurements; ranks {dict(wins)}; geometric mean vs historical {ch(g_mean(historical))}; vs published {ch(g_mean(published))}')
