use crate::*;

#[derive(Clone, Copy)]
pub(crate) struct ParentFrame {
    rect: XyRect,
    output_origin: Xy<f32>,
    padding: Xy<[f32; 2]>,
    flipped: Xy<bool>,
    pixel_scale: Option<f32>,
}

/// The placement part of the layout. Every `TreeAdapter` gets it from the blanket impl.
pub(crate) trait Place: Solve {
    fn place_nodes<const PARTIAL: bool>(&mut self) {
        let root = self.root();
        let size = self.node_layout_data(root).size();
        let rect = Xy::new([0.0, size.x], [0.0, size.y]);
        let pixel_scale = self.layout_data().pixel_scale;
        #[cfg(feature = "incremental")]
        { self.layout_data().placement_scale_changed = false; }
        self.place::<PARTIAL>(root, rect, Xy::new_symm(0.0), pixel_scale);
    }

    /// Writes a node's final rect. Sibling loops can inline leaf writes without
    /// entering the recursive child traversal's stack frame.
    #[inline(always)]
    fn place<const PARTIAL: bool>(&mut self, i: Self::NodeId, rect: XyRect, parent_origin: Xy<f32>, pixel_scale: Option<f32>) {
        #[cfg(feature = "incremental")]
        if PARTIAL {
            match self.node_layout_data(i).placement {
                PlacementWork::Clean => return,
                PlacementWork::Subtree => return self.place::<false>(i, rect, parent_origin, pixel_scale),
                PlacementWork::Descendants => {
                    self.node_layout_data_mut(i).placement = PlacementWork::Clean;
                    // This frame is unchanged. Its unrounded edges still position the
                    // affected children, and its snapped origin defines their local output.
                    if let Some(first) = self.first_child(i) {
                        let output = pixel_scale.map_or(rect, |scale| snap_rect(rect, scale));
                        self.place_children::<true>(i, first, rect, Xy::new(output.x[0], output.y[0]), pixel_scale);
                    }
                    return;
                }
            }
        }
        #[cfg(feature = "incremental")]
        if self.node_layout_data(i).placement != PlacementWork::Clean {
            self.node_layout_data_mut(i).placement = PlacementWork::Clean;
        }
        let output = pixel_scale.map_or(rect, |scale| snap_rect(rect, scale));
        let local_rect = Xy::new(
            [output.x[0] - parent_origin.x, output.x[1] - parent_origin.x],
            [output.y[0] - parent_origin.y, output.y[1] - parent_origin.y],
        );
        self.write_output_rect(i, output, local_rect);
        if let Some(first) = self.first_child(i) {
            self.place_children::<PARTIAL>(i, first, rect, Xy::new(output.x[0], output.y[0]), pixel_scale);
        }
    }

    fn place_children<const PARTIAL: bool>(&mut self, i: Self::NodeId, first: Self::NodeId, rect: XyRect, output_origin: Xy<f32>, pixel_scale: Option<f32>) {
        let first = Some(first);
        let (layout, frame) = self.parent_frame(i, rect, output_origin, pixel_scale);
        match layout {
            ChildrenLayout::Free => self.place_children_free::<PARTIAL>(first, &frame),
            ChildrenLayout::Stack { arrange, axis, spacing } => self.place_children_stack::<PARTIAL>(first, &frame, axis, arrange, spacing),
            ChildrenLayout::Wrap { arrange, axis, spacing, line_spacing } => {
                self.place_children_wrap::<PARTIAL>(first, &frame, axis, arrange, spacing, line_spacing);
            }
            ChildrenLayout::Block => self.place_children_block::<PARTIAL>(i, first, &frame),
            ChildrenLayout::Grid { spacing_x, spacing_y, .. } => self.place_children_grid::<PARTIAL>(i, first, &frame, spacing_x, spacing_y),
        }
    }

    /// Places a freely placed node and its subtree, inside the rect of its parent. It panics if the node is not freely placed.
    fn place_free_node(&mut self, node: Self::NodeId, parent_rect: XyRect) {
        if self.node_layout_params(node).disabled {
            return;
        }
        let parent = self.parent(node).expect("place_free_placed_subtree called on the root, which is not freely placed");
        let is_free = self.node_layout_params(node).free_placement || self.node_layout_params(parent).children_layout == ChildrenLayout::Free;
        assert!(is_free, "place_free_placed_subtree called on {node:?}, which is not freely placed");
        let pixel_scale = self.layout_data().pixel_scale;
        let mut parent_origin = Xy::new(parent_rect.x[0], parent_rect.y[0]);
        if let Some(scale) = pixel_scale {
            parent_origin = Xy::new(snap_edge(parent_origin.x, scale), snap_edge(parent_origin.y, scale));
        }
        let (_, frame) = self.parent_frame(parent, parent_rect, parent_origin, pixel_scale);
        self.place_child_free::<false>(node, &frame, self.node_layout_data(node).size());
        #[cfg(feature = "incremental")]
        self.node_layout_data_mut(node).mark_placement_changed();
    }

    /// Place an appended leaf when the preceding stack items retain their sizes and
    /// positions. Both cached rectangles must be unrounded. The previous item, if
    /// present, is the last enabled, in-flow sibling.
    #[cfg(feature = "incremental")]
    fn place_appended_stack_leaf(&mut self, parent: Self::NodeId, child: Self::NodeId, parent_rect: XyRect,
        previous: Option<(Self::NodeId, XyRect)>) -> bool
    {
        if self.layout_data().pixel_scale.is_some() || self.first_child(child).is_some() { return false; }
        let origin = Xy::new(parent_rect.x[0], parent_rect.y[0]);
        let (layout, frame) = self.parent_frame(parent, parent_rect, origin, None);
        let ChildrenLayout::Stack { axis, arrange: Arrange::Start, spacing } = layout else { return false };
        let params = self.node_layout_params(child);
        if frame.flipped[axis] || params.disabled || params.free_placement { return false; }

        let range = inner_range(&frame, axis);
        let mut cursor = if let Some((sibling, rect)) = previous {
            let sibling_params = self.node_layout_params(sibling);
            if sibling_params.disabled || sibling_params.free_placement { return false; }
            // Match place_in_line's addition order. Adding the gap to the cached
            // trailing edge would round at a different step for fractional sizes.
            let trailing = sibling_params.margin[axis][1].pixels();
            cursor_after_item(rect[axis][0], self.node_layout_data(sibling).size()[axis], trailing, spacing)
        } else {
            range[0]
        };
        let size = self.node_layout_data(child).size();
        let rect = self.stack_item_rect(&frame, params, size, axis, &mut cursor, spacing);
        self.place::<false>(child, rect, origin, None);
        true
    }

    #[inline(always)]
    fn parent_frame(&self, i: Self::NodeId, rect: XyRect, output_origin: Xy<f32>, pixel_scale: Option<f32>) -> (ChildrenLayout, ParentFrame) {
        let params = self.node_layout_params(i);
        (params.children_layout, ParentFrame {
            rect,
            output_origin,
            padding: params.padding,
            flipped: params.children_origin_flipped,
            pixel_scale,
        })
    }

    fn place_children_stack<const PARTIAL: bool>(&mut self, first: Option<Self::NodeId>, frame: &ParentFrame, axis: Axis, arrange: Arrange, spacing: f32) {
        let (main, cross) = (axis, axis.other());

        // On the main axis, totally ignore the children's chosen Position's and place them according to our own Stack::Arrange value.

        let range = inner_range(frame, main);
        let cross_start = inner_range(frame, cross)[0];
        let forward = !frame.flipped.x && !frame.flipped.y;
        let (total_size, n) = if arrange == Arrange::Start {
            (0.0, 0)
        } else {
            let mut n: u32 = 0;
            let mut children_size = 0.0;
            for_each_layout_child!(@from self, first, child, {
                if ! self.node_layout_params(child).free_placement {
                    let [start, end] = margins(self.node_layout_params(child), main);
                    children_size += with_margin(self.node_layout_data(child).size()[main], start + end);
                    n += 1;
                }
            });
            let total = if n > 0 { children_size + spacing * (n - 1) as f32 } else { children_size };
            (total, n)
        };
        let (mut walking_position, gap) = line_start_and_gap(arrange, range, total_size, n, spacing);

        for_each_layout_child!(@from self, first, child, {
            let child_size = self.node_layout_data(child).size();
            let params = self.node_layout_params(child);
            if params.free_placement {
                self.place_child_free::<PARTIAL>(child, frame, child_size);
            } else {
                let child_rect = if params.margin == Xy::new_symm([Margin::ZERO; 2]) && forward && params.position[cross] == Pos::Start {
                    let origin = match main {
                        X => Xy::new(walking_position, cross_start),
                        Y => Xy::new(cross_start, walking_position),
                    };
                    walking_position += child_size[main] + gap;
                    Xy::new([origin.x, origin.x + child_size.x], [origin.y, origin.y + child_size.y])
                } else {
                    self.stack_item_rect(frame, params, child_size, main, &mut walking_position, gap)
                };
                self.place::<PARTIAL>(child, child_rect, frame.output_origin, frame.pixel_scale);
            }
        });
    }

    #[inline(always)]
    fn stack_item_rect(&self, frame: &ParentFrame, params: &LayoutParams, size: Xy<f32>, main: Axis, cursor: &mut f32, gap: f32) -> XyRect {
        let cross = main.other();
        let mut rect = Xy::new_symm([0.0; 2]);
        rect[cross] = self.resolve_pos_on_axis(frame, params, cross, size[cross], margins(params, cross));
        rect[main] = place_in_line(frame, main, inner_range(frame, main), cursor, size[main], margins(params, main), gap);
        rect
    }

    fn place_children_wrap<const PARTIAL: bool>(&mut self, mut next: Option<Self::NodeId>, frame: &ParentFrame, axis: Axis, arrange: Arrange, spacing: f32, line_spacing: f32) {
        let cross = axis.other();
        let main_range = inner_range(frame, axis);
        let cross_range = inner_range(frame, cross);
        let mut cross_position = cross_range[0];
        while next.is_some() {
            let line = self.wrap_line(next, axis, None, spacing);
            let (mut main_position, gap) = line_start_and_gap(arrange, main_range, line.main, line.count, spacing);
            let mut line_frame = *frame;
            line_frame.rect[cross] = place_in_line(frame, cross, cross_range, &mut cross_position, line.cross, [0.0; 2], line_spacing);
            line_frame.padding[cross] = [0.0; 2];
            while next != line.next {
                let child = next.unwrap();
                next = self.next_sibling(child);
                let params = self.node_layout_params(child);
                if params.disabled {
                    continue;
                }
                let size = self.node_layout_data(child).size();
                if params.free_placement {
                    self.place_child_free::<PARTIAL>(child, frame, size);
                } else {
                    let mut rect = Xy::new_symm([0.0; 2]);
                    rect[axis] = place_in_line(frame, axis, main_range, &mut main_position, size[axis], margins(params, axis), gap);
                    rect[cross] = self.resolve_pos_on_axis(&line_frame, params, cross, size[cross], margins(params, cross));
                    self.place::<PARTIAL>(child, rect, frame.output_origin, frame.pixel_scale);
                }
            }
        }
    }

    fn place_children_block<const PARTIAL: bool>(&mut self, i: Self::NodeId, first: Option<Self::NodeId>, frame: &ParentFrame) {
        let mut flow = self.block_flow(i);
        let [left, right] = inner_range(frame, X);
        let [top, _] = inner_range(frame, Y);
        for_each_layout_child!(@from self, first, child, {
            let params = self.node_layout_params(child);
            let size = self.node_layout_data(child).size();
            if params.free_placement {
                self.place_child_free::<PARTIAL>(child, frame, size);
            } else {
                let [inline_left, inline_right] = params.margin.x;
                let spare = (right - left - size.x - inline_left.pixels() - inline_right.pixels()).max(0.0);
                let auto_count = usize::from(inline_left == Margin::AUTO) + usize::from(inline_right == Margin::AUTO);
                let leading = if frame.flipped.x { inline_right } else { inline_left };
                let leading = if leading == Margin::AUTO { spare / auto_count as f32 } else { leading.pixels() };
                let inline = if frame.flipped.x {
                    let end = right - leading;
                    [end - size.x, end]
                } else {
                    let start = left + leading;
                    [start, start + size.x]
                };
                let y = top + flow.push(self.block_item(child));
                self.place::<PARTIAL>(child, Xy::new(inline, [y, y + size.y]), frame.output_origin, frame.pixel_scale);
            }
        });
    }

    fn place_children_grid<const PARTIAL: bool>(&mut self, i: Self::NodeId, first: Option<Self::NodeId>, frame: &ParentFrame, spacing_x: f32, spacing_y: f32) {
        let lines = self.node_layout_data(i).grid_lines();

        let spacing = Xy::new(spacing_x, spacing_y);
        let size = self.node_layout_data(i).size();
        let mut cell = Xy::new(0.0, 0.0);
        for axis in [X, Y] {
            let n = lines[axis] as f32;
            let [pad_start, pad_end] = frame.padding[axis];
            cell[axis] = ((size[axis] - pad_start - pad_end - spacing[axis] * (n - 1.0)) / n.max(1.0)).max(0.0);
        }

        for_each_layout_child!(@from self, first, child, {
            let child_size = self.node_layout_data(child).size();
            let params = self.node_layout_params(child);
            if params.free_placement {
                self.place_child_free::<PARTIAL>(child, frame, child_size);
            } else {
                let child_cell = self.node_layout_data(child).grid_cell();
                let span = params.grid_span;
                // The child is positioned inside the rect of its cells, as if the cells were its parent.
                let mut cell_frame = ParentFrame { rect: Xy::new_symm([0.0; 2]), padding: Xy::new_symm([0.0; 2]), ..*frame };
                for axis in [X, Y] {
                    let span = (span[axis].max(1).min(lines[axis].max(1))) as f32;
                    let offset = child_cell[axis] as f32 * (cell[axis] + spacing[axis]);
                    let length = span * cell[axis] + (span - 1.0) * spacing[axis];
                    cell_frame.rect[axis] = if ! frame.flipped[axis] {
                        let start = frame.rect[axis][0] + frame.padding[axis][0] + offset;
                        [start, start + length]
                    } else {
                        let end = frame.rect[axis][1] - frame.padding[axis][1] - offset;
                        [end - length, end]
                    };
                }
                let mut child_rect = Xy::new([0.0, 0.0], [0.0, 0.0]);
                for axis in [X, Y] {
                    child_rect[axis] = self.resolve_pos_on_axis(&cell_frame, params, axis, child_size[axis], margins(params, axis));
                }
                self.place::<PARTIAL>(child, child_rect, frame.output_origin, frame.pixel_scale);
            }
        });
    }

    #[inline(always)]
    fn resolve_pos_on_axis(&self, frame: &ParentFrame, params: &LayoutParams, axis: Axis, child_size: f32, margin: [f32; 2]) -> [f32; 2] {
        let [inner_start, inner_end] = inner_range(frame, axis);
        let inner_start = with_margin(inner_start, margin[0]);
        let inner_end = with_margin(inner_end, -margin[1]);
        let flipped = frame.flipped[axis];

        let place_at = |reference: f32| {
            let anchor_frac = anchor_frac(params.anchor[axis]);
            if ! flipped {
                let low = reference - anchor_frac * child_size;
                [low, low + child_size]
            } else {
                let high = reference + anchor_frac * child_size;
                [high - child_size, high]
            }
        };

        let origin_edge = if ! flipped { inner_start } else { inner_end };
        let far_edge = if ! flipped { inner_end } else { inner_start };

        match params.position[axis] {
            Pos::Start => {
                if ! flipped { [origin_edge, origin_edge + child_size] } else { [origin_edge - child_size, origin_edge] }
            }
            Pos::End => {
                if ! flipped { [far_edge - child_size, far_edge] } else { [far_edge, far_edge + child_size] }
            }
            Pos::Pixels(pixels) => place_at(if ! flipped { origin_edge + pixels } else { origin_edge - pixels }),
            Pos::Frac(frac) => {
                let static_pos = frac * (inner_end - inner_start);
                place_at(if ! flipped { origin_edge + static_pos } else { origin_edge - static_pos })
            }
            Pos::Center => centered_range(inner_start, inner_end, child_size),
        }
    }

    #[inline(always)]
    fn place_child_free<const PARTIAL: bool>(&mut self, child: Self::NodeId, frame: &ParentFrame, child_size: Xy<f32>) {
        let params = self.node_layout_params(child);
        let rect = if params.position == Xy::new_symm(Pos::Center) && params.window_overflow == Xy::new_symm(WindowOverflow::Ignore) {
            // Keeping both axes together lets the compiler vectorize the centered arithmetic.
            Xy::new(
                centered_range(frame.rect.x[0] + frame.padding.x[0], frame.rect.x[1] - frame.padding.x[1], child_size.x),
                centered_range(frame.rect.y[0] + frame.padding.y[0], frame.rect.y[1] - frame.padding.y[1], child_size.y),
            )
        } else {
            let overflow = params.window_overflow;
            let anchors = params.anchor;
            let mut rect = Xy::new(
                self.resolve_pos_on_axis(frame, params, X, child_size.x, [0.0; 2]),
                self.resolve_pos_on_axis(frame, params, Y, child_size.y, [0.0; 2]),
            );
            for axis in [X, Y] {
                if overflow[axis] != WindowOverflow::Ignore {
                    let window_size = self.layout_data().window_size[axis];
                    rect[axis] = self.apply_window_overflow(window_size, overflow[axis], frame.flipped[axis], anchors[axis], rect[axis]);
                }
            }
            rect
        };
        self.place::<PARTIAL>(child, rect, frame.output_origin, frame.pixel_scale);
    }

    fn apply_window_overflow(&self, win_high: f32, behavior: WindowOverflow, flipped: bool, anchor: Anchor, rect: [f32; 2]) -> [f32; 2] {
        let win_low = 0.0;
        let [lo, hi] = rect;
        let size = hi - lo;

        // If the node is larger than the window, just give up.
        if size >= (win_high - win_low) {
            return [win_low, win_low + size];
        }

        let mut out = rect;
        if behavior == WindowOverflow::Flip {
            // The anchor point (in absolute coords) is the point that should stay fixed, e.g. the cursor.
            let anchor_frac = anchor_frac(anchor);
            let a = if ! flipped { lo + anchor_frac * size } else { hi - anchor_frac * size };

            let reflected = [2.0 * a - hi, 2.0 * a - lo];
            let should_reflect = hi > win_high && reflected[0] >= win_low || lo < win_low && reflected[1] <= win_high;
            if should_reflect {
                out = reflected;
            }
        }

        // Clamp (also the fallback when a flip wouldn't fit either).
        let [mut lo, mut hi] = out;
        let size = hi - lo;
        if hi > win_high {
            hi = win_high;
            lo = hi - size;
        }
        if lo < win_low {
            lo = win_low;
            hi = lo + size;
        }
        [lo, hi]
    }

    fn place_children_free<const PARTIAL: bool>(&mut self, first: Option<Self::NodeId>, frame: &ParentFrame) {
        for_each_layout_child!(@from self, first, child, {
            #[cfg(feature = "incremental")]
            if PARTIAL && self.node_layout_data(child).placement == PlacementWork::Clean { continue; }
            let child_size = self.node_layout_data(child).size();
            self.place_child_free::<PARTIAL>(child, frame, child_size);
        });
    }
}

impl<T: TreeAdapter + ?Sized> Place for T {}

#[inline]
fn snap_rect(rect: XyRect, scale: f32) -> XyRect {
    let [left, right, top, bottom] = [rect.x[0], rect.x[1], rect.y[0], rect.y[1]].map(|edge| snap_edge(edge, scale));
    Xy::new([left, right], [top, bottom])
}

fn snap_edge(edge: f32, scale: f32) -> f32 {
    let scale = f64::from(scale);
    let scaled = f64::from(edge) * scale;
    let rounded = if cfg!(all(target_arch = "x86_64", not(target_feature = "sse4.1"))) {
        // Baseline SSE2 has no packed round instruction. The product of two f32s has
        // at most 48 significant bits, so at 2^47 and above it is already integral.
        let magnitude = scaled.abs();
        const INTEGRAL_LIMIT: f64 = (1_u64 << 47) as f64;
        const UNIT_SPACING: f64 = (1_u64 << 52) as f64;
        // Below that limit, adding 2^52 rounds to the nearest integer. Bias upwards
        // by at most two f64 ULPs so half-integers round away from zero. The five
        // spare significand bits ensure this cannot round a non-tie across a boundary.
        let biased = magnitude * (1.0 + f64::EPSILON);
        let nearest = (biased + UNIT_SPACING) - UNIT_SPACING;
        let rounded = if magnitude < INTEGRAL_LIMIT { nearest } else { magnitude };
        rounded.copysign(scaled)
    } else {
        scaled.round()
    };
    (rounded / scale) as f32
}

#[inline]
fn inner_range(frame: &ParentFrame, axis: Axis) -> [f32; 2] {
    let [start, end] = frame.rect[axis];
    let [pad_start, pad_end] = frame.padding[axis];
    [start + pad_start, end - pad_end]
}

fn line_start_and_gap(arrange: Arrange, [start, end]: [f32; 2], total: f32, n: u32, spacing: f32) -> (f32, f32) {
    let free = ((end - start) - total).max(0.0);
    match arrange {
        Arrange::Start => (start, spacing),
        Arrange::End => (end - total, spacing),
        Arrange::Center => ((start + end) / 2.0 - total / 2.0, spacing),
        Arrange::SpaceBetween => {
            let extra = if n > 1 { free / (n - 1) as f32 } else { 0.0 };
            (start, spacing + extra)
        }
        Arrange::SpaceAround => {
            let extra = if n > 0 { free / n as f32 } else { 0.0 };
            (start + extra / 2.0, spacing + extra)
        }
        Arrange::SpaceEvenly => {
            let extra = if n > 0 { free / (n + 1) as f32 } else { 0.0 };
            (start + extra, spacing + extra)
        }
    }
}

#[inline]
fn place_in_line(frame: &ParentFrame, axis: Axis, [start, end]: [f32; 2], cursor: &mut f32, size: f32, margin: [f32; 2], gap: f32) -> [f32; 2] {
    let (leading, trailing) = if frame.flipped[axis] { (margin[1], margin[0]) } else { (margin[0], margin[1]) };
    let position = with_margin(*cursor, leading);
    *cursor = cursor_after_item(position, size, trailing, gap);
    if frame.flipped[axis] {
        let mirrored = start + end - position;
        [mirrored - size, mirrored]
    } else {
        [position, position + size]
    }
}

#[inline]
fn cursor_after_item(position: f32, size: f32, trailing_margin: f32, gap: f32) -> f32 {
    position + (with_margin(size, trailing_margin) + gap)
}

#[inline(always)]
fn centered_range(start: f32, end: f32, size: f32) -> [f32; 2] {
    let center = (start + end) / 2.0;
    [center - size / 2.0, center + size / 2.0]
}

/// The anchor point of a node, as a fraction of its size from its origin-side edge.
#[inline(always)]
fn anchor_frac(anchor: Anchor) -> f32 {
    match anchor {
        Anchor::Start => 0.0,
        Anchor::Center => 0.5,
        Anchor::End => 1.0,
        Anchor::Frac(f) => f,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use rand::{Rng, SeedableRng};

    #[test]
    fn resuming_a_stack_preserves_cursor_rounding() {
        // The first rectangle's end rounds down to its start. Its size and trailing
        // gap still advance the cursor together by one representable coordinate.
        let start = (1_u32 << 24) as f32;
        let range = [start, start + 8.0];
        let frame = ParentFrame {
            rect: Xy::new_symm(range), padding: Xy::new_symm([0.0; 2]),
            output_origin: Xy::new_symm(start), flipped: Xy::new_symm(false), pixel_scale: None,
        };
        let mut cursor = start;
        let first = place_in_line(&frame, X, range, &mut cursor, 1.0, [0.0; 2], 1.0);
        assert_eq!(first, [start; 2]);
        assert_eq!(cursor, start + 2.0);
        assert_eq!(cursor_after_item(first[0], 1.0, 0.0, 1.0), cursor);
    }

    #[test]
    fn packed_snapping_matches_scalar_rounding() {
        let check = |edges: [f32; 4], scale: f32| {
            let snapped = snap_rect(Xy::new([edges[0], edges[1]], [edges[2], edges[3]]), scale);
            let actual = [snapped.x[0], snapped.x[1], snapped.y[0], snapped.y[1]];
            for (edge, actual) in edges.into_iter().zip(actual) {
                let expected = ((f64::from(edge) * f64::from(scale)).round() / f64::from(scale)) as f32;
                if expected.is_nan() {
                    assert!(actual.is_nan());
                } else {
                    assert_eq!(actual.to_bits(), expected.to_bits(), "edge={edge}, scale={scale}");
                }
            }
        };

        for scale in [0.125, 0.75, 1.0, 1.5, 2.0, f32::MIN_POSITIVE, f32::MAX] {
            for half_pixel in [0.5, 1.5, 2.5, 127.5, 4095.5, 8_388_607.5] {
                let edge = (half_pixel / f64::from(scale)) as f32;
                check([edge.next_down(), edge, edge.next_up(), -edge], scale);
            }
            check([-0.0, f32::from_bits(1), f32::INFINITY, f32::NEG_INFINITY], scale);
            check([f32::MAX, -f32::MAX, (1_u64 << 47) as f32, f32::NAN], scale);
        }

        let mut rng = rand::rngs::StdRng::seed_from_u64(0x52_47);
        for _ in 0..10_000 {
            let scale = f32::from_bits(rng.random_range(1..=f32::MAX.to_bits()));
            check(std::array::from_fn(|_| f32::from_bits(rng.random())), scale);
        }
    }
}
