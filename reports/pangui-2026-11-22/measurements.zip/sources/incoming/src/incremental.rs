use crate::*;
use crate::Axis::{X, Y};

/// What `solve_layout_incremental` did. The `Fallback` variants give the reason for a full solve.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum IncrementalRelayoutOutcome {
    /// The relayout was incremental.
    Success {
        /// Slot computations.
        computed: u32,
    },
    /// In `solve_layout_incremental_checked()`, the incremental relayout gave a different result than the full relayout. The tree keeps the result of the full relayout. This should only be possible if a change wasn't registered with `register_node_change()`, `register_content_change()` or a structural change notification.
    CheckedIncrementalRelayoutMismatch,
    /// The incremental relayout fell back to a full relayout because the full layout was never solved before.
    FallbackNeverSolved,
    /// Legacy outcome retained for API compatibility. Structural edits use incremental measurement.
    FallbackStructuralChange,
    /// The previous solve found a cycle and this pass has no structural edits to rebuild its dependencies.
    FallbackCycle,
    /// A block or wrapping flow must rebuild its line or collapsed-margin data.
    FallbackFlow,
    /// The incremental relayout fell back to a full relayout because the changes affected a large part of the tree, and the solver estimated it would be faster to fall back to a full relayout.
    FallbackTooMuchWork,
    /// The incremental relayout fell back to a full relayout because `LayoutTree::invalidate()` was called explicitly.
    FallbackInvalidated,
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub(crate) enum StructuralChange {
    #[default]
    Clean,
    Children,
    /// This node has a new parent. Its own style and intrinsic content are unchanged.
    Moved,
    Subtree,
    /// A clean, fixed-size region skipped during the current structural measurement.
    Retained,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum PlacementWork {
    Clean,
    Descendants,
    Subtree,
}

impl NodeLayoutData {
    pub(crate) fn mark_moved(&mut self) {
        self.structural_change = match self.structural_change {
            StructuralChange::Clean => StructuralChange::Moved,
            StructuralChange::Children => StructuralChange::Subtree,
            mark => mark,
        };
    }

    pub(crate) fn mark_subtree_changed(&mut self) {
        self.structural_change = StructuralChange::Subtree;
    }

    pub(crate) fn mark_children_changed(&mut self) {
        self.structural_change = match self.structural_change {
            StructuralChange::Clean => StructuralChange::Children,
            StructuralChange::Moved => StructuralChange::Subtree,
            mark => mark,
        };
    }

    pub(crate) fn mark_placement_changed(&mut self) {
        self.placement = PlacementWork::Subtree;
    }
}

impl<I> LayoutData<I> {
    pub(crate) fn record_node_change(&mut self, i: I, old: &LayoutParams, new: &LayoutParams, node: &mut NodeLayoutData) -> bool {
        if !self.tracks_structure() { return false; }
        let change = NodeChange::between(old, new, self.tracks_sizes());
        if self.record_change(i, change) {
            node.mark_subtree_changed();
        } else {
            node.mark_placement_changed();
        }
        change.is_none()
    }

    pub(crate) fn tracks_structure(&self) -> bool {
        use IncrementalRelayoutOutcome::*;
        matches!(self.pending_full_solve, None | Some(FallbackFlow | FallbackTooMuchWork))
    }

    fn tracks_sizes(&self) -> bool {
        self.pending_full_solve.is_none()
    }

    // A queued node can be deleted before the next solve. Mark it on the live tree
    // as well, so a later structural pass can discard all queued IDs safely.
    fn record_change(&mut self, i: I, change: Option<NodeChange>) -> bool {
        match change {
            None => true,
            // While a sizing fallback is pending, between() only checks for a change
            // of rule. Retain the live mark if the batch later includes a tree edit.
            Some(_) if self.pending_full_solve.is_some() => true,
            Some(change) if change != NodeChange::default() => {
                if self.accept_sizing_change() && !self.children_changed {
                    self.node_changes.push((i, change));
                }
                true
            }
            Some(_) => false,
        }
    }

    fn record_content(&mut self, i: I) -> bool {
        if !self.tracks_structure() { return false; }
        if self.accept_sizing_change() && !self.children_changed {
            self.content_changes.push(i);
        }
        true
    }

    pub(crate) fn record_content_change(&mut self, i: I, node: &mut NodeLayoutData) {
        if self.record_content(i) { node.mark_subtree_changed(); }
    }

    pub(crate) fn start_children_change(&mut self) -> bool {
        if !self.tracks_structure() { return false; }
        // Regional measurement includes earlier sizing marks, regardless of edit order.
        self.pending_full_solve = None;
        self.children_changed = true;
        true
    }

    pub(crate) fn record_children_change(&mut self, node: &mut NodeLayoutData) {
        if self.start_children_change() {
            node.mark_children_changed();
        }
    }

    /// Check the fallback before growing a change list that the solver would discard.
    fn accept_sizing_change(&mut self) -> bool {
        if !self.tracks_sizes() || self.has_cycle {
            return false;
        }
        if self.children_changed { return true; }
        self.pending_full_solve = if self.has_flow {
            Some(IncrementalRelayoutOutcome::FallbackFlow)
        } else if self.node_changes.len() + self.content_changes.len() >= (self.n_nodes_solved / 2) as usize {
            Some(IncrementalRelayoutOutcome::FallbackTooMuchWork)
        } else {
            return true;
        };
        false
    }

    /// An explicit full solve takes priority over a fallback inferred from sizing edits.
    pub(crate) fn request_full_solve(&mut self, reason: IncrementalRelayoutOutcome) {
        if self.tracks_structure() {
            self.pending_full_solve = Some(reason);
        }
    }

    pub(crate) fn clear(&mut self) {
        self.children_changed = false;
        self.unknown_structure = false;
        self.node_changes.clear();
        self.content_changes.clear();
    }
}

/// The sizing inputs that changed. Placement reads the latest params directly.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub(crate) struct NodeChange {
    declared: u8,
    inner: Xy<bool>,
    margin: Xy<bool>,
    fill_weight: bool,
    content: bool,
}

impl NodeChange {
    /// A structural change requires rebuilding the affected dependencies.
    fn between(old: &LayoutParams, new: &LayoutParams, track_sizes: bool) -> Option<Self> {
        if is_structural(old, new) {
            return None;
        }

        let mut change = Self::default();
        if !track_sizes {
            return Some(change);
        }
        for axis in [X, Y] {
            for (kind, changed) in [
                (Kind::Regular, old.size[axis] != new.size[axis]),
                (Kind::Min, old.min_size[axis] != new.min_size[axis]),
                (Kind::Max, old.max_size[axis] != new.max_size[axis]),
            ] {
                if changed {
                    change.declared |= 1 << slot_index(axis, kind);
                }
            }
            change.inner[axis] = old.padding[axis] != new.padding[axis];
            change.margin[axis] = !new.free_placement && old.margin[axis] != new.margin[axis];
        }
        change.fill_weight = !new.free_placement && old.fill_weight != new.fill_weight;
        change.content = old.image != new.image || new.content_measure != ContentMeasure::None
            && (change.inner.x || change.inner.y || old.max_size != new.max_size);
        match (old.children_layout, new.children_layout) {
            (ChildrenLayout::Stack { spacing: a, .. }, ChildrenLayout::Stack { axis, spacing: b, .. }) if a != b => {
                change.inner[axis] = true;
            }
            (ChildrenLayout::Wrap { spacing: a, line_spacing: line_a, .. }, ChildrenLayout::Wrap { axis, spacing: b, line_spacing: line_b, .. }) => {
                change.inner[axis] |= a != b;
                change.inner[axis.other()] |= line_a != line_b;
            }
            (a @ ChildrenLayout::Grid { .. }, b @ ChildrenLayout::Grid { .. }) if a != b => {
                change.inner = Xy::new_symm(true);
            }
            _ => {}
        }
        Some(change)
    }
}

/// True if the change can change the dependencies between the slots.
fn is_structural(old: &LayoutParams, new: &LayoutParams) -> bool {
    use std::mem::discriminant;
    let same_kind = |a: Option<Size>, b: Option<Size>| a.map(|a| discriminant(&a)) == b.map(|b| discriminant(&b));
    let same_layout = match (old.children_layout, new.children_layout) {
        (ChildrenLayout::Free, ChildrenLayout::Free) => true,
        (ChildrenLayout::Block, ChildrenLayout::Block) => true,
        (ChildrenLayout::Stack { axis: a, .. }, ChildrenLayout::Stack { axis: b, .. }) => a == b,
        (ChildrenLayout::Wrap { axis: a, .. }, ChildrenLayout::Wrap { axis: b, .. }) => a == b,
        // The `Count` grid cells are assigned in `prepare`.
        (ChildrenLayout::Grid { columns: MainAxisCellSize::Count(a), main_axis: main_a, backfill: backfill_a, .. }, ChildrenLayout::Grid { columns: MainAxisCellSize::Count(b), main_axis: main_b, backfill: backfill_b, .. }) => a == b && main_a == main_b && backfill_a == backfill_b,
        (ChildrenLayout::Grid { columns: MainAxisCellSize::Width(_), main_axis: main_a, backfill: backfill_a, .. }, ChildrenLayout::Grid { columns: MainAxisCellSize::Width(_), main_axis: main_b, backfill: backfill_b, .. }) => main_a == main_b && backfill_a == backfill_b,
        _ => false,
    };
    old.disabled != new.disabled
        || old.free_placement != new.free_placement
        || old.grid_span != new.grid_span
        || old.text != new.text
        || old.content_measure != new.content_measure
        || old.image.is_some() != new.image.is_some()
        || ! same_layout
        || [X, Y].into_iter().any(|axis| {
            ! same_kind(Some(old.size[axis]), Some(new.size[axis]))
                || ! same_kind(old.min_size[axis], new.min_size[axis])
                || ! same_kind(old.max_size[axis], new.max_size[axis])
        })
}

/// Dependency levels are LIFO stacks into one shared array of entries. A zero link
/// ends a stack. Popping a slot returns its entry to the free list for any level.
#[derive(Debug, Clone)]
pub(crate) struct WorkQueue<I> {
    heads: Vec<usize>,
    entries: Vec<(Slot<I>, usize)>,
    free: usize,
    cursor: usize,
    first_level: u16,
}

impl<I> WorkQueue<I> {
    pub(crate) const fn new() -> Self {
        Self { heads: Vec::new(), entries: Vec::new(), free: 0, cursor: 0, first_level: 0 }
    }

    fn push(&mut self, level: u16, slot: Slot<I>) {
        if self.heads.is_empty() {
            self.first_level = level;
        } else if level < self.first_level {
            // Initial edits may arrive in any order. Dependents added while solving
            // always have a higher level than the slot being processed.
            debug_assert_eq!(self.cursor, 0);
            // Grow geometrically when prepending so descending edits amortize the copies.
            let missing = usize::from(self.first_level - level);
            let extra = missing.max(self.heads.len()).min(usize::from(self.first_level));
            self.heads.resize(self.heads.len() + extra, 0);
            self.heads.rotate_right(extra);
            self.first_level -= extra as u16;
        }
        let index = usize::from(level - self.first_level);
        debug_assert!(index >= self.cursor);
        if self.heads.len() <= index {
            self.heads.resize(index + 1, 0);
        }
        let head = &mut self.heads[index];
        let entry = (slot, *head);
        if self.free == 0 {
            self.entries.push(entry);
            *head = self.entries.len();
        } else {
            *head = self.free;
            self.free = std::mem::replace(&mut self.entries[self.free - 1], entry).1;
        }
    }

    fn pop(&mut self) -> Option<Slot<I>> where I: Copy {
        while let Some(head) = self.heads.get_mut(self.cursor) {
            if *head != 0 {
                let index = *head;
                let (slot, next) = &mut self.entries[index - 1];
                *head = *next;
                *next = self.free;
                self.free = index;
                return Some(*slot);
            }
            self.cursor += 1;
        }
        self.clear();
        None
    }

    fn clear(&mut self) {
        self.heads.clear();
        self.entries.clear();
        self.free = 0;
        self.cursor = 0;
    }
}

/// Disjoint subtrees to measure in document order, plus live counts for the next solve.
pub(crate) struct StructuralPlan<I> {
    regions: Vec<I>,
    retained: SubtreeCounts,
}

#[derive(Default, Clone, Copy)]
pub(crate) struct SubtreeCounts {
    pub(crate) nodes: u32,
    pub(crate) blocks: usize,
    pub(crate) has_flow: bool,
    has_cycle: bool,
}

impl SubtreeCounts {
    pub(crate) fn include(&mut self, flags: NodeFlags) {
        // A disabled node has no solved slots. An enabled node has both final sizes.
        if flags != NodeFlags::EMPTY {
            self.nodes += 1;
            self.blocks += usize::from(flags.is_block_container());
            self.has_flow |= flags.has_flow();
            self.has_cycle |= flags.has_cycle();
        }
    }
}

pub(crate) trait Incremental: Solve {
    fn measure_structure(&mut self, window_size: Xy<f32>) -> IncrementalRelayoutOutcome {
        if self.layout_data().unknown_structure {
            self.reconcile_topology();
        }
        let root = self.root();
        let old_window = std::mem::replace(&mut self.layout_data().window_size, window_size);
        if [X, Y].into_iter().any(|axis| old_window[axis] != window_size[axis]
            && DECLARED_SIZES.into_iter().any(|kind| self.read_size(root, axis, kind).is_some_and(|size| size.is_flex())))
        {
            self.node_layout_data_mut(root).mark_subtree_changed();
        }
        let mut plan = StructuralPlan {
            regions: std::mem::take(&mut self.layout_data().regions),
            retained: SubtreeCounts::default(),
        };
        self.plan_subtree(root, &mut plan);
        let data = self.layout_data();
        // Pending queues can reference removed IDs. The live nodes carried the same edits.
        data.clear();
        data.has_flow = plan.retained.has_flow;
        data.has_cycle = plan.retained.has_cycle;
        let mut computed: u32 = 0;
        for &region in &plan.regions {
            let (nodes, slots, blocks) = self.measure_subtree(region);
            self.node_layout_data_mut(region).placement = PlacementWork::Subtree;
            plan.retained.nodes += nodes;
            plan.retained.blocks += blocks;
            computed = computed.saturating_add(slots);
        }
        self.layout_data().n_nodes_solved = plan.retained.nodes;
        self.compact_block_margins(plan.retained.blocks);
        plan.regions.clear();
        self.layout_data().regions = plan.regions;
        self.remember_topology();
        IncrementalRelayoutOutcome::Success { computed }
    }

    /// Return true when this node's sizing inputs may have changed for its parent.
    /// When siblings share inputs, a single enclosing region replaces the child regions.
    fn plan_subtree(&mut self, node: Self::NodeId, plan: &mut StructuralPlan<Self::NodeId>) -> bool {
        let mark = self.node_layout_data(node).structural_change;
        if matches!(mark, StructuralChange::Moved | StructuralChange::Subtree) {
            self.node_layout_data_mut(node).placement = PlacementWork::Subtree;
            plan.regions.push(node);
            return true;
        }
        if self.node_layout_params(node).disabled {
            self.node_layout_data_mut(node).placement = PlacementWork::Clean;
            return false;
        }
        let independent = (mark == StructuralChange::Children).then(|| self.try_refresh_independent_parent(node));
        // A changed, coupled child list already requires measuring the whole region.
        // prepare() will visit and count those descendants, including any pending edits.
        if independent != Some(false) {
            let start = plan.regions.len();
            let retained = plan.retained;
            plan.retained.include(self.node_layout_data(node).flags);
            let layout = self.node_layout_params(node).children_layout;
            let mut changed_children = mark == StructuralChange::Children;
            let mut placement = if self.node_layout_data(node).placement == PlacementWork::Subtree
                || changed_children && layout != ChildrenLayout::Free
            {
                PlacementWork::Subtree
            } else {
                PlacementWork::Clean
            };
            let mut next = self.first_child(node);
            while let Some(child) = next {
                next = self.next_sibling(child);
                // Most siblings in a wide list are clean leaves. Count them in this
                // loop without entering another planner frame or writing their cache.
                let cached = self.node_layout_data(child);
                if cached.structural_change == StructuralChange::Clean && cached.placement == PlacementWork::Clean
                    && self.first_child(child).is_none()
                {
                    plan.retained.include(cached.flags);
                    continue;
                }
                let size_changed = self.plan_subtree(child, plan);
                changed_children |= size_changed;
                if size_changed && layout != ChildrenLayout::Free && !self.node_layout_params(child).free_placement {
                    placement = PlacementWork::Subtree;
                } else if placement == PlacementWork::Clean && self.node_layout_data(child).placement != PlacementWork::Clean {
                    placement = PlacementWork::Descendants;
                }
            }
            if self.node_layout_data(node).placement != placement {
                self.node_layout_data_mut(node).placement = placement;
            }
            // A descendant may have been measured while this node's cyclic slot
            // still held a provisional value. Replay the enclosing cycle if any
            // sizing region reached into it, even across a fixed-size descendant.
            let replay_cycle = self.node_layout_data(node).flags.has_cycle()
                && (changed_children || plan.regions.len() > start);
            if !changed_children && !replay_cycle { return false; }
            if !replay_cycle && independent.unwrap_or_else(|| self.try_refresh_independent_parent(node)) {
                self.node_layout_data_mut(node).structural_change = StructuralChange::Clean;
                return false;
            }
            plan.regions.truncate(start);
            plan.retained = retained;
        }
        self.node_layout_data_mut(node).placement = PlacementWork::Subtree;
        plan.regions.push(node);
        // A wrapping parent writes the main-axis share before measuring the line,
        // then reuses the same child field for the cross-axis extent.
        let in_wrap = !self.node_layout_params(node).free_placement && self.parent(node).is_some_and(|parent| {
            matches!(self.node_layout_params(parent).children_layout, ChildrenLayout::Wrap { .. })
        });
        // A parent can enter a cyclic region through a different slot than the
        // region's own traversal would. Include it when those sizes are coupled.
        self.node_layout_data(node).flags.has_cycle() || self.size_depends_on_children(node)
            || self.node_layout_data(node).flags.is_block_item() || in_wrap
    }

    // Rebuilding a block can replace a saved collapsed margin; deleting one drops
    // its owner. Bound the arena by the live block count across repeated edits.
    fn compact_block_margins(&mut self, blocks: usize) {
        let data = self.layout_data();
        if blocks == 0 {
            data.block_margins.clear();
            return;
        }
        if data.block_margins.len() <= blocks.saturating_mul(2) { return; }
        let old = std::mem::take(&mut data.block_margins);
        let mut live = std::mem::take(&mut data.margin_scratch);
        let mut next = Some(self.root());
        while let Some(node) = next {
            next = self.tree_traversal_next(node);
            if !self.node_layout_params(node).disabled
                && let Some(index) = self.node_layout_data(node).block_margin_index()
            {
                self.node_layout_data_mut(node).set_block_margin_index(live.len());
                live.push(old[index]);
            }
        }
        let data = self.layout_data();
        data.block_margins = live;
        data.margin_scratch = old;
        data.margin_scratch.clear();
    }

    fn measure_sizes_incremental(&mut self, window_size: Xy<f32>) -> IncrementalRelayoutOutcome {
        let root = self.root();
        let data = self.layout_data();
        let last_window_size = std::mem::replace(&mut data.window_size, window_size);
        if last_window_size == window_size && data.node_changes.is_empty() && data.content_changes.is_empty() {
            return IncrementalRelayoutOutcome::Success { computed: 0 };
        }
        let max_computed = data.n_nodes_solved / 2;

        // Borrow the change lists independently while queuing slots through the adapter.
        let mut changes = std::mem::take(&mut data.node_changes);
        let mut content_changes = std::mem::take(&mut data.content_changes);
        for axis in [X, Y] {
            if last_window_size[axis] != window_size[axis] {
                self.queue_declared(root, axis, |size| size.is_flex());
            }
        }
        for (i, change) in changes.drain(..) {
            self.node_layout_data_mut(i).structural_change = StructuralChange::Clean;
            self.queue_node_change(i, change);
        }
        for i in content_changes.drain(..) {
            self.node_layout_data_mut(i).structural_change = StructuralChange::Clean;
            self.queue_content_change(i);
        }
        let data = self.layout_data();
        data.node_changes = changes;
        data.content_changes = content_changes;
        self.run_queue(max_computed)
    }

    /// Records a change in the params of a node.
    fn incr_register_node_change(&mut self, i: Self::NodeId, old: &LayoutParams) {
        let data = self.layout_data();
        if data.tracks_structure() {
            let track_sizes = data.tracks_sizes();
            let change = NodeChange::between(old, self.node_layout_params(i), track_sizes);
            if self.layout_data().record_change(i, change) {
                self.node_layout_data_mut(i).mark_subtree_changed();
                if change.is_none() {
                    let parent = self.parent(i).unwrap_or(i);
                    self.incr_register_children_change(parent, Some(i));
                }
            } else if self.node_layout_params(i) != old {
                self.node_layout_data_mut(i).mark_placement_changed();
            }
        }
    }

    /// Records that the text or the image of a node changed.
    fn incr_register_content_change(&mut self, i: Self::NodeId) {
        if self.layout_data().record_content(i) {
            self.node_layout_data_mut(i).mark_subtree_changed();
        }
    }

    fn incr_register_children_change(&mut self, parent: Self::NodeId, attached: Option<Self::NodeId>) {
        if self.layout_data().start_children_change() {
            self.node_layout_data_mut(parent).mark_children_changed();
            if let Some(child) = attached {
                self.mark_attached(child);
            }
        }
    }

    /// Does an incremental relayout, or a full solve if the registered changes need one. If `verify` is true, it also does a full solve and compares the sizes.
    fn solve_incremental(&mut self, window_size: Xy<f32>, verify: bool) -> IncrementalRelayoutOutcome {
        let data = self.layout_data();
        let partial_placement = data.children_changed && data.window_size == window_size && !data.placement_scale_changed;
        let outcome = if let Some(reason) = data.pending_full_solve {
            reason
        } else if data.children_changed {
            self.measure_structure(window_size)
        } else if data.has_cycle {
            IncrementalRelayoutOutcome::FallbackCycle
        } else if data.has_flow && data.window_size != window_size {
            IncrementalRelayoutOutcome::FallbackFlow
        } else {
            self.measure_sizes_incremental(window_size)
        };
        match outcome {
            IncrementalRelayoutOutcome::Success { .. } => match verify {
                true => {
                    if ! self.run_full_solve_and_compare(window_size) {
                        return IncrementalRelayoutOutcome::CheckedIncrementalRelayoutMismatch;
                    }
                }
                false if partial_placement && self.retains_output_rects() => self.place_nodes::<true>(),
                false => self.place_nodes::<false>(),
            },
            _ => self.solve_layout(window_size),
        }
        outcome
    }

    fn run_full_solve_and_compare(&mut self, window_size: Xy<f32>) -> bool {
        let data = self.layout_data();
        let mut incremental = std::mem::take(&mut data.checked_values);
        incremental.reserve(data.n_nodes_solved as usize);
        let mut next = Some(self.root());
        while let Some(i) = next {
            incremental.push((i, self.node_layout_data(i).values.map(f32::to_bits)));
            next = self.tree_traversal_next(i);
        }
        self.solve_layout(window_size);
        let matches = incremental.iter().all(|(i, values)| self.node_layout_data(*i).values.map(f32::to_bits) == *values);
        incremental.clear();
        self.layout_data().checked_values = incremental;
        matches
    }

    /// Queues the slots affected by the sizing inputs that changed.
    fn queue_node_change(&mut self, i: Self::NodeId, change: NodeChange) {
        if self.node_layout_params(i).disabled {
            return;
        }
        for axis in [X, Y] {
            for kind in DECLARED_SIZES {
                if change.declared & (1 << slot_index(axis, kind)) != 0 {
                    self.queue(Slot { node: i, axis, kind });
                }
            }
            // A FitContent stack reads its children's fractions directly from their params.
            let params = self.node_layout_params(i);
            if change.declared & (1 << slot_index(axis, Kind::Regular)) != 0
                && matches!(params.size[axis], Size::Frac(_)) && !params.free_placement && let Some(parent) = self.parent(i)
            {
                self.queue_declared(parent, axis, |size| size == Size::FitContent);
            }
        }
        if change.inner.x || change.inner.y {
            self.queue_inner_size_readers(i, change.inner);
        }
        for axis in [X, Y] {
            if change.margin[axis] && let Some(parent) = self.parent(i)
                && self.node_layout_params(parent).children_layout != ChildrenLayout::Free
            {
                self.queue_declared(i, axis, |size| size.is_fill());
                self.queue_declared(parent, axis, |size| size == Size::FitContent);
                if self.stack_axis(parent) == Some(axis) {
                    self.queue_even_share(parent);
                }
            }
        }
        if change.fill_weight && let Some(parent) = self.parent(i) && let Some(axis) = self.stack_axis(parent) {
            self.queue_declared(i, axis, |size| size.is_fill());
            self.queue_even_share(parent);
        }
        if change.content {
            self.queue_content_change(i);
        }
    }

    fn queue_content_change(&mut self, i: Self::NodeId) {
        if self.node_layout_params(i).disabled {
            return;
        }
        for axis in [X, Y] {
            self.queue_declared(i, axis, |size| size == Size::FitContent);
        }
    }

    fn queue_inner_size_readers(&mut self, i: Self::NodeId, mut changed: Xy<bool>) {
        let grid_main = self.width_grid_main_axis(i);
        if grid_main.is_some() {
            // Changing one cell dimension can change both axes of a width grid.
            changed = Xy::new_symm(true);
        }
        for axis in [X, Y] {
            if changed[axis] {
                self.queue_declared(i, axis, |size| size == Size::FitContent);
            }
        }
        let stack_axis = self.stack_axis(i);
        for_each_layout_child!(self, i, child, {
            let free = self.node_layout_params(child).free_placement;
            for axis in [X, Y] {
                if changed[axis] {
                    let in_stack = stack_axis == Some(axis) && !free;
                    self.queue_declared(child, axis, |size| matches!(size, Size::Frac(_)) || (size.is_fill() && !in_stack));
                }
            }
        });
        if let Some(main) = grid_main {
            self.queue(Slot { node: i, axis: main, kind: Kind::Final });
        }
        if changed.x && self.text_wraps(i, Y) {
            self.queue_declared(i, Y, |size| size == Size::FitContent);
        }
        if let Some(axis) = stack_axis {
            self.queue(Slot { node: i, axis, kind: Kind::EvenShare });
        }
    }

    fn queue_even_share(&mut self, i: Self::NodeId) {
        if let Some(axis) = self.stack_axis(i) {
            self.queue(Slot { node: i, axis, kind: Kind::EvenShare });
        }
    }

    fn queue(&mut self, slot: Slot<Self::NodeId>) {
        let Slot { node, axis, kind } = slot;
        let data = self.node_layout_data_mut(node);
        if data.flags.check_state(axis, kind) != SOLVED {
            return;
        }
        data.flags.set_state(axis, kind, UNSOLVED);
        let level = data.levels[slot_index(axis, kind)];
        self.layout_data().queue.push(level, slot);
    }

    /// Computes the queued slots in order of level, and queues the dependents of each slot that changes. The levels are exact, so each slot is computed once. It stops after `max_computed` slot computations.
    fn run_queue(&mut self, max_computed: u32) -> IncrementalRelayoutOutcome {
        let mut computed = 0;
        loop {
            let data = self.layout_data();
            let Some(slot) = data.queue.pop() else { break };
            computed += 1;
            if computed > max_computed {
                data.queue.clear();
                return IncrementalRelayoutOutcome::FallbackTooMuchWork;
            }
            let k = slot_index(slot.axis, slot.kind);
            let old = self.node_layout_data(slot.node);
            let (old_value, old_grid_lines) = (old.values[k], old.grid_lines());
            // The level of the slot stays the same.
            self.finish_slot(slot);
            let new = self.node_layout_data(slot.node);
            // The cells of a width grid can change while its size stays the same.
            if new.values[k].to_bits() != old_value.to_bits() || new.grid_lines() != old_grid_lines {
                self.queue_dependents(slot);
            }
        }
        IncrementalRelayoutOutcome::Success { computed }
    }

    /// Queues every slot that reads `slot`. It is the reverse of `solve_all_dependencies`, and it has to stay in sync with it.
    fn queue_dependents(&mut self, slot: Slot<Self::NodeId>) {
        let Slot { node: i, axis, kind } = slot;
        match kind {
            Kind::EvenShare => {
                for_each_layout_child!(self, i, child, {
                    if self.is_in_stack(child, axis) {
                        self.queue_declared(child, axis, |size| size.is_fill());
                    }
                });
            }
            Kind::Final => {
                let other = axis.other();
                self.queue_declared(i, other, |size| matches!(size, Size::AspectRatio(_)));
                let grid_main = self.width_grid_main_axis(i) == Some(axis);
                if grid_main || (axis == X && self.text_wraps(i, Y))
                    || self.node_layout_params(i).content_measure.reads_other_axis(other)
                {
                    self.queue_declared(i, other, |size| size == Size::FitContent);
                }
                if self.stack_axis(i) == Some(axis) {
                    self.queue(Slot { node: i, axis, kind: Kind::EvenShare });
                }
                for_each_layout_child!(self, i, child, {
                    for child_axis in [X, Y] {
                        // A placed child of a width grid also reads the main axis for its other axis.
                        if child_axis == axis || (grid_main && ! self.node_layout_params(child).free_placement) {
                            let in_stack = self.is_in_stack(child, child_axis);
                            self.queue_declared(child, child_axis, |size| matches!(size, Size::Frac(_)) || (size.is_fill() && ! in_stack));
                        }
                    }
                });
                if let Some(parent) = self.stack_parent(i, axis) && ! self.any_size_is_fill(i, axis) {
                    self.queue(Slot { node: parent, axis, kind: Kind::EvenShare });
                }
            }
            Kind::Flow => unreachable!("flow currently uses full measurement"),
            declared => {
                self.queue(Slot { node: i, axis, kind: Kind::Final });
                if ! self.node_layout_params(i).free_placement && let Some(parent) = self.parent(i) {
                    let size = self.read_size(i, axis, declared).unwrap();
                    if self.stack_axis(parent) == Some(axis) && self.any_size_is_fill(i, axis) && ! size.is_fill() {
                        self.queue(Slot { node: parent, axis, kind: Kind::EvenShare });
                    }
                    if ! size.is_flex() {
                        self.queue_declared(parent, axis, |size| size == Size::FitContent);
                    }
                }
            }
        }
    }

    /// Queues the declared slots of a node on `axis` whose size matches `filter`.
    #[inline(always)]
    fn queue_declared(&mut self, i: Self::NodeId, axis: Axis, filter: impl Fn(Size) -> bool) {
        for kind in DECLARED_SIZES {
            if let Some(size) = self.read_size(i, axis, kind) && filter(size) {
                self.queue(Slot { node: i, axis, kind });
            }
        }
    }
}

impl<T: TreeAdapter + ?Sized> Incremental for T {}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rebuilding_blocks_compacts_live_margins_after_reordering() {
        let mut tree: LayoutTree = LayoutTree::new();
        let root = tree.root();
        let block = LayoutParams {
            size: Xy::new(Size::Fill, Size::Auto),
            children_layout: ChildrenLayout::Block,
            ..LayoutParams::DEFAULT
        };
        let groups = [tree.add_node(root, block), tree.add_node(root, block)];
        let nested = groups.map(|parent| tree.add_node(parent, block));
        let mut children = nested.map(|parent| tree.add_node(parent, LayoutParams::DEFAULT));
        let window = Xy::new_symm(100.0);
        tree.solve_layout(window);
        for i in 0..24 {
            let hot = i % 2;
            tree.remove(children[hot]);
            children[hot] = tree.add_node(nested[hot], LayoutParams {
                size: Xy::new(Size::Auto, Size::Pixels(10.0)),
                margin: Xy::new([Margin::ZERO; 2], [Margin::px(i as f32 + 2.0), Margin::px(3.0)]),
                ..LayoutParams::DEFAULT
            });
            tree.move_node(groups[hot], root, None);
            let mut full = tree.clone();
            full.invalidate();
            full.solve_layout(window);
            assert!(matches!(tree.solve_layout(window), IncrementalRelayoutOutcome::Success { .. }));
            for id in groups.into_iter().chain(nested).chain(children) {
                assert_eq!(tree.layout(id), full.layout(id));
            }
            assert!(tree.layout_data.block_margins.len() <= 2 * (groups.len() + nested.len()));
        }
        assert!(tree.layout_data.margin_scratch.capacity() > 0);
    }

    #[test]
    fn queue_preserves_priority_and_lifo_order_when_reusing_entries() {
        let mut queue = WorkQueue::new();
        let slot = |node| Slot { node, axis: X, kind: Kind::Regular };
        for (level, id) in [(4000, 1), (3999, 2), (3990, 3), (3999, 4)] {
            queue.push(level, slot(id));
        }
        assert_eq!(queue.pop().unwrap().node, 3);
        queue.push(4001, slot(5));
        assert_eq!(queue.pop().unwrap().node, 4);
        queue.push(4000, slot(6));
        for expected in [2, 6, 1, 5] {
            assert_eq!(queue.pop().unwrap().node, expected);
        }
        assert!(queue.pop().is_none());

        queue.push(65535, slot(7));
        queue.clear();
        queue.push(0, slot(8));
        assert_eq!(queue.pop().unwrap().node, 8);
        assert!(queue.pop().is_none());
    }

    #[test]
    fn explicit_invalidations_take_priority_over_inferred_fallbacks() {
        use IncrementalRelayoutOutcome::*;
        let window = Xy::new_symm(100.0);
        for fallback in [FallbackFlow, FallbackCycle, FallbackTooMuchWork] {
            let mut tree: LayoutTree = LayoutTree::new();
            let root = tree.root();
            if fallback == FallbackFlow {
                tree.update_node_params(root, LayoutParams { children_layout: ChildrenLayout::Block, ..LayoutParams::DEFAULT });
            } else if fallback == FallbackCycle {
                tree.add_node(root, LayoutParams { size: Xy::new_symm(Size::AspectRatio(1.0)), ..LayoutParams::DEFAULT });
            }
            let item = tree.add_node(root, LayoutParams { size: Xy::new_symm(Size::Pixels(10.0)), ..LayoutParams::DEFAULT });
            tree.solve_layout(window);

            let mut params = *tree.params(item);
            params.size.x = Size::Pixels(11.0);
            tree.update_node_params(item, params);
            for _ in 0..4 {
                tree.mark_content_changed(item);
            }

            let mut invalidated = tree.clone();
            invalidated.invalidate();
            params.size.x = Size::Fill;
            invalidated.update_node_params(item, params);
            assert_eq!(invalidated.solve_layout(window), FallbackInvalidated);

            let mut structural = tree.clone();
            structural.update_node_params(item, params);
            structural.invalidate();
            assert_eq!(structural.solve_layout(window), FallbackInvalidated);
            assert_eq!(tree.solve_layout(window), fallback);
        }
    }
}
