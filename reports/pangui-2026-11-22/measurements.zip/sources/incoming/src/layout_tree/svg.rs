use super::*;
use arrayvec::ArrayString;
use std::fmt::{self, Write};

impl<T> LayoutTree<T> {
    fn write_svg_inner(&self, svg: &mut (impl Write + ?Sized), text: impl Fn(&T) -> &str) -> fmt::Result {
        let mut numbers = SvgNumbers::new();
        let window = self.layout_data.window_size;
        writeln!(svg, "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{}\" height=\"{}\" font-family=\"monospace\" font-size=\"7.5\">", window.x, window.y)?;
        writeln!(svg, "<rect width=\"100%\" height=\"100%\" fill=\"#faf8f5\"/>")?;
        let mut next = Some(self.root);
        while let Some(i) = next {
            let node = &self.nodes[i];
            next = self.next_in_subtree(self.root, i, !node.params.disabled);
            if node.params.disabled {
                continue;
            }
            let color = node_color(i);
            let color = color.as_str();
            let rect = node.rect;
            let size = node.params.size;

            numbers.write_fields(svg, [
                ("<rect x=\"", rect.x[0]), ("\" y=\"", rect.y[0]),
                ("\" width=\"", rect.x[1] - rect.x[0]), ("\" height=\"", rect.y[1] - rect.y[0]),
            ])?;
            writeln!(svg, "\" fill=\"{color}\" fill-opacity=\"0.06\" stroke=\"{color}\"/>")?;
            if let (Some(context), true) = (&node.context, node.params.text != TextContent::None) {
                let [left, right] = node.params.padding.x;
                let wraps = node.params.text == TextContent::Wrapping && !matches!(node.params.size.x, Size::AspectRatio(_));
                let wrap_width = wraps.then(|| (node.layout.size().x - left - right).max(0.0));
                for (n, line) in wrapped_lines(text(context), wrap_width).enumerate() {
                    let y = rect.y[0] + node.params.padding.y[0] + (n as f32 + 0.75) * LINE_HEIGHT;
                    let length = line.width_in_chars as f32 * CHAR_WIDTH;
                    numbers.write_fields(svg, [
                        ("<text x=\"", rect.x[0] + left), ("\" y=\"", y),
                        ("\" font-size=\"", FONT_SIZE), ("\" textLength=\"", length),
                    ])?;
                    svg.write_str("\" lengthAdjust=\"spacingAndGlyphs\" fill=\"#222\">")?;
                    line.write_text(svg)?;
                    writeln!(svg, "</text>")?;
                }
            }
            numbers.write_fields(svg, [("<text x=\"", rect.x[0] + 2.25), ("\" y=\"", rect.y[0] + 9.0)])?;
            write!(svg, "\" fill=\"{color}\">")?;
            numbers.write_size(svg, size.x)?;
            svg.write_str(" × ")?;
            numbers.write_size(svg, size.y)?;
            svg.write_str("</text>\n")?;
        }
        writeln!(svg, "</svg>")
    }

    fn svg_string(&self, text: impl Fn(&T) -> &str) -> String {
        // Each visible node emits a rectangle and its size label. Use the measured count
        // only while it is current; a structural change may have hidden a whole subtree.
        let visible = if self.layout_data.pending_full_solve.is_none() {
            self.layout_data.n_nodes_solved as usize
        } else {
            0
        };
        let mut svg = String::new();
        // About 240 bytes of markup per node plus the header. A failed estimate
        // leaves the String free to grow as individual tags are written.
        let _ = svg.try_reserve_exact(visible.saturating_mul(240).saturating_add(256));
        self.write_svg_inner(&mut svg, text).expect("writing to a String cannot fail");
        svg
    }

    /// Writes the layout rectangles to a caller-provided buffer or formatter.
    pub fn write_svg(&self, svg: &mut (impl Write + ?Sized)) -> fmt::Result {
        self.write_svg_inner(svg, |_| "")
    }

    /// Draws an SVG image representing the layout rectangles from the last `solve_layout()`.
    pub fn to_svg(&self) -> String {
        self.svg_string(|_| "")
    }
}

impl<T: AsRef<str>> LayoutTree<T> {
    /// Writes the layout rectangles and their text to a caller-provided buffer or formatter.
    pub fn write_svg_with_text(&self, svg: &mut (impl Write + ?Sized)) -> fmt::Result {
        self.write_svg_inner(svg, |text| text.as_ref())
    }

    /// Draws an SVG image representing the layout from the last `solve_layout()`.
    ///
    /// The text will only have the correct dimensions if [`measure_monospace_text()`] is used as the measurement function.
    pub fn to_svg_with_text(&self) -> String {
        self.svg_string(|text| text.as_ref())
    }
}

/// Each line borrows its original UTF-8 span. Its width counts one space between words.
struct WrappedLine<'text> {
    source: &'text str,
    width_in_chars: usize,
    single_spaces: bool,
}

impl WrappedLine<'_> {
    fn write_text(&self, svg: &mut (impl Write + ?Sized)) -> fmt::Result {
        if self.single_spaces {
            return write_escaped(svg, self.source);
        }
        for (index, word) in self.source.split_whitespace().enumerate() {
            if index != 0 {
                svg.write_char(' ')?;
            }
            write_escaped(svg, word)?;
        }
        Ok(())
    }
}

fn wrapped_lines(text: &str, wrap_width: Option<f32>) -> impl Iterator<Item = WrappedLine<'_>> {
    let ascii = text.is_ascii();
    let mut words = text.split_whitespace().map(move |word| {
        // split_whitespace returns subslices of text. Keep the original boundaries for bulk writes.
        let start = word.as_ptr().addr() - text.as_ptr().addr();
        let width = if ascii { word.len() } else { word.chars().count() };
        (start..start + word.len(), width)
    }).peekable();
    let max = max_line_chars(wrap_width);
    std::iter::from_fn(move || {
        let (mut line, mut width) = words.next()?;
        let mut single_spaces = true;
        while let Some((next, chars)) = words.next_if(|(_, chars)| width + 1 + chars <= max) {
            single_spaces &= next.start == line.end + 1 && text.as_bytes()[line.end] == b' ';
            line.end = next.end;
            width += 1 + chars;
        }
        Some(WrappedLine { source: &text[line], width_in_chars: width, single_spaces })
    })
}

fn write_escaped(svg: &mut (impl Write + ?Sized), text: &str) -> fmt::Result {
    let mut start = 0;
    for index in memchr::memchr2_iter(b'&', b'<', text.as_bytes()) {
        svg.write_str(&text[start..index])?;
        svg.write_str(if text.as_bytes()[index] == b'&' { "&amp;" } else { "&lt;" })?;
        start = index + 1;
    }
    svg.write_str(&text[start..])
}

fn node_color(i: NodeId) -> ArrayString<24> {
    use slotmap::Key;
    let mut hash = i.data().as_ffi().wrapping_add(0x9e37_79b9_7f4a_7c15);
    hash = (hash ^ (hash >> 30)).wrapping_mul(0xbf58_476d_1ce4_e5b9);
    hash = (hash ^ (hash >> 27)).wrapping_mul(0x94d0_49bb_1331_11eb);
    hash ^= hash >> 31;
    let hue = hash % 360;
    let saturation = 45 + (hash >> 16) % 25;
    let lightness = 32 + (hash >> 32) % 14;
    let mut color = ArrayString::new();
    write!(color, "hsl({hue}, {saturation}%, {lightness}%)").unwrap();
    color
}

// Coordinates, line lengths and dimensions recur across tags. Cache their exact Display
// spellings for this render. Using the bits as keys keeps -0.0 distinct from +0.0.
const NUMBER_CACHE_BITS: u32 = 6;
struct SvgNumbers([(u32, ArrayString<64>); 1 << NUMBER_CACHE_BITS]);

impl SvgNumbers {
    fn new() -> Self {
        Self([(0, ArrayString::new()); 1 << NUMBER_CACHE_BITS])
    }

    fn number(&mut self, value: f32) -> &str {
        let bits = value.to_bits();
        let hash = (bits ^ (bits >> 13)).wrapping_mul(0x9e37_79b9);
        let index = hash >> (u32::BITS - NUMBER_CACHE_BITS);
        let (key, text) = &mut self.0[index as usize];
        if *key != bits || text.is_empty() {
            text.clear();
            // Even negative subnormal f32s fit within 64 bytes in decimal notation.
            write!(text, "{value}").unwrap();
            *key = bits;
        }
        text.as_str()
    }

    fn write_fields<const N: usize>(&mut self, svg: &mut (impl Write + ?Sized), fields: [(&str, f32); N]) -> fmt::Result {
        for (prefix, value) in fields {
            svg.write_str(prefix)?;
            svg.write_str(self.number(value))?;
        }
        Ok(())
    }

    fn write_size(&mut self, svg: &mut (impl Write + ?Sized), size: Size) -> fmt::Result {
        let (value, suffix) = match size {
            Size::Fill => return svg.write_str("fill"),
            Size::FitContent => return svg.write_str("fit"),
            Size::Auto => return svg.write_str("auto"),
            Size::Pixels(value) => (value, "px"),
            Size::Frac(value) => (value, "fr"),
            Size::AspectRatio(value) => {
                svg.write_str("ratio ")?;
                (value, "")
            }
        };
        svg.write_str(self.number((value * 100.0).round() / 100.0))?;
        svg.write_str(suffix)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn svg_number_cache_preserves_display_across_evictions() {
        let mut numbers = SvgNumbers::new();
        for exponent in 0..=255u32 {
            for fraction in [0, 1, 0x0012_3456, 0x007f_ffff] {
                for sign in [0, 1 << 31] {
                    let value = f32::from_bits(sign | exponent << 23 | fraction);
                    let expected = value.to_string();
                    assert_eq!(numbers.number(value), expected);
                    assert_eq!(numbers.number(value), expected);
                }
            }
        }
    }

    #[test]
    fn svg_propagates_a_stream_failure() {
        struct LimitedWriter(usize);
        impl fmt::Write for LimitedWriter {
            fn write_str(&mut self, text: &str) -> fmt::Result {
                self.0 = self.0.checked_sub(text.len()).ok_or(fmt::Error)?;
                Ok(())
            }
        }
        let tree = LayoutTree::<&str>::new();
        let len = tree.to_svg_with_text().len();
        for limit in [0, len / 2, len - 1] {
            assert!(tree.write_svg_with_text(&mut LimitedWriter(limit)).is_err());
        }
        assert!(tree.write_svg_with_text(&mut LimitedWriter(len)).is_ok());
    }

    #[test]
    fn borrowed_lines_and_ascii_measurement_agree_across_chunk_boundaries() {
        let id = LayoutTree::<()>::new().root();
        // Include every ASCII byte, in particular vertical tab and the non-whitespace controls.
        let input: String = (0..=127u8).chain((0..=127u8).rev()).map(char::from).collect();
        for end in 0..=input.len() {
            let mut text = &input[..end];
            for width in [None, Some(0.0), Some(12.0 * CHAR_WIDTH)] {
                let expected = measure_word_widths(text.split_whitespace().map(str::len), width);
                let measured = measure_monospace_text(id, Some(&mut text), width);
                assert_eq!(expected, measured);
                let lines = wrapped_lines(text, width);
                let mut count = 0;
                let mut longest = 0;
                for line in lines {
                    let normalized = line.source.split_whitespace().collect::<Vec<_>>().join(" ");
                    assert_eq!(normalized.len(), line.width_in_chars);
                    count += 1;
                    longest = longest.max(line.width_in_chars);
                }
                assert_eq!(measured, Xy::new(longest as f32 * CHAR_WIDTH, count as f32 * LINE_HEIGHT));
            }
        }
    }

    #[test]
    fn svg_lines_preserve_normalized_text_and_xml_entities() {
        let text = "\u{a0}λ< \t &猫\u{200a}dog\u{b} x&<  ";
        for (width, expected) in [
            (None, "λ&lt; &amp;猫 dog x&amp;&lt;\n"),
            (Some(5.0 * CHAR_WIDTH), "λ&lt; &amp;猫\ndog\nx&amp;&lt;\n"),
            (Some(0.0), "λ&lt;\n&amp;猫\ndog\nx&amp;&lt;\n"),
        ] {
            let mut svg = String::new();
            for line in wrapped_lines(text, width) {
                line.write_text(&mut svg).unwrap();
                svg.push('\n');
            }
            assert_eq!(svg, expected);
        }
    }

    #[test]
    fn svg_streams_normalized_and_escaped_borrowed_text_in_paint_order() {
        let text = String::from("  λ&<  \t 猫\u{2003}longword  ");
        let mut tree = LayoutTree::new();
        let params = LayoutParams {
            text: TextContent::Wrapping,
            size: Xy::new(Size::Pixels(5.0 * CHAR_WIDTH), Size::FitContent),
            ..LayoutParams::DEFAULT
        };
        let root = tree.root();
        tree.add_node_with_context(root, params, "painted last");
        tree.add_node_with_context(root, params, text.as_str());
        tree.add_node_with_context(root, LayoutParams { disabled: true, ..params }, "hidden");
        tree.solve_layout_with_measure(Xy::new_symm(120.0), measure_monospace_text);
        let mut svg = String::from("prefix");
        tree.write_svg_with_text(&mut svg).unwrap();
        assert_eq!(&svg["prefix".len()..], tree.to_svg_with_text());
        let short = svg.find(">λ&amp;&lt; 猫</text>").unwrap();
        let long = svg.find(">longword</text>").unwrap();
        let last = svg.find(">painted</text>").unwrap();
        assert!(short < long && long < last);
        assert!(!svg.contains("hidden"));
    }

}
