use crate::{Incremental, LayoutParams, NodeLayoutData, TreeAdapter};

// A cached node record can be detached, recycled, or brought in from another
// adapter. Disjoint ticket ranges distinguish it from the current snapshot in
// all of those cases. Reserve once per snapshot, independent of tree size.
#[cfg(target_has_atomic = "64")]
fn reserve_tickets(count: usize) -> u64 {
    use std::sync::atomic::{AtomicU64, Ordering};
    static NEXT: AtomicU64 = AtomicU64::new(1);
    NEXT.fetch_update(Ordering::Relaxed, Ordering::Relaxed, |next| next.checked_add(count as u64))
        .expect("exhausted topology tickets")
}

#[cfg(not(target_has_atomic = "64"))]
fn reserve_tickets(count: usize) -> u64 {
    use std::sync::Mutex;
    static NEXT: Mutex<u64> = Mutex::new(1);
    let mut next = NEXT.lock().unwrap();
    let first = *next;
    *next = first.checked_add(count as u64).expect("exhausted topology tickets");
    first
}

#[derive(Clone, Debug)]
struct PriorNode<I> {
    id: I,
    parent: usize,
    // In preorder, the following sibling is immediately after this subtree.
    end: usize,
    style: usize,
}

#[derive(Clone, Debug)]
struct PriorStyle {
    params: LayoutParams,
    uses: usize,
}

#[derive(Clone, Debug)]
pub(crate) struct TopologySnapshot<I> {
    first_ticket: u64,
    nodes: Vec<PriorNode<I>>,
    // Consecutive equal declarations share one copy. A registered parameter
    // edit splits a shared entry or overwrites a private one in place.
    styles: Vec<PriorStyle>,
}

impl<I: Eq> TopologySnapshot<I> {
    fn index(&self, id: I, ticket: u64) -> Option<usize> {
        let index = usize::try_from(ticket.checked_sub(self.first_ticket)?).ok()?;
        self.nodes.get(index).filter(|entry| entry.id == id).map(|_| index)
    }
}

impl<I> TopologySnapshot<I> {
    pub(crate) const fn new() -> Self {
        Self { first_ticket: 1, nodes: Vec::new(), styles: Vec::new() }
    }

    fn store_style(&mut self, params: &LayoutParams) -> usize {
        if let Some(last) = self.styles.last_mut() && last.params == *params {
            last.uses += 1;
        } else {
            self.styles.push(PriorStyle { params: *params, uses: 1 });
        }
        self.styles.len() - 1
    }
}

const ROOT_PARENT: usize = usize::MAX;

pub(crate) trait Topology: TreeAdapter {
    fn remember_topology(&mut self) {
        let Some(mut snapshot) = self.layout_data().topology.take() else { return };
        snapshot.nodes.clear();
        snapshot.styles.clear();
        snapshot.nodes.reserve(self.layout_data().n_nodes_solved as usize);
        self.capture_subtree(self.root(), ROOT_PARENT, &mut snapshot);

        snapshot.first_ticket = reserve_tickets(snapshot.nodes.len());
        for (index, entry) in snapshot.nodes.iter().enumerate() {
            self.node_layout_data_mut(entry.id).topology_index = snapshot.first_ticket + index as u64;
        }
        self.layout_data().topology = Some(snapshot);
    }

    fn capture_subtree(&self, node: Self::NodeId, parent: usize, snapshot: &mut TopologySnapshot<Self::NodeId>) {
        let params = self.node_layout_params(node);
        let style = snapshot.store_style(params);
        let index = snapshot.nodes.len();
        snapshot.nodes.push(PriorNode { id: node, parent, end: 0, style });
        if !params.disabled {
            let mut next = self.first_child(node);
            while let Some(child) = next {
                self.capture_subtree(child, index, snapshot);
                next = self.next_sibling(child);
            }
        }
        snapshot.nodes[index].end = snapshot.nodes.len();
    }

    fn update_remembered_params(&mut self, node: Self::NodeId, old: &LayoutParams) {
        let ticket = self.node_layout_data(node).topology_index;
        if ticket == 0 { return }
        let params = *self.node_layout_params(node);
        let Some(snapshot) = self.layout_data().topology.as_mut() else { return };
        let Some(index) = snapshot.index(node, ticket) else { return };
        let style = &mut snapshot.styles[snapshot.nodes[index].style];
        // An earlier unlocalized edit may not have been reconciled yet. Only
        // advance a baseline that describes the caller's registered transition.
        if style.params == *old && style.params != params {
            if style.uses == 1 {
                style.params = params;
            } else {
                style.uses -= 1;
                snapshot.nodes[index].style = snapshot.styles.len();
                snapshot.styles.push(PriorStyle { params, uses: 1 });
            }
        }
    }

    fn reconcile_topology(&mut self) {
        let Some(snapshot) = self.layout_data().topology.take() else { return };
        self.reconcile_subtree(self.root(), Some(ROOT_PARENT), &snapshot);
        self.layout_data().topology = Some(snapshot);
    }

    fn mark_attached(&mut self, node: Self::NodeId) {
        let ticket = self.node_layout_data(node).topology_index;
        let Some(snapshot) = self.layout_data().topology.as_ref() else {
            self.node_layout_data_mut(node).mark_subtree_changed();
            return;
        };
        let prior = snapshot.index(node, ticket)
            .map(|index| snapshot.styles[snapshot.nodes[index].style].params);
        if prior.is_some_and(|params| !params.disabled && params == *self.node_layout_params(node)) {
            self.node_layout_data_mut(node).mark_moved();
            return;
        }
        let data = self.node_layout_data_mut(node);
        if prior.is_none() {
            // Cached descendant slots and block-margin indices can predate a
            // detachment or come from another tree. Prepare this subtree afresh.
            *data = NodeLayoutData::new();
        }
        data.mark_subtree_changed();
    }

    // Only the current traversal supplies IDs to adapter methods. The old child
    // list is traversed entirely by indices, even if its nodes have been deleted.
    fn reconcile_subtree(
        &mut self, node: Self::NodeId, parent: Option<usize>, snapshot: &TopologySnapshot<Self::NodeId>,
    ) -> Option<usize> {
        let index = snapshot.index(node, self.node_layout_data(node).topology_index);
        let prior = index.map(|index| &snapshot.nodes[index]);
        if let Some(entry) = prior {
            let old = &snapshot.styles[entry.style].params;
            let changed = old != self.node_layout_params(node);
            if changed {
                self.incr_register_node_change(node, old);
            }
            if Some(entry.parent) != parent {
                if old.disabled || changed {
                    self.node_layout_data_mut(node).mark_subtree_changed();
                } else {
                    self.node_layout_data_mut(node).mark_moved();
                }
            }
        } else {
            self.node_layout_data_mut(node).mark_subtree_changed();
        }
        if !self.node_layout_params(node).disabled {
            let end = prior.map_or(0, |entry| entry.end);
            let mut expected = index.map_or(0, |index| index + 1);
            let mut changed = false;
            let mut next = self.first_child(node);
            while let Some(child) = next {
                let old_child = self.reconcile_subtree(child, index, snapshot);
                if expected < end {
                    changed |= old_child != Some(expected);
                    expected = snapshot.nodes[expected].end;
                } else {
                    changed = true;
                }
                next = self.next_sibling(child);
            }
            if changed || expected != end {
                self.node_layout_data_mut(node).mark_children_changed();
            }
        }
        index
    }
}

impl<T: TreeAdapter + ?Sized> Topology for T {}
