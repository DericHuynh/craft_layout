use crate::*;

#[inline]
pub(crate) fn margins(params: &LayoutParams, axis: Axis) -> [f32; 2] {
    params.margin[axis].map(Margin::pixels)
}

#[inline]
pub(crate) fn with_margin(size: f32, margin: f32) -> f32 {
    if margin == 0.0 { size } else { size + margin }
}

#[derive(Debug, Clone, Copy, Default, PartialEq)]
pub(crate) struct CollapsedMargin {
    positive: f32,
    negative: f32,
}

impl CollapsedMargin {
    fn new(value: f32) -> Self {
        Self { positive: value.max(0.0), negative: value.min(0.0) }
    }

    fn merge(&mut self, other: Self) {
        self.positive = self.positive.max(other.positive);
        self.negative = self.negative.min(other.negative);
    }

    fn size(self) -> f32 {
        self.positive + self.negative
    }
}

#[derive(Debug, Clone, Copy, Default)]
pub(crate) struct BlockMargins {
    before: CollapsedMargin,
    after: CollapsedMargin,
    all_through: bool,
}

impl BlockMargins {
    // The node already records the empty-block case and its declared physical margins.
    // Only nested margins or a collapse-through chain need additional storage.
    pub(crate) fn is_implicit(self, layout: &NodeLayoutData) -> bool {
        self.before == CollapsedMargin::default() && self.after == CollapsedMargin::default()
            && self.all_through == (layout.n_placed_children == 0)
    }
}

/// The collapsible margins at each edge of an in-flow block and the block's box height.
pub(crate) struct BlockItem {
    before: CollapsedMargin,
    after: CollapsedMargin,
    size: f32,
    through: bool,
}

impl BlockItem {
    pub(crate) fn new(params: &LayoutParams, layout: &NodeLayoutData, nested: Option<BlockMargins>) -> Self {
        let [top, bottom] = margins(params, Y);
        let mut before = CollapsedMargin::new(top);
        let mut after = CollapsedMargin::new(bottom);
        if let Some(nested) = nested {
            before.merge(nested.before);
            after.merge(nested.after);
        }
        let size = layout.size().y;
        let through = size == 0.0 && block_can_collapse(params)
            && params.padding.y == [0.0; 2]
            && params.min_size.y.is_none_or(|size| size == Size::Pixels(0.0) || size == Size::Frac(0.0))
            && nested.map_or(layout.n_placed_children == 0, |nested| nested.all_through);
        Self { before, after, size, through }
    }
}

fn block_can_collapse(params: &LayoutParams) -> bool {
    params.text == TextContent::None && params.image.is_none() && params.content_measure == ContentMeasure::None
}

/// Tracks adjoining block margins independently of their net size, so adding another margin
/// to the group still uses the largest positive and most negative contributions.
pub(crate) struct BlockFlow {
    end: f32,
    pending: CollapsedMargin,
    outgoing: BlockMargins,
    collapse_top: bool,
    collapse_bottom: bool,
}

impl BlockFlow {
    pub(crate) fn new(params: &LayoutParams, block_item: bool, auto_height: bool) -> Self {
        let margins_adjoin = block_item && block_can_collapse(params);
        Self {
            end: 0.0,
            pending: CollapsedMargin::default(),
            outgoing: BlockMargins { all_through: true, ..BlockMargins::default() },
            collapse_top: margins_adjoin && params.padding.y[0] == 0.0,
            collapse_bottom: margins_adjoin && params.padding.y[1] == 0.0 && auto_height
                && params.min_size.y.is_none_or(|size| size == Size::Pixels(0.0) || size == Size::Frac(0.0)),
        }
    }

    pub(crate) fn push(&mut self, item: BlockItem) -> f32 {
        self.pending.merge(item.before);
        let top_adjoins_parent = self.outgoing.all_through && self.collapse_top;
        let start = self.end + if top_adjoins_parent { 0.0 } else { self.pending.size() };
        if item.through {
            self.pending.merge(item.after);
        } else {
            if top_adjoins_parent {
                self.outgoing.before = self.pending;
            }
            self.outgoing.all_through = false;
            self.end = start + item.size;
            self.pending = item.after;
        }
        start
    }

    pub(crate) fn finish(mut self) -> (f32, BlockMargins) {
        if self.outgoing.all_through && self.collapse_top {
            self.outgoing.before = self.pending;
        } else if self.collapse_bottom {
            self.outgoing.after = self.pending;
        } else {
            self.end += self.pending.size();
        }
        (self.end.max(0.0), self.outgoing)
    }
}

pub(crate) struct WrapLine<I> {
    pub(crate) next: Option<I>,
    pub(crate) count: u32,
    pub(crate) main: f32,
    pub(crate) cross: f32,
    pub(crate) has_fill: bool,
}

pub(crate) trait Flow: Solve {
    /// With an available size, find a break using each child's size before Fill. Otherwise
    /// reuse the saved break and read the resolved dimensions for measurement or placement.
    fn wrap_line(&self, mut next: Option<Self::NodeId>, axis: Axis, available: Option<f32>, spacing: f32) -> WrapLine<Self::NodeId> {
        let cross_axis = axis.other();
        let mut count = 0;
        let mut main = 0.0;
        let mut cross: f32 = 0.0;
        let mut has_fill = false;
        while let Some(child) = next {
            let params = self.node_layout_params(child);
            if !params.disabled && !params.free_placement {
                if available.is_none() && count != 0 && self.node_layout_data(child).flags.starts_wrap_line() {
                    break;
                }
                let fill = available.is_some() && self.any_size_is_fill(child, axis);
                let size = if fill {
                    self.wrap_fill_base(child, axis)
                } else {
                    self.get_solved_value(child, axis, Kind::Final)
                };
                let [start, end] = margins(params, axis);
                let extent = with_margin(size, start + end);
                let new_main = if count == 0 { extent } else { main + spacing + extent };
                if count != 0 && available.is_some_and(|available| new_main > available) {
                    break;
                }
                main = new_main;
                has_fill |= fill;
                if available.is_none() {
                    let [start, end] = margins(params, cross_axis);
                    cross = cross.max(with_margin(self.pre_grow_size(child, cross_axis), start + end));
                }
                count += 1;
            }
            next = self.next_sibling(child);
        }
        WrapLine { next, count, main, cross, has_fill }
    }

    fn block_flow(&self, i: Self::NodeId) -> BlockFlow {
        BlockFlow::new(self.node_layout_params(i), self.node_layout_data(i).flags.is_block_item(),
            self.read_size(i, Y, Kind::Regular) == Some(Size::FitContent))
    }

    fn block_item(&mut self, i: Self::NodeId) -> BlockItem {
        let index = self.node_layout_data(i).block_margin_index();
        let nested = index.map(|index| self.layout_data().block_margins[index]);
        BlockItem::new(self.node_layout_params(i), self.node_layout_data(i), nested)
    }
}

impl<T: TreeAdapter + ?Sized> Flow for T {}
