use crate::*;
use crate::Axis::{X, Y};
use std::num::NonZeroU32;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum Kind {
    Regular,
    Min,
    Max,
    Final,
    EvenShare,
    Flow,
}

/// The kinds that have a slot on each axis.
const N_AXIS_KINDS: usize = Kind::Final as usize + 1;
pub(crate) const DECLARED_SIZES: [Kind; 3] = [Kind::Regular, Kind::Min, Kind::Max];
pub(crate) const N_SLOTS: usize = 2 * N_AXIS_KINDS + 2;

#[inline(always)]
pub(crate) const fn slot_index(axis: Axis, kind: Kind) -> usize {
    match kind {
        Kind::EvenShare => 2 * N_AXIS_KINDS,
        Kind::Flow => 2 * N_AXIS_KINDS + 1,
        _ => axis as usize * N_AXIS_KINDS + kind as usize,
    }
}

#[derive(Debug, Clone, Copy)]
pub(crate) struct Slot<I> {
    pub node: I,
    pub axis: Axis,
    pub kind: Kind,
}

/// The state of each slot takes 2 bits in `NodeFlags`.
pub(crate) const UNSOLVED: u32 = 0;
/// The slot is solving the slots that it reads. Reaching it again means that there is a cycle.
const IN_PROGRESS: u32 = 1;
pub(crate) const SOLVED: u32 = 2;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct NodeFlags(u32);

impl NodeFlags {
    pub(crate) const EMPTY: NodeFlags = NodeFlags(0);

    const IN_CYCLE_X: u32 = 1 << (2 * N_SLOTS);
    const IN_CYCLE_Y: u32 = 1 << (2 * N_SLOTS + 1);
    const FLEX_CHILD_X: u32 = 1 << (2 * N_SLOTS + 2);
    const FLEX_CHILD_Y: u32 = 1 << (2 * N_SLOTS + 3);
    const GRID_SPANS: u32 = 1 << (2 * N_SLOTS + 4);
    const BLOCK_ITEM: u32 = 1 << (2 * N_SLOTS + 5);
    const BLOCK_PARENT_AUTO_HEIGHT: u32 = 1 << (2 * N_SLOTS + 6);
    const BLOCK_CONTAINER: u32 = 1 << (2 * N_SLOTS + 7);
    const WRAP_CONTAINER: u32 = 1 << (2 * N_SLOTS + 8);
    const WRAP_LINE_START: u32 = 1 << (2 * N_SLOTS + 9);
    const DESCENDANTS_NEED_SOLVE: u32 = 1 << (2 * N_SLOTS + 10);
    const FIXED_LEAF: u32 = 1 << (2 * N_SLOTS + 11);

    pub(crate) fn is_block_item(self) -> bool {
        self.0 & Self::BLOCK_ITEM != 0
    }

    pub(crate) fn starts_wrap_line(self) -> bool {
        self.0 & Self::WRAP_LINE_START != 0
    }

    #[inline(always)]
    fn in_cycle(axis: Axis) -> u32 {
        match axis {
            X => NodeFlags::IN_CYCLE_X,
            Y => NodeFlags::IN_CYCLE_Y,
        }
    }

    #[inline(always)]
    fn flex_child(axis: Axis) -> u32 {
        match axis {
            X => NodeFlags::FLEX_CHILD_X,
            Y => NodeFlags::FLEX_CHILD_Y,
        }
    }

    #[inline(always)]
    pub(crate) fn check_state(self, axis: Axis, kind: Kind) -> u32 {
        let k = slot_index(axis, kind);
        (self.0 >> (2 * k)) & 3
    }

    #[inline(always)]
    pub(crate) fn set_state(&mut self, axis: Axis, kind: Kind, state: u32) {
        let k = slot_index(axis, kind);
        self.0 = (self.0 & ! (3 << (2 * k))) | (state << (2 * k));
    }
}

const _: () = assert!(2 * N_SLOTS + 12 <= 32, "The slot states and the flags don't fit in NodeFlags");

const EMPTY_VALUES: [f32; N_SLOTS] = {
    let mut values = [0.0; N_SLOTS];
    values[slot_index(X, Kind::Max)] = f32::INFINITY;
    values[slot_index(Y, Kind::Max)] = f32::INFINITY;
    values
};


impl Size {
    #[inline(always)]
    pub(crate) fn is_fill(&self) -> bool {
        *self == Size::Fill
    }

    #[inline(always)]
    pub(crate) fn is_flex(&self) -> bool {
        matches!(self, Size::Frac(_) | Size::Fill)
    }
}

macro_rules! for_each_layout_child {
    ($solver:expr, $i:expr, $child:ident, $body:block) => {
        for_each_layout_child!(@from $solver, $solver.first_child($i), $child, $body)
    };
    (@from $solver:expr, $first:expr, $child:ident, $body:block) => {{
        let mut next = $first;
        while let Some($child) = next {
            next = $solver.next_sibling($child);
            if ! $solver.node_layout_params($child).disabled {
                $body
            }
        }
    }};
}

/// Per-node data used by the layout solver.
#[derive(Debug, Clone, Copy)]
pub struct NodeLayoutData {
    /// The value of every slot. Mapped by `slot_index()`.
    pub(crate) values: [f32; N_SLOTS],
    /// The state of every slot.
    pub(crate) flags: NodeFlags,
    /// The dependency level of every slot. Mapped by `slot_index()`.
    /// 
    /// The "level" is the longest chain of dependencies of dependencies flowing into a slot. This is used for efficient incremental relayout.
    #[cfg(feature = "incremental")]
    pub(crate) levels: [u16; N_SLOTS],
    /// How many children aren't free-placement.
    pub(crate) n_placed_children: u32,
    /// A grid item's two cell coordinates, or a wrap item's line metric.
    parent_flow: u32,
    /// A grid container's row/column counts, or a block's saved margin index plus one.
    children_flow: u32,
}

impl NodeLayoutData {
    /// Creates a new empty [`NodeLayoutData`].
    pub const fn new() -> Self {
        NodeLayoutData {
            values: EMPTY_VALUES,
            flags: NodeFlags::EMPTY,
            #[cfg(feature = "incremental")]
            levels: [0; N_SLOTS],
            n_placed_children: 0,
            parent_flow: 0,
            children_flow: 0,
        }
    }

    /// Initializes independent pixel slots and returns whether both final sizes are ready.
    #[inline(always)]
    fn seed_pixels(&mut self, params: &LayoutParams, block_item: bool, width_grid_axis: Option<Axis>) -> bool {
        let mut both_axes_fixed = true;
        for axis in [X, Y] {
            let Size::Pixels(pixels) = params.size[axis] else {
                both_axes_fixed = false;
                continue;
            };
            self.values[slot_index(axis, Kind::Regular)] = pixels;
            self.flags.set_state(axis, Kind::Regular, SOLVED);
            if params.min_size[axis].is_none() && params.max_size[axis].is_none()
                && pixels.is_finite() && !block_item && width_grid_axis != Some(axis)
            {
                let final_size = slot_index(axis, Kind::Final);
                self.values[final_size] = pixels;
                self.flags.set_state(axis, Kind::Final, SOLVED);
                #[cfg(feature = "incremental")]
                {
                    // A pixel value has no dependencies, and Final reads only Regular.
                    self.levels[final_size] = 1;
                }
            } else {
                both_axes_fixed = false;
            }
        }
        both_axes_fixed
    }

    #[inline]
    fn reset_leaf(&mut self, mut prepared: Self, fixed: bool) {
        if fixed {
            prepared.flags.0 |= NodeFlags::FIXED_LEAF;
            // The marker guarantees the slot levels and unused fields. A grid or
            // wrap parent can still have set parent_flow or marked a line start.
            if self.flags == prepared.flags && self.parent_flow == 0 && [X, Y].into_iter().all(|axis| {
                let pixels = prepared.values[slot_index(axis, Kind::Final)].to_bits();
                // An incremental pass can fall back between updating Regular and Final.
                [Kind::Regular, Kind::Final].into_iter().all(|kind| self.values[slot_index(axis, kind)].to_bits() == pixels)
            }) {
                return;
            }
        }
        *self = prepared;
    }

    pub(crate) fn size(&self) -> Xy<f32> {
        let values = &self.values;
        Xy::new(values[slot_index(X, Kind::Final)], values[slot_index(Y, Kind::Final)])
    }

    pub(crate) fn grid_cell(&self) -> Xy<u16> {
        unpack_counts(self.parent_flow)
    }

    pub(crate) fn grid_lines(&self) -> Xy<u16> {
        unpack_counts(self.children_flow)
    }

    pub(crate) fn block_margin_index(&self) -> Option<usize> {
        if self.flags.0 & NodeFlags::BLOCK_CONTAINER == 0 {
            return None;
        }
        NonZeroU32::new(self.children_flow).map(|index| index.get() as usize - 1)
    }

    fn wrap_line_metric(&self) -> f32 {
        f32::from_bits(self.parent_flow)
    }
}

fn pack_counts(counts: Xy<u16>) -> u32 {
    u32::from(counts.x) | u32::from(counts.y) << u16::BITS
}

fn unpack_counts(packed: u32) -> Xy<u16> {
    Xy::new(packed as u16, (packed >> u16::BITS) as u16)
}

impl Default for NodeLayoutData {
    fn default() -> Self {
        Self::new()
    }
}

/// A `Fill` child of a stack, in `solve_even_share`.
#[derive(Debug, Clone, Copy, Default)]
pub(crate) struct FillChild {
    min: f32,
    max: f32,
    weight: f32,
}

impl FillChild {
    fn new(content: Option<f32>, min: Option<f32>, max: Option<f32>, capped_by_content: bool, weight: f32) -> Self {
        // f32::min/max ignore a NaN bound. Fold the intrinsic constraint into the
        // interval once, preserving the declared minimum's precedence over the maximum.
        // If a target is NaN, its violation (size minus target) is NaN for any size
        // and the distribution loop can never freeze that child.
        let mut min = min.unwrap_or(f32::NAN);
        let mut max = max.unwrap_or(f32::NAN);
        if let Some(content) = content.filter(|value| !value.is_nan()) {
            if capped_by_content {
                max = max.min(content);
            } else {
                min = min.max(content.min(max));
            }
        }
        Self { min, max, weight }
    }

    fn size(&self, target: f32) -> f32 {
        target.min(self.max).max(self.min)
    }
}

const MAX_FIT_STACK_FRAC: f32 = 0.999;
const MAX_FIT_STACK_STEPS: usize = 64;
const FIT_STACK_EPSILON: f32 = 1e-6;
const EVEN_SHARE_EPSILON: f32 = 1e-3;

#[inline(always)]
fn clamp(size: f32, min: Option<f32>, max: Option<f32>) -> f32 {
    let size = max.map_or(size, |max| size.min(max));
    min.map_or(size, |min| size.max(min))
}

#[inline(always)]
fn inner(size: f32, padding: f32) -> f32 {
    (size - padding).max(0.0)
}

pub(crate) trait Solve: TreeAdapter {
    #[cfg(feature = "incremental")]
    #[inline(always)]
    fn tree_traversal_next(&self, i: Self::NodeId) -> Option<Self::NodeId> {
        self.traversal_next(i, !self.node_layout_params(i).disabled)
    }

    #[inline(always)]
    fn traversal_next(&self, i: Self::NodeId, descend: bool) -> Option<Self::NodeId> {
        if descend && let Some(child) = self.first_child(i) {
            return Some(child);
        }
        let root = self.root();
        let mut i = i;
        loop {
            if i == root {
                return None;
            }
            if let Some(sibling) = self.next_sibling(i) {
                return Some(sibling);
            }
            i = self.parent(i)?;
        }
    }

    #[inline(always)]
    fn read_size(&self, i: Self::NodeId, axis: Axis, kind: Kind) -> Option<Size> {
        let node = self.node_layout_params(i);
        let size = match kind {
            Kind::Min => node.min_size[axis],
            Kind::Max => node.max_size[axis],
            Kind::Regular => Some(node.size[axis]),
            Kind::Final | Kind::EvenShare | Kind::Flow => unreachable!(),
        };
        match size {
            Some(Size::Auto) => Some(if kind == Kind::Regular && axis == X && self.node_layout_data(i).flags.is_block_item() {
                Size::Fill
            } else {
                Size::FitContent
            }),
            Some(size) if axis == Y && size.is_flex()
                && self.node_layout_data(i).flags.0 & NodeFlags::BLOCK_PARENT_AUTO_HEIGHT != 0 =>
            {
                (kind == Kind::Regular).then_some(Size::FitContent)
            }
            size => size,
        }
    }

    #[inline(always)]
    fn any_size_is_fill(&self, i: Self::NodeId, axis: Axis) -> bool {
        let is_fill = |size: Option<Size>| size.is_some_and(|size| size.is_fill());
        is_fill(self.read_size(i, axis, Kind::Regular)) || is_fill(self.read_size(i, axis, Kind::Min)) || is_fill(self.read_size(i, axis, Kind::Max))
    }

    #[inline(always)]
    fn text_wraps(&self, i: Self::NodeId, axis: Axis) -> bool {
        axis == Y && self.node_layout_params(i).text == TextContent::Wrapping && ! matches!(self.node_layout_params(i).size[X], Size::AspectRatio(_))
    }

    #[inline(always)]
    fn stack_axis(&self, i: Self::NodeId) -> Option<Axis> {
        match self.node_layout_params(i).children_layout {
            ChildrenLayout::Stack { axis, .. } | ChildrenLayout::Wrap { axis, .. } => Some(axis),
            _ => None,
        }
    }

    /// The parent of `i`, if `i` is placed in a stack on `axis`.
    #[inline(always)]
    fn stack_parent(&self, i: Self::NodeId, axis: Axis) -> Option<Self::NodeId> {
        let parent = self.parent(i)?;
        (self.stack_axis(parent) == Some(axis) && ! self.node_layout_params(i).free_placement).then_some(parent)
    }

    #[cfg(feature = "incremental")]
    #[inline(always)]
    fn is_in_stack(&self, i: Self::NodeId, axis: Axis) -> bool {
        self.stack_parent(i, axis).is_some()
    }

    fn prepare(&mut self, i: Self::NodeId, block_parent: Option<bool>) -> (u32, bool) {
        let params = self.node_layout_params(i);
        if params.disabled {
            *self.node_layout_data_mut(i) = NodeLayoutData::new();
            return (0, false);
        }

        let children_layout = params.children_layout;
        let block_parent = block_parent.filter(|_| !params.free_placement);
        let block_children = (children_layout == ChildrenLayout::Block).then(|| {
            matches!(params.size.y, Size::Auto | Size::FitContent)
                || block_parent == Some(true) && params.size.y.is_flex()
        });
        let aspect_on_both_axes = matches!(params.size, Xy { x: Size::AspectRatio(_), y: Size::AspectRatio(_) });
        if aspect_on_both_axes {
            self.warn(LayoutWarning::AspectRatioOnBothAxes { node: i });
        }
        #[cfg(feature = "incremental")]
        if matches!(children_layout, ChildrenLayout::Block | ChildrenLayout::Wrap { .. }) {
            self.layout_data().has_flow = true;
        }

        let mut n_placed_children = 0;
        let mut n_nodes = 1;
        let mut flags = 0;
        let mut next = self.first_child(i);
        while let Some(child) = next {
            next = self.next_sibling(child);
            let params = self.node_layout_params(child);
            // Ordinary leaves need only their own slots initialized. Keep them in the sibling loop.
            let (child_nodes, needs_solve) = if block_children.is_none() && !params.disabled
                && matches!(params.children_layout, ChildrenLayout::Free | ChildrenLayout::Stack { .. })
                && self.first_child(child).is_none()
                && !matches!(params.size, Xy { x: Size::AspectRatio(_), y: Size::AspectRatio(_) })
            {
                let mut data = NodeLayoutData::new();
                let fixed = data.seed_pixels(params, false, None);
                self.node_layout_data_mut(child).reset_leaf(data, fixed);
                (1, !fixed)
            } else {
                self.prepare(child, block_children)
            };
            n_nodes += child_nodes;
            if needs_solve {
                flags |= NodeFlags::DESCENDANTS_NEED_SOLVE;
            }
            let params = self.node_layout_params(child);
            if ! params.disabled && ! params.free_placement {
                n_placed_children += 1;
                if params.size.x.is_flex() {
                    flags |= NodeFlags::FLEX_CHILD_X;
                }
                if params.size.y.is_flex() {
                    flags |= NodeFlags::FLEX_CHILD_Y;
                }
                if params.grid_span.x > 1 || params.grid_span.y > 1 {
                    flags |= NodeFlags::GRID_SPANS;
                }
            }
        }
        let params = self.node_layout_params(i);
        let mut data = NodeLayoutData::new();
        data.n_placed_children = n_placed_children;
        data.flags.0 = flags;
        if let Some(auto_height) = block_parent {
            data.flags.0 |= NodeFlags::BLOCK_ITEM;
            if auto_height {
                data.flags.0 |= NodeFlags::BLOCK_PARENT_AUTO_HEIGHT;
            }
        }
        if block_children.is_some() {
            data.flags.0 |= NodeFlags::BLOCK_CONTAINER;
        }
        if matches!(children_layout, ChildrenLayout::Wrap { .. }) {
            data.flags.0 |= NodeFlags::WRAP_CONTAINER;
        }
        let width_grid_axis = match children_layout {
            ChildrenLayout::Grid { columns: MainAxisCellSize::Width(_), main_axis, .. } => Some(main_axis),
            _ => None,
        };
        let both_axes_fixed = data.seed_pixels(params, block_parent.is_some(), width_grid_axis);
        *self.node_layout_data_mut(i) = data;

        if let ChildrenLayout::Grid { columns: MainAxisCellSize::Count(n), main_axis, backfill, .. } = children_layout {
            self.assign_grid_cells(i, (n as usize).max(1), main_axis, backfill);
        }
        let needs_solve = !both_axes_fixed
            || data.flags.0 & (NodeFlags::DESCENDANTS_NEED_SOLVE | NodeFlags::BLOCK_CONTAINER | NodeFlags::WRAP_CONTAINER) != 0;
        (n_nodes, needs_solve)
    }

    #[inline(always)]
    fn width_grid_main_axis(&self, i: Self::NodeId) -> Option<Axis> {
        match self.node_layout_params(i).children_layout {
            ChildrenLayout::Grid { columns: MainAxisCellSize::Width(_), main_axis, .. } => Some(main_axis),
            _ => None,
        }
    }

    fn solve_all_dependencies(&mut self, slot: Slot<Self::NodeId>) {
        let Slot { node: i, axis, kind } = slot;
        match kind {
            Kind::Final => {
                for kind in DECLARED_SIZES {
                    if self.read_size(i, axis, kind).is_some() {
                        self.solve_slot(i, axis, kind);
                    }
                }
            }
            Kind::EvenShare => {
                self.solve_slot(i, axis, Kind::Final);
                for_each_layout_child!(self, i, child, {
                    if self.node_layout_params(child).free_placement {
                        // Nothing
                    } else if self.any_size_is_fill(child, axis) {
                        for kind in DECLARED_SIZES {
                            if let Some(size) = self.read_size(child, axis, kind) && ! size.is_fill() {
                                self.solve_slot(child, axis, kind);
                            }
                        }
                    } else {
                        self.solve_slot(child, axis, Kind::Final);
                    }
                });
            }
            Kind::Flow => self.solve_flow_dependencies(i),
            declared => match self.read_size(i, axis, declared).unwrap() {
                Size::Pixels(_) => {}
                Size::AspectRatio(_) => self.solve_slot(i, axis.other(), Kind::Final),
                Size::Frac(_) => self.read_available_from_parent(slot),
                Size::Fill => {
                    if let Some(parent) = self.stack_parent(i, axis) {
                        self.solve_slot(parent, axis, Kind::EvenShare);
                    } else {
                        self.read_available_from_parent(slot)
                    }
                }
                Size::FitContent => {
                    match self.node_layout_params(i).children_layout {
                        ChildrenLayout::Block if axis == Y => self.solve_slot(i, Y, Kind::Flow),
                        ChildrenLayout::Wrap { axis: main, .. } if main != axis => self.solve_slot(i, axis, Kind::Flow),
                        _ => for_each_layout_child!(self, i, child, {
                            if ! self.node_layout_params(child).free_placement {
                                self.solve_intrinsic_child(child, axis);
                            }
                        }),
                    }
                    if self.text_wraps(i, axis) {
                        self.solve_slot(i, X, Kind::Final);
                    }
                    if self.node_layout_params(i).content_measure.reads_other_axis(axis) {
                        self.solve_slot(i, axis.other(), Kind::Final);
                    }

                    if let Some(main) = self.width_grid_main_axis(i) && main != axis {
                        self.solve_slot(i, main, Kind::Final);
                    }
                }
                Size::Auto => unreachable!("read_size resolves Auto"),
            },
        }
    }

    #[inline]
    fn solve_intrinsic_child(&mut self, child: Self::NodeId, axis: Axis) {
        for kind in DECLARED_SIZES {
            if let Some(size) = self.read_size(child, axis, kind) && !size.is_flex() {
                self.solve_slot(child, axis, kind);
            }
        }
    }

    fn solve_flow_dependencies(&mut self, i: Self::NodeId) {
        let wrap_axis = match self.node_layout_params(i).children_layout {
            ChildrenLayout::Wrap { axis, .. } => {
                self.solve_slot(i, axis, Kind::EvenShare);
                Some(axis)
            }
            ChildrenLayout::Block => None,
            _ => unreachable!(),
        };
        for_each_layout_child!(self, i, child, {
            if !self.node_layout_params(child).free_placement {
                if let Some(main) = wrap_axis {
                    self.solve_slot(child, main, Kind::Final);
                    self.solve_intrinsic_child(child, main.other());
                } else {
                    self.solve_slot(child, Y, Kind::Final);
                    if self.node_layout_data(child).flags.0 & NodeFlags::BLOCK_CONTAINER != 0 {
                        self.solve_slot(child, Y, Kind::Flow);
                    }
                }
            }
        });
    }

    /// Solves what `available_from_parent` reads. The root reads the window size, which is an input.
    #[inline(always)]
    fn read_available_from_parent(&mut self, slot: Slot<Self::NodeId>) {
        let i = slot.node;
        let Some(parent) = self.parent(i) else {
            return;
        };
        if !self.node_layout_params(i).free_placement
            && let ChildrenLayout::Wrap { axis, .. } = self.node_layout_params(parent).children_layout
            && axis != slot.axis
        {
            self.solve_slot(parent, slot.axis, Kind::Flow);
            return;
        }
        self.solve_slot(parent, slot.axis, Kind::Final);
        if ! self.node_layout_params(i).free_placement && let Some(main) = self.width_grid_main_axis(parent) {
            self.solve_slot(parent, main, Kind::Final);
        }
    }

    fn measure_sizes(&mut self, window_size: Xy<f32>) {
        self.layout_data().window_size = window_size;
        self.layout_data().block_margins.clear();
        #[cfg(feature = "incremental")]
        {
            let data = self.layout_data();
            data.has_cycle = false;
            data.has_flow = false;
            data.pending_full_solve = None;
        }
        let _summary = self.prepare(self.root(), None);
        #[cfg(feature = "incremental")]
        {
            self.layout_data().n_nodes_solved = _summary.0;
        }
        self.solve();
    }

    fn solve(&mut self) {
        let mut next = Some(self.root());
        while let Some(node) = next {
            let flags = self.node_layout_data(node).flags;
            if flags == NodeFlags::EMPTY && self.node_layout_params(node).disabled {
                next = self.traversal_next(node, false);
                continue;
            }
            if flags.check_state(X, Kind::Final) != SOLVED {
                self.solve_slot(node, X, Kind::Final);
            }
            if flags.check_state(Y, Kind::Final) != SOLVED {
                self.solve_slot(node, Y, Kind::Final);
            }
            if flags.0 & NodeFlags::BLOCK_CONTAINER != 0 {
                self.solve_slot(node, Y, Kind::Flow);
            }
            if flags.0 & NodeFlags::WRAP_CONTAINER != 0 {
                let axis = self.stack_axis(node).unwrap();
                self.solve_slot(node, axis, Kind::EvenShare);
            }
            let descend = flags.0 & NodeFlags::DESCENDANTS_NEED_SOLVE != 0 && !self.solve_fill_items(node);
            next = self.traversal_next(node, descend);
        }
    }

    /// Resolves a complete stack of unbounded fill items in sibling order when
    /// the cross axis and all deeper descendants are already measured.
    fn solve_fill_items(&mut self, node: Self::NodeId) -> bool {
        let ChildrenLayout::Stack { axis, .. } = self.node_layout_params(node).children_layout else {
            return false;
        };
        let flags = self.node_layout_data(node).flags;
        if flags.0 & NodeFlags::flex_child(axis) == 0 || flags.check_state(axis, Kind::EvenShare) != UNSOLVED {
            return false;
        }
        let first = self.first_child(node);
        let own = inner(self.get_solved_value(node, axis, Kind::Final), self.total_padding(node, axis));
        let mut budget = (own - self.stack_gaps(node, axis)).max(0.0);
        let mut total_weight = 0.0;
        for_each_layout_child!(@from self, first, child, {
            let params = self.node_layout_params(child);
            let flags = self.node_layout_data(child).flags;
            if params.free_placement || params.size[axis] != Size::Fill || params.min_size[axis].is_some() || params.max_size[axis].is_some()
                || flags.check_state(axis.other(), Kind::Final) != SOLVED
                || flags.0 & (NodeFlags::DESCENDANTS_NEED_SOLVE | NodeFlags::BLOCK_CONTAINER | NodeFlags::WRAP_CONTAINER) != 0
                || self.width_grid_main_axis(child) == Some(axis)
            {
                return false;
            }
            let [start, end] = margins(params, axis);
            budget -= start + end;
            total_weight += params.fill_weight;
        });
        // With no size bounds every item accepts its weighted share on the first pass.
        let share = if total_weight > 0.0 { budget.max(0.0) / total_weight } else { 0.0 };
        let data = self.node_layout_data_mut(node);
        data.values[slot_index(axis, Kind::EvenShare)] = share;
        data.flags.set_state(axis, Kind::EvenShare, SOLVED);
        #[cfg(feature = "incremental")]
        let share_level = {
            let level = data.levels[slot_index(axis, Kind::Final)] + 1;
            data.levels[slot_index(axis, Kind::EvenShare)] = level;
            level
        };
        for_each_layout_child!(@from self, first, child, {
            let value = share * self.node_layout_params(child).fill_weight;
            if !value.is_finite() {
                self.warn(LayoutWarning::NotFinite { node: child, axis });
            }
            let data = self.node_layout_data_mut(child);
            for kind in [Kind::Regular, Kind::Final] {
                data.values[slot_index(axis, kind)] = value;
                data.flags.set_state(axis, kind, SOLVED);
            }
            #[cfg(feature = "incremental")]
            {
                data.levels[slot_index(axis, Kind::Regular)] = share_level + 1;
                data.levels[slot_index(axis, Kind::Final)] = share_level + 2;
            }
        });
        true
    }

    fn solve_slot(&mut self, node: Self::NodeId, axis: Axis, kind: Kind) {
        let slot = Slot { node, axis, kind };
        match self.node_layout_data(node).flags.check_state(axis, kind) {
            SOLVED => {
                #[cfg(feature = "incremental")]
                {
                    let level = self.node_layout_data(node).levels[slot_index(axis, kind)];
                    let data = self.layout_data();
                    data.current_level = data.current_level.max(level + 1);
                }
                return;
            }
            IN_PROGRESS => {
                #[cfg(feature = "incremental")]
                {
                    self.layout_data().has_cycle = true;
                }
                self.record_cycle(node, axis);
                return;
            }
            _ => {}
        }
        self.node_layout_data_mut(node).flags.set_state(axis, kind, IN_PROGRESS);
        #[cfg(feature = "incremental")]
        let outer = std::mem::replace(&mut self.layout_data().current_level, 0);
        self.solve_all_dependencies(slot);
        self.finish_slot(slot);
        #[cfg(feature = "incremental")]
        {
            let level = self.layout_data().current_level;
            self.layout_data().current_level = outer.max(level + 1);
            self.node_layout_data_mut(node).levels[slot_index(axis, kind)] = level;
        }
    }

    /// Computes the value of a slot whose dependencies are solved, and marks it as solved.
    fn finish_slot(&mut self, slot: Slot<Self::NodeId>) {
        let Slot { node, axis, kind } = slot;
        let size = self.solve_slot_inner(slot);
        if kind == Kind::Final && ! size.is_finite() {
            self.warn(LayoutWarning::NotFinite { node, axis });
        }
        let data = self.node_layout_data_mut(node);
        data.values[slot_index(axis, kind)] = size;
        data.flags.set_state(axis, kind, SOLVED);
        if kind == Kind::Final && self.width_grid_main_axis(node) == Some(axis) {
            self.assign_width_grid_cells(node);
        }
    }

    /// Keeps the user's callback out of the hot code.
    #[cold]
    #[inline(never)]
    fn warn(&mut self, warning: LayoutWarning<Self::NodeId>) {
        self.layout_warning(warning);
    }

    #[cold]
    #[inline(never)]
    fn record_cycle(&mut self, node: Self::NodeId, axis: Axis) {
        let flags = &mut self.node_layout_data_mut(node).flags;
        if flags.0 & NodeFlags::in_cycle(axis) == 0 {
            flags.0 |= NodeFlags::in_cycle(axis);
            self.layout_warning(LayoutWarning::Cycle { node, axis });
        }
    }

    #[inline(always)]
    fn get_solved_value(&self, i: Self::NodeId, axis: Axis, kind: Kind) -> f32 {
        let data = self.node_layout_data(i);
        debug_assert!(data.flags.check_state(axis, kind) != UNSOLVED, "Slot {axis:?} {kind:?} of node {i:?} read before it is solved.");
        data.values[slot_index(axis, kind)]
    }

    fn solve_slot_inner(&mut self, slot: Slot<Self::NodeId>) -> f32 {
        let i = slot.node;
        let axis = slot.axis;
        match slot.kind {
            Kind::Final => {
                let (min, max) = self.solved_bounds(i, axis, |_| false);
                if let (Some(min), Some(max)) = (min, max) && min > max {
                    self.warn(LayoutWarning::MinAboveMax { node: i, axis });
                }
                let mut size = clamp(self.get_solved_value(i, axis, Kind::Regular), min, max);
                let flags = self.node_layout_data(i).flags;
                if flags.is_block_item() {
                    size = size.max(self.total_padding(i, axis));
                }
                let has_flex_child = flags.0 & NodeFlags::flex_child(axis) != 0;
                if has_flex_child && size <= self.total_padding(i, axis)
                    && self.node_layout_params(i).size[axis] == Size::FitContent
                    && !matches!(self.node_layout_params(i).children_layout, ChildrenLayout::Block | ChildrenLayout::Wrap { .. })
                {
                    self.warn(LayoutWarning::FitContentCollapsed { node: i, axis });
                }
                size
            }
            Kind::EvenShare => self.solve_even_share(i, axis),
            Kind::Flow => self.solve_flow(i),
            declared => match self.read_size(i, axis, declared).unwrap() {
                Size::Pixels(pixels) => pixels,
                Size::AspectRatio(aspect) => {
                    let other = self.get_solved_value(i, axis.other(), Kind::Final);
                    match axis {
                        X => other * aspect,
                        Y => other / aspect,
                    }
                }
                Size::FitContent => self.solve_fitcontent(i, axis),
                Size::Frac(frac) => self.available_from_parent(i, axis, false) * frac,

                Size::Fill => {
                    if let Some(parent) = self.stack_parent(i, axis) {
                        let share = if self.node_layout_data(parent).flags.0 & NodeFlags::WRAP_CONTAINER == 0 {
                            self.get_solved_value(parent, axis, Kind::EvenShare)
                        } else {
                            self.node_layout_data(i).wrap_line_metric()
                        };
                        share * self.node_layout_params(i).fill_weight
                    } else {
                        self.available_from_parent(i, axis, true)
                    }
                },
                Size::Auto => unreachable!("read_size resolves Auto"),
            },
        }
    }

    #[inline(always)]
    fn solved_bounds(&self, i: Self::NodeId, axis: Axis, ignore_bounds_rule: impl Fn(Size) -> bool) -> (Option<f32>, Option<f32>) {
        let min = if let Some(bound) = self.read_size(i, axis, Kind::Min) && ! ignore_bounds_rule(bound) {
            Some(self.get_solved_value(i, axis, Kind::Min))
        } else { None };
        let max = if let Some(bound) = self.read_size(i, axis, Kind::Max) && ! ignore_bounds_rule(bound) {
            Some(self.get_solved_value(i, axis, Kind::Max))
        } else { None };
        (min, max)
    }

    fn available_from_parent(&mut self, i: Self::NodeId, axis: Axis, fill: bool) -> f32 {
        let Some(parent) = self.parent(i) else {
            return self.layout_data().window_size[axis];
        };
        let params = self.node_layout_params(i);
        let children_layout = self.node_layout_params(parent).children_layout;
        let subtract_margin = |size: f32| {
            if !fill || params.free_placement || children_layout == ChildrenLayout::Free {
                return size;
            }
            let [start, end] = margins(params, axis);
            let margin = start + end;
            if margin == 0.0 { size } else { (size - margin).max(0.0) }
        };
        if !params.free_placement
            && let ChildrenLayout::Wrap { axis: main, .. } = children_layout
            && main != axis
        {
            let extent = if self.node_layout_data(parent).flags.check_state(axis, Kind::Flow) == SOLVED {
                self.node_layout_data(i).wrap_line_metric()
            } else {
                0.0
            };
            return subtract_margin(extent);
        }
        let inner = inner(self.get_solved_value(parent, axis, Kind::Final), self.total_padding(parent, axis));
        if params.free_placement {
            return inner;
        }
        let available = match children_layout {
            ChildrenLayout::Grid { spacing_x, spacing_y, .. } => {
                let spacing = Xy::new(spacing_x, spacing_y)[axis];
                let n = self.node_layout_data(parent).grid_lines()[axis] as f32;
                let cell = ((inner - spacing * (n - 1.0)) / n.max(1.0)).max(0.0);
                let span = (self.node_layout_params(i).grid_span[axis].max(1) as f32).min(n.max(1.0));
                span * cell + (span - 1.0) * spacing
            }
            ChildrenLayout::Stack { axis: stack_axis, .. } if stack_axis == axis => {
                (inner - self.stack_gaps(parent, axis)).max(0.0)
            }
            _ => inner,
        };
        subtract_margin(available)
    }

    fn solve_flow(&mut self, i: Self::NodeId) -> f32 {
        match self.node_layout_params(i).children_layout {
            ChildrenLayout::Wrap { axis, spacing, line_spacing, .. } => {
                let mut next = self.first_child(i);
                let mut extent = 0.0;
                while next.is_some() {
                    let line = self.wrap_line(next, axis, None, spacing);
                    while next != line.next {
                        let child = next.unwrap();
                        if !self.node_layout_params(child).disabled && !self.node_layout_params(child).free_placement {
                            // Main-axis slots are now solved. Cross-axis readers can reuse the line's storage.
                            self.node_layout_data_mut(child).parent_flow = line.cross.to_bits();
                        }
                        next = self.next_sibling(child);
                    }
                    extent += line.cross;
                    if next.is_some() {
                        extent += line_spacing;
                    }
                }
                extent
            }
            ChildrenLayout::Block => {
                let mut flow = self.block_flow(i);
                for_each_layout_child!(self, i, child, {
                    if !self.node_layout_params(child).free_placement {
                        flow.push(self.block_item(child));
                    }
                });
                let (height, margins) = flow.finish();
                let layout = self.node_layout_data(i);
                if layout.flags.is_block_item() && !margins.is_implicit(layout) {
                    let storage = &mut self.layout_data().block_margins;
                    storage.push(margins);
                    let index = u32::try_from(storage.len()).expect("too many block containers");
                    self.node_layout_data_mut(i).children_flow = index;
                }
                height
            }
            _ => unreachable!(),
        }
    }

    fn solve_fitcontent(&mut self, i: Self::NodeId, axis: Axis) -> f32 {
        let (children, gaps) = match self.node_layout_params(i).children_layout {
            ChildrenLayout::Grid { columns, spacing_x, spacing_y, main_axis, .. } => {
                let spacing = Xy::new(spacing_x, spacing_y)[axis];
                let (n, cell) = match columns {
                    MainAxisCellSize::Width(w) if axis == main_axis => (1.0, w),
                    _ => {
                        let n = self.node_layout_data(i).grid_lines()[axis] as f32;
                        let mut cell = 0.0f32;
                        for_each_layout_child!(self, i, child, {
                            if ! self.node_layout_params(child).free_placement {
                                let span = (self.node_layout_params(child).grid_span[axis].max(1) as f32).min(n.max(1.0));
                                let [start, end] = margins(self.node_layout_params(child), axis);
                                let extent = with_margin(self.pre_grow_size(child, axis), start + end);
                                cell = cell.max((extent - (span - 1.0) * spacing) / span);
                            }
                        });
                        (n, cell)
                    }
                };
                ((n * cell + spacing * (n - 1.0)).max(0.0), 0.0)
            }
            ChildrenLayout::Stack { axis: stack_axis, .. } | ChildrenLayout::Wrap { axis: stack_axis, .. } if stack_axis == axis => {
                (self.fit_stack_main(i, axis), self.stack_gaps(i, axis))
            }
            ChildrenLayout::Block if axis == Y => (self.get_solved_value(i, axis, Kind::Flow), 0.0),
            ChildrenLayout::Wrap { .. } => (self.get_solved_value(i, axis, Kind::Flow), 0.0),
            layout => {
                let mut biggest = 0.0f32;
                for_each_layout_child!(self, i, child, {
                    if ! self.node_layout_params(child).free_placement {
                        let size = self.pre_grow_size(child, axis);
                        let extent = if layout == ChildrenLayout::Free {
                            size
                        } else {
                            let [start, end] = margins(self.node_layout_params(child), axis);
                            with_margin(size, start + end)
                        };
                        biggest = biggest.max(extent);
                    }
                });
                (biggest, 0.0)
            }
        };

        let mut own_content = match self.node_layout_params(i).text {
            TextContent::None => 0.0,
            _ if self.text_wraps(i, axis) => {
                let width = inner(self.get_solved_value(i, X, Kind::Final), self.total_padding(i, X));
                self.measure_text_height(i, Some(width))
            }
            _ => match axis {
                X => self.measure_text_width(i),
                Y => self.measure_text_height(i, None),
            },
        };
        if let Some(image) = self.node_layout_params(i).image {
            own_content = own_content.max(image[axis]);
        }
        if self.node_layout_params(i).content_measure != ContentMeasure::None {
            let measured = self.custom_intrinsic_size(i, axis);
            own_content = own_content.max(measured);
        }

        children.max(own_content) + gaps + self.total_padding(i, axis)
    }

    fn custom_intrinsic_size(&mut self, i: Self::NodeId, axis: Axis) -> f32 {
        let params = self.node_layout_params(i);
        let mut known_dimensions = Xy::new_symm(None);
        if params.content_measure.reads_other_axis(axis) {
            let other = axis.other();
            known_dimensions[other] = Some(inner(self.get_solved_value(i, other, Kind::Final), self.total_padding(i, other)));
        }
        let pixel_max = |axis| match params.max_size[axis] {
            Some(Size::Pixels(pixels)) => Some(inner(pixels, self.total_padding(i, axis))),
            _ => None,
        };
        let max_size = Xy::new(pixel_max(X), pixel_max(Y));
        self.measure_content(i, ContentMeasureInput { axis, known_dimensions, max_size })[axis]
    }

    fn fit_stack_main(&mut self, i: Self::NodeId, axis: Axis) -> f32 {
        let mut estimate = 0.0f32;
        let mut overflow = false;
        for _ in 0..MAX_FIT_STACK_STEPS {
            let mut fixed = 0.0f32;
            let mut free_frac = 0.0f32;
            let mut has_frac = false;
            for_each_layout_child!(self, i, child, {
                if self.node_layout_params(child).free_placement {
                    // Nothing
                } else if let Some(Size::Frac(frac)) = self.read_size(child, axis, Kind::Regular) {
                    let [start, end] = margins(self.node_layout_params(child), axis);
                    fixed += start + end;
                    has_frac = true;
                    let wanted = estimate * frac;
                    let (min, max) = self.solved_bounds(child, axis, |bound| bound.is_flex());
                    let allowed = clamp(wanted, min, max);
                    match allowed == wanted {
                        true => free_frac += frac,
                        false => fixed += allowed,
                    }
                } else {
                    let [start, end] = margins(self.node_layout_params(child), axis);
                    fixed += with_margin(self.pre_grow_size(child, axis), start + end);
                }
            });

            if ! has_frac {
                return fixed;
            }

            let next = match free_frac <= MAX_FIT_STACK_FRAC {
                true => fixed / (1.0 - free_frac),
                false => {
                    overflow = true;
                    fixed
                }
            };
            let settled = (next - estimate).abs() <= FIT_STACK_EPSILON * next.abs().max(1.0);
            estimate = next;
            if settled {
                break;
            }
        }
        if overflow {
            self.warn(LayoutWarning::ImpossibleFracChildren { node: i, axis });
        }
        estimate
    }

    #[inline(always)]
    fn pre_grow_size(&self, child: Self::NodeId, axis: Axis) -> f32 {
        let size = match self.read_size(child, axis, Kind::Regular).unwrap() {
            Size::Fill | Size::Frac(_) => 0.0,
            _ => self.get_solved_value(child, axis, Kind::Regular),
        };
        let (min, max) = self.solved_bounds(child, axis, |bound| bound.is_flex());
        clamp(size, min, max)
    }

    fn solve_even_share(&mut self, i: Self::NodeId, axis: Axis) -> f32 {
        let own = inner(self.get_solved_value(i, axis, Kind::Final), self.total_padding(i, axis));
        let first = self.first_child(i);
        if let ChildrenLayout::Wrap { spacing, .. } = self.node_layout_params(i).children_layout {
            let mut first = first;
            while first.is_some() {
                let line = self.wrap_line(first, axis, Some(own), spacing);
                if let Some(next) = line.next {
                    self.node_layout_data_mut(next).flags.0 |= NodeFlags::WRAP_LINE_START;
                }
                if line.has_fill {
                    let gaps = spacing * line.count.saturating_sub(1) as f32;
                    let share = self.distribute_fill(axis, (own - gaps).max(0.0), first, line.next);
                    while first != line.next {
                        let child = first.unwrap();
                        if !self.node_layout_params(child).disabled && !self.node_layout_params(child).free_placement {
                            self.node_layout_data_mut(child).parent_flow = share.to_bits();
                        }
                        first = self.next_sibling(child);
                    }
                }
                first = line.next;
            }
            return 0.0;
        }
        let budget = (own - self.stack_gaps(i, axis)).max(0.0);
        self.distribute_fill(axis, budget, first, None)
    }

    fn wrap_fill_base(&self, child: Self::NodeId, axis: Axis) -> f32 {
        let content = if self.read_size(child, axis, Kind::Regular) == Some(Size::Fill) {
            0.0
        } else {
            self.get_solved_value(child, axis, Kind::Regular)
        };
        let (min, max) = self.solved_bounds(child, axis, |bound| bound.is_fill());
        clamp(content, min, max)
    }

    fn distribute_fill(
        &mut self,
        axis: Axis,
        mut budget: f32,
        mut next: Option<Self::NodeId>,
        end: Option<Self::NodeId>,
    ) -> f32 {

        let mut fills = Vec::new();
        let mut inline = [FillChild::default(); 8];
        let mut fill_count = 0;
        let mut unfrozen_weight = 0.0;
        let mut max_unconstrained_weight = None::<f32>;
        while next != end {
            let child = next.unwrap();
            next = self.next_sibling(child);
            let node = self.node_layout_params(child);
            if node.free_placement || node.disabled {
                // Nothing
            } else {
                let [start, end] = margins(node, axis);
                budget -= start + end;
                if self.any_size_is_fill(child, axis) {
                    let content = if self.read_size(child, axis, Kind::Regular) != Some(Size::Fill) {
                        Some(self.get_solved_value(child, axis, Kind::Regular))
                    } else { None };
                    let weight = node.fill_weight;
                    unfrozen_weight += weight;
                    let (min, max) = self.solved_bounds(child, axis, |bound| bound.is_fill());
                    if content.is_none() && min.is_none() && max.is_none() {
                        let abs_weight = if weight.is_nan() { f32::INFINITY } else { weight.abs() };
                        max_unconstrained_weight = Some(max_unconstrained_weight.map_or(abs_weight, |current| current.max(abs_weight)));
                    } else {
                        let capped_by_content = content.is_some() && self.read_size(child, axis, Kind::Max) == Some(Size::Fill);
                        let fill = FillChild::new(content, min, max, capped_by_content, weight);
                        if fill_count < inline.len() {
                            inline[fill_count] = fill;
                        } else {
                            if fill_count == inline.len() {
                                fills = std::mem::take(&mut self.layout_data().fills_scratch);
                                fills.reserve(2 * inline.len());
                                fills.extend_from_slice(&inline);
                            }
                            fills.push(fill);
                        }
                        fill_count += 1;
                    }
                } else {
                    budget -= self.get_solved_value(child, axis, Kind::Final);
                }
            }
        }

        let budget = budget.max(0.0);
        if fill_count <= inline.len() {
            return resolve_fill_share(&mut inline[..fill_count], budget, unfrozen_weight, max_unconstrained_weight);
        }
        let share = resolve_fill_share(&mut fills, budget, unfrozen_weight, max_unconstrained_weight);
        fills.clear();
        self.layout_data().fills_scratch = fills;
        share
    }

    /// Assigns the cells of a grid with `MainAxisCellSize::Width` columns, from its `Final` size on the main axis.
    fn assign_width_grid_cells(&mut self, i: Self::NodeId) {
        let ChildrenLayout::Grid { columns: MainAxisCellSize::Width(w), spacing_x, spacing_y, main_axis: main, backfill } = self.node_layout_params(i).children_layout else {
            unreachable!();
        };
        let spacing = Xy::new(spacing_x, spacing_y)[main];
        let inner_main = inner(self.get_solved_value(i, main, Kind::Final), self.total_padding(i, main));
        let n_main = ((inner_main + spacing) / (w + spacing)).floor().max(1.0) as usize;
        self.assign_grid_cells(i, n_main, main, backfill);
    }

    fn assign_grid_cells(&mut self, i: Self::NodeId, n_main: usize, main_axis: Axis, backfill: bool) {
        let has_spans = self.node_layout_data(i).flags.0 & NodeFlags::GRID_SPANS != 0;
        let n_lines = if ! has_spans {
            self.assign_grid_cells_in_order(i, n_main, main_axis)
        } else {
            self.assign_grid_cells_with_spans(i, n_main, main_axis, backfill)
        };

        let mut lines = Xy::new(0, 0);
        lines[main_axis] = n_main as u16;
        lines[main_axis.other()] = n_lines as u16;
        self.node_layout_data_mut(i).children_flow = pack_counts(lines);
    }

    /// Without spans, the children go into predictable positions and `backfill` has no effect, because there are no holes.
    fn assign_grid_cells_in_order(&mut self, i: Self::NodeId, n_main: usize, main_axis: Axis) -> usize {
        let mut line = 0;
        let mut pos = 0;
        for_each_layout_child!(self, i, child, {
            if ! self.node_layout_params(child).free_placement {
                let mut cell = Xy::new(0, 0);
                cell[main_axis] = pos as u16;
                cell[main_axis.other()] = line as u16;
                self.node_layout_data_mut(child).parent_flow = pack_counts(cell);
                pos += 1;
                if pos == n_main {
                    line += 1;
                    pos = 0;
                }
            }
        });
        line + usize::from(pos != 0)
    }

    fn assign_grid_cells_with_spans(&mut self, i: Self::NodeId, n_main: usize, main_axis: Axis, backfill: bool) -> usize {
        let mut occupied = std::mem::take(&mut self.layout_data().occupied_scratch);
        // Start each row on a word boundary so the same masks apply to every row of a span.
        let words_per_line = n_main.div_ceil(GRID_WORD_BITS);
        if backfill {
            // Each in-flow child occupies at least one cell, including children with spans.
            let min_rows = (self.node_layout_data(i).n_placed_children as usize).div_ceil(n_main);
            occupied.reserve(min_rows * words_per_line);
        }
        let mut n_lines = 0;
        let mut cursor = (0, 0);
        let mut first_stored_line = 0;
        // Occupancy only grows. Repeated small spans can resume at their last fit.
        const CACHED_SPANS: usize = 8;
        let mut first_fit = [[0usize; CACHED_SPANS]; CACHED_SPANS];

        for_each_layout_child!(self, i, child, {
            if ! self.node_layout_params(child).free_placement {
                let span = self.node_layout_params(child).grid_span;
                let span_pos = (span[main_axis].max(1) as usize).min(n_main);
                let span_line = span[main_axis.other()].max(1) as usize;

                let start = if backfill {
                    let line = first_fit[span_line.min(CACHED_SPANS) - 1][span_pos.min(CACHED_SPANS) - 1];
                    (line, 0)
                } else {
                    (cursor.0 - first_stored_line, cursor.1)
                };
                let (relative_line, pos) = find_grid_cell(&occupied, n_main, words_per_line,
                    n_lines - first_stored_line, start, span_line, span_pos);
                let line = first_stored_line + relative_line;

                let end_line = line + span_line;
                if end_line > n_lines {
                    occupied.resize((end_line - first_stored_line) * words_per_line, 0);
                    n_lines = end_line;
                }
                let rows = relative_line * words_per_line..(end_line - first_stored_line) * words_per_line;
                GridColumns::new(pos, span_pos).occupy(&mut occupied[rows], words_per_line);
                if backfill {
                    if span_line <= CACHED_SPANS && span_pos <= CACHED_SPANS {
                        first_fit[span_line - 1][span_pos - 1] = line;
                    }
                } else {
                    cursor = (line, pos + span_pos);
                    // Everything before the cursor is unreachable. Compact only once the
                    // discarded prefix is at least as large as the live rows being moved.
                    if relative_line >= n_lines - line {
                        let prefix = relative_line * words_per_line;
                        occupied.copy_within(prefix.., 0);
                        occupied.truncate(occupied.len() - prefix);
                        first_stored_line = line;
                    }
                }

                let mut cell = Xy::new(0, 0);
                cell[main_axis] = pos as u16;
                cell[main_axis.other()] = line as u16;
                self.node_layout_data_mut(child).parent_flow = pack_counts(cell);
            }
        });
        occupied.clear();
        self.layout_data().occupied_scratch = occupied;
        n_lines
    }

    #[inline(always)]
    fn total_padding(&self, i: Self::NodeId, axis: Axis) -> f32 {
        let [start, end] = self.node_layout_params(i).padding[axis];
        start + end
    }

    #[inline(always)]
    fn stack_gaps(&self, i: Self::NodeId, axis: Axis) -> f32 {
        let (ChildrenLayout::Stack { axis: stack_axis, spacing, .. } | ChildrenLayout::Wrap { axis: stack_axis, spacing, .. }) = self.node_layout_params(i).children_layout else {
            return 0.0;
        };
        if stack_axis != axis {
            return 0.0;
        }
        let n = self.node_layout_data(i).n_placed_children as f32;
        spacing * (n - 1.0).max(0.0)
    }
}

impl<T: TreeAdapter + ?Sized> Solve for T {}

fn resolve_fill_share(fills: &mut [FillChild], budget: f32, mut unfrozen_weight: f32, max_unconstrained_weight: Option<f32>) -> f32 {
    let mut active = fills;
    let mut frozen_total = 0.0;
    let mut share = 0.0;

    while !active.is_empty() || max_unconstrained_weight.is_some() {
        share = if unfrozen_weight > 0.0 { (budget - frozen_total) / unfrozen_weight } else { 0.0 };
        if active.is_empty() {
            break;
        }
        // Unconstrained children never freeze. Their target minus itself is zero
        // for finite targets and NaN otherwise.
        let mut total_violation = if max_unconstrained_weight.is_some_and(|weight| !(share * weight).is_finite()) {
            f32::NAN
        } else {
            0.0
        };
        for child in active.iter() {
            let target = share * child.weight;
            total_violation += child.size(target) - target;
        }
        if total_violation.abs() < EVEN_SHARE_EPSILON {
            break;
        }

        // Retain the active constraints in order so subsequent sums use the same rounding.
        let mut remaining = 0;
        for i in 0..active.len() {
            let child = active[i];
            let target = share * child.weight;
            let size = child.size(target);
            let stuck = if total_violation > 0.0 {
                size - target > EVEN_SHARE_EPSILON
            } else {
                size - target < -EVEN_SHARE_EPSILON
            };
            if stuck {
                frozen_total += size;
                unfrozen_weight -= child.weight;
            } else {
                active[remaining] = child;
                remaining += 1;
            }
        }
        if remaining == active.len() {
            break;
        }
        active = &mut active[..remaining];
    }
    share
}

const GRID_WORD_BITS: usize = u64::BITS as usize;

fn find_grid_cell(
    occupied: &[u64],
    n_main: usize,
    words_per_line: usize,
    n_lines: usize,
    (mut line, mut pos): (usize, usize),
    span_line: usize,
    span_pos: usize,
) -> (usize, usize) {
    let last_start = n_main - span_pos;
    loop {
        if pos > last_start {
            line += 1;
            pos = 0;
        }
        if line >= n_lines {
            return (line, pos);
        }
        let rows = &occupied[line * words_per_line..(line + span_line).min(n_lines) * words_per_line];
        if words_per_line == 1 {
            // Collapse the spanned rows before testing all candidate columns in parallel.
            let blocked = rows.iter().fold(0, |blocked, &row| blocked | row);
            let starts = open_grid_starts(!blocked, span_pos) & (u64::MAX << pos);
            let next = starts.trailing_zeros() as usize;
            if next <= last_start {
                return (line, next);
            }
            line += 1;
            pos = 0;
        } else if let Some(next) = GridColumns::new(pos, span_pos).next_after_collision(rows, words_per_line) {
            pos = next;
        } else {
            return (line, pos);
        }
    }
}

fn open_grid_starts(mut open: u64, span: usize) -> u64 {
    // Each bit represents the start of an open run. Double the run length at each step.
    let mut length = 1;
    while length * 2 <= span {
        open &= open >> length;
        length *= 2;
    }
    open & (open >> (span - length))
}

struct GridColumns {
    first: usize,
    last: usize,
    start_mask: u64,
    end_mask: u64,
}

impl GridColumns {
    fn new(pos: usize, span: usize) -> Self {
        let end = pos + (span - 1);
        Self {
            first: pos / GRID_WORD_BITS,
            last: end / GRID_WORD_BITS,
            start_mask: u64::MAX << (pos % GRID_WORD_BITS),
            end_mask: u64::MAX >> (GRID_WORD_BITS - 1 - end % GRID_WORD_BITS),
        }
    }

    fn next_after_collision(&self, rows: &[u64], words_per_line: usize) -> Option<usize> {
        let Self { first, last, start_mask, end_mask } = *self;
        for row in rows.chunks_exact(words_per_line) {
            let bits = if first == last {
                row[first] & start_mask & end_mask
            } else {
                let end = row[last] & end_mask;
                if end != 0 {
                    return Some(column_after_occupied_run(last, row[last], end));
                }
                if let Some(offset) = row[first + 1..last].iter().rposition(|&bits| bits != 0) {
                    let word = first + 1 + offset;
                    return Some(column_after_occupied_run(word, row[word], row[word]));
                }
                row[first] & start_mask
            };
            if bits != 0 {
                return Some(column_after_occupied_run(first, row[first], bits));
            }
        }
        None
    }

    fn occupy(&self, rows: &mut [u64], words_per_line: usize) {
        let Self { first, last, start_mask, end_mask } = *self;
        if words_per_line == 1 {
            let mask = start_mask & end_mask;
            for word in rows {
                *word |= mask;
            }
            return;
        }
        for row in rows.chunks_exact_mut(words_per_line) {
            if first == last {
                row[first] |= start_mask & end_mask;
            } else {
                row[first] |= start_mask;
                row[first + 1..last].fill(u64::MAX);
                row[last] |= end_mask;
            }
        }
    }
}

fn column_after_occupied_run(word: usize, occupied: u64, collisions: u64) -> usize {
    // A candidate overlapping the last collision cannot start until the next free column.
    let last_collision = GRID_WORD_BITS - 1 - collisions.leading_zeros() as usize;
    let free_after_collision = !occupied & (u64::MAX << last_collision);
    word * GRID_WORD_BITS + free_after_collision.trailing_zeros() as usize
}

#[cfg(test)]
mod tests {
    use super::*;
    use rand::{Rng, SeedableRng, rngs::StdRng};

    #[test]
    fn fixed_leaf_reset_restores_both_slots_and_discards_parent_flow() {
        let params = LayoutParams { size: Xy::new(Size::Pixels(-0.0), Size::Pixels(12.0)), ..LayoutParams::DEFAULT };
        let mut prepared = NodeLayoutData::new();
        assert!(prepared.seed_pixels(&params, false, None));
        let mut leaf = NodeLayoutData::new();
        leaf.reset_leaf(prepared, true);

        for kind in [Kind::Regular, Kind::Final] {
            let slot = slot_index(X, kind);
            leaf.values[slot] = 0.0;
            leaf.reset_leaf(prepared, true);
            assert_eq!(leaf.values[slot].to_bits(), (-0.0f32).to_bits());
        }
        leaf.parent_flow = pack_counts(Xy::new(3, 1));
        leaf.reset_leaf(prepared, true);
        assert_eq!(leaf.parent_flow, 0);
        leaf.flags.0 |= NodeFlags::WRAP_LINE_START;
        leaf.reset_leaf(prepared, true);
        assert!(!leaf.flags.starts_wrap_line());
    }

    #[test]
    fn fill_interval_preserves_content_and_bound_precedence() {
        let bounds = [None, Some(-5.0), Some(0.0), Some(3.0), Some(f32::NEG_INFINITY), Some(f32::INFINITY), Some(f32::NAN)];
        for content in bounds {
            for min in bounds {
                for max in bounds {
                    for capped in [false, true] {
                        let fill = FillChild::new(content, min, max, capped, 1.0);
                        for target in [-7.0, -0.0, 2.5, 8.0, f32::NEG_INFINITY, f32::INFINITY] {
                            let raw = match content {
                                Some(content) if capped => content.min(target),
                                Some(content) => content.max(target),
                                None => target,
                            };
                            assert_eq!(fill.size(target), clamp(raw, min, max));
                        }
                    }
                }
            }
        }
    }

    #[cfg(feature = "incremental")]
    #[test]
    fn fill_redistributes_space_after_the_last_constraint_freezes() {
        let mut tree: LayoutTree = LayoutTree::new();
        let root = tree.root();
        tree.update_node_params(root, LayoutParams {
            children_layout: ChildrenLayout::Stack { arrange: Arrange::Start, axis: X, spacing: 0.0 },
            ..LayoutParams::DEFAULT
        });
        let constrained = tree.add_node(root, LayoutParams {
            min_size: Xy::new(Some(Size::Pixels(80.0)), None),
            ..LayoutParams::DEFAULT
        });
        let unconstrained = tree.add_node(root, LayoutParams::DEFAULT);

        tree.solve_layout(Xy::new(100.0, 100.0));
        assert_eq!(tree.layout(constrained).x, [0.0, 80.0]);
        assert_eq!(tree.layout(unconstrained).x, [80.0, 100.0]);
    }

    #[test]
    fn packed_grid_matches_cell_by_cell_search() {
        let mut rng = StdRng::seed_from_u64(314);
        for columns in [1_usize, 12, 63, 64, 65, 97, 129, 257] {
            let words_per_line = columns.div_ceil(GRID_WORD_BITS);
            for backfill in [false, true] {
                let mut packed = Vec::new();
                let mut cells = Vec::<Vec<bool>>::new();
                let mut cursor = (0, 0);
                #[cfg(feature = "incremental")]
                let mut placements = Vec::new();
                for child in 0..150 {
                    let height = rng.random_range(1..=8);
                    let width = match child % 4 {
                        0 => rng.random_range(1..=columns),
                        _ => rng.random_range(1..=columns.min(7)),
                    };
                    let (mut line, mut pos) = cursor;
                    loop {
                        if pos + width > columns {
                            line += 1;
                            pos = 0;
                        }
                        let blocked = cells.iter().skip(line).take(height)
                            .any(|row| row[pos..pos + width].contains(&true));
                        if ! blocked {
                            break;
                        }
                        pos += 1;
                    }

                    assert_eq!(
                        find_grid_cell(&packed, columns, words_per_line, cells.len(), cursor, height, width),
                        (line, pos),
                        "columns={columns} backfill={backfill} cursor={cursor:?} span={width}x{height}",
                    );
                    #[cfg(feature = "incremental")]
                    placements.push((line, pos, height, width));
                    let end = line + height;
                    if end > cells.len() {
                        cells.resize_with(end, || vec![false; columns]);
                        packed.resize(end * words_per_line, 0);
                    }
                    for row in &mut cells[line..end] {
                        row[pos..pos + width].fill(true);
                    }
                    let words = &mut packed[line * words_per_line..end * words_per_line];
                    GridColumns::new(pos, width).occupy(words, words_per_line);
                    if ! backfill {
                        cursor = (line, pos + width);
                    }
                }
                #[cfg(feature = "incremental")]
                check_grid_layout(columns, cells.len(), backfill, &placements);
            }
        }
    }

    #[cfg(feature = "incremental")]
    fn check_grid_layout(columns: usize, rows: usize, backfill: bool, placements: &[(usize, usize, usize, usize)]) {
        let mut tree = LayoutTree::<()>::new();
        let root = tree.root();
        tree.update_node_params(root, LayoutParams {
            children_layout: ChildrenLayout::Grid {
                columns: MainAxisCellSize::Count(columns as u32),
                main_axis: X, backfill, spacing_x: 0.0, spacing_y: 0.0,
            },
            ..LayoutParams::DEFAULT
        });
        let ids: Vec<_> = placements.iter().map(|&(_, _, height, width)| tree.add_node(root, LayoutParams {
            grid_span: Xy::new(width as u16, height as u16),
            ..LayoutParams::DEFAULT
        })).collect();
        tree.solve_layout(Xy::new(columns as f32, rows as f32));
        for (&(line, pos, height, width), id) in placements.iter().zip(ids) {
            let expected = Xy::new([pos as f32, (pos + width) as f32], [line as f32, (line + height) as f32]);
            assert_eq!(tree.layout(id), expected);
        }
    }
}
