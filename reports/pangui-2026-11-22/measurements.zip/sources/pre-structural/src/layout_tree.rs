mod svg;

use crate::*;
use slotmap::{SlotMap, new_key_type};

new_key_type! {
    /// The id of a node in a `LayoutTree`.
    pub struct NodeId;
}

#[derive(Debug, Clone)]
pub(crate) struct LayoutNode<T> {
    pub(crate) parent: Option<NodeId>,
    pub(crate) first_child: Option<NodeId>,
    pub(crate) last_child: Option<NodeId>,
    pub(crate) prev_sibling: Option<NodeId>,
    pub(crate) next_sibling: Option<NodeId>,
    pub(crate) params: LayoutParams,
    pub(crate) layout: NodeLayoutData,
    pub(crate) rect: XyRect,
    pub(crate) context: Option<T>,
}

/// A tree of layout nodes. It records the changes to the nodes, and `solve_layout` uses them to do an incremental relayout when it can.
///
/// `T` is the type of the context of each node, for example its text. The measure function of `solve_layout_with_measure` receives it.
///
/// The tree always has a root node. It starts as `Size::Fill` on both axes, so it covers the whole `window_size` given to `solve_layout`. All other nodes are descendants of the root.
///
/// The functions panic if they receive the id of a removed node.
#[derive(Debug, Clone)]
pub struct LayoutTree<T = ()> {
    pub(crate) nodes: SlotMap<NodeId, LayoutNode<T>>,
    root: NodeId,
    pub(crate) layout_data: LayoutData<NodeId>,
    warnings: Vec<LayoutWarning<NodeId>>,
}

impl<T> Default for LayoutTree<T> {
    fn default() -> Self {
        Self::new()
    }
}

impl<T> LayoutTree<T> {
    /// Makes a tree that contains only the root.
    pub fn new() -> Self {
        Self::with_capacity(16)
    }

    /// Makes a tree that contains only the root, with space for `capacity` nodes.
    pub fn with_capacity(capacity: usize) -> Self {
        let mut nodes = SlotMap::with_capacity_and_key(capacity);
        let root_params = LayoutParams { size: Xy::new(Size::Fill, Size::Fill), ..LayoutParams::DEFAULT };
        let root = nodes.insert(LayoutNode::new(root_params));
        LayoutTree { nodes, root, layout_data: LayoutData::new(), warnings: Vec::new() }
    }

    /// Get the `NodeId` corresponding to the root node.
    pub fn root(&self) -> NodeId {
        self.root
    }

    /// Makes a node, and adds it as the last child of `parent`.
    pub fn add_node(&mut self, parent: NodeId, params: LayoutParams) -> NodeId {
        self.add_node_inner(parent, params, None)
    }

    /// Makes a node with a context, and adds it as the last child of `parent`.
    pub fn add_node_with_context(&mut self, parent: NodeId, params: LayoutParams, context: T) -> NodeId {
        self.add_node_inner(parent, params, Some(context))
    }

    /// Moves a node and its subtree, placing it as a child of `parent` and right  before `before_sibling`, or to the end if `before_sibling` is `None`.
    pub fn move_node(&mut self, i: NodeId, parent: NodeId, before_sibling: Option<NodeId>) {
        if let Some(sibling) = before_sibling {
            assert!(sibling != i, "Can't move node {i:?} before itself.");
            assert!(self.nodes[sibling].parent == Some(parent), "Node {sibling:?} is not a child of {parent:?}.");
        }
        if self.nodes[i].parent == Some(parent) && self.nodes[i].next_sibling == before_sibling {
            return;
        }
        let mut ancestor = Some(parent);
        while let Some(a) = ancestor {
            assert!(a != i, "Can't move node {i:?} into {parent:?}: it is the same node or one of its ancestors.");
            ancestor = self.nodes[a].parent;
        }
        self.unlink(i);
        let prev = match before_sibling {
            Some(sibling) => self.nodes[sibling].prev_sibling,
            None => self.nodes[parent].last_child,
        };
        self.link(i, parent, prev, before_sibling);
    }

    /// Changes the params of a node. If the parent is disabled, the node stays disabled. A change of `disabled` also applies to all the descendants. Equal params cause no relayout.
    pub fn update_node_params(&mut self, i: NodeId, mut params: LayoutParams) {
        if let Some(parent) = self.nodes[i].parent {
            params.disabled |= self.nodes[parent].params.disabled;
        }
        let old = &self.nodes[i].params;
        if *old == params {
            return;
        }
        let disabled_changed = old.disabled != params.disabled;
        self.layout_data.record_node_change(i, old, &params);
        self.nodes[i].params = params;
        if disabled_changed {
            self.set_subtree_disabled(i, params.disabled);
        }
    }

    /// Removes a node and all its descendants.
    pub fn remove(&mut self, i: NodeId) {
        assert!(i != self.root, "Can't remove the root.");
        self.unlink(i);
        let mut next = Some(i);
        while let Some(i) = next {
            let node = self.nodes.remove(i).unwrap();
            next = node.prev_sibling;
            if let Some(first) = node.first_child {
                // The detached sibling chain doubles as the worklist. When its first child
                // is removed, continue with the next pending subtree.
                self.nodes[first].prev_sibling = next;
                next = node.last_child;
            }
        }
        self.layout_data.request_full_solve(IncrementalRelayoutOutcome::FallbackStructuralChange);
    }

    /// Read the node's `LayoutParams`.
    pub fn params(&self, i: NodeId) -> &LayoutParams {
        &self.nodes[i].params
    }

    /// Updates the context of a node and invalidates its intrinsic content measurement.
    pub fn update_node_context(&mut self, i: NodeId, context: Option<T>) {
        self.nodes[i].context = context;
        self.mark_content_changed(i);
    }

    /// Makes the next `solve_layout` measure the text of a node again. Use it when the text changes and the context stays the same, for example when the context is an id and the text it points to changes.
    pub fn mark_text_changed(&mut self, i: NodeId) {
        self.mark_content_changed(i);
    }

    /// Invalidates the intrinsic content measurement of a node whose context has changed in place.
    pub fn mark_content_changed(&mut self, i: NodeId) {
        self.layout_data.record_content_change(i);
    }

    /// Makes the next `solve_layout` a full solve. Use it when the measure function changes, for example after a font change.
    pub fn invalidate(&mut self) {
        self.layout_data.request_full_solve(IncrementalRelayoutOutcome::FallbackInvalidated);
    }

    /// Enable pixel-grid rounding for output, or disable it with `None`.
    /// The scale is the number of physical pixels per logical pixel.
    pub fn set_pixel_scale(&mut self, pixels_per_logical_pixel: Option<f32>) {
        self.layout_data.set_pixel_scale(pixels_per_logical_pixel);
    }

    /// The parent of a node. Only the root has no parent.
    pub fn parent(&self, i: NodeId) -> Option<NodeId> {
        self.nodes[i].parent
    }

    /// Get an iterator over the node's children.
    pub fn children(&self, i: NodeId) -> impl Iterator<Item = NodeId> + '_ {
        std::iter::successors(self.nodes[i].first_child, |&child| self.nodes[child].next_sibling)
    }

    /// The rect of a node from the last `solve_layout`, in logical pixels.
    pub fn layout(&self, i: NodeId) -> XyRect {
        self.nodes[i].rect
    }

    /// The warnings from the last `solve_layout`. An incremental relayout reports only the warnings of the slots that it computes again.
    pub fn warnings(&self) -> &[LayoutWarning<NodeId>] {
        &self.warnings
    }

    /// Solves the layout. `window_size` is the size of the window, in logical pixels. The text of all nodes measures as zero.
    pub fn solve_layout(&mut self, window_size: Xy<f32>) -> IncrementalRelayoutOutcome {
        self.solve_layout_with_measure(window_size, |_, _, _| Xy::new(0.0, 0.0))
    }

    /// Solves the layout. `window_size` is the size of the window, in logical pixels. `measure` gives the size of the text of a node, with its width optionally fixed to a wrap width.
    pub fn solve_layout_with_measure(&mut self, window_size: Xy<f32>, measure: impl FnMut(NodeId, Option<&mut T>, Option<f32>) -> Xy<f32>) -> IncrementalRelayoutOutcome {
        self.solve_layout_with_measurers(window_size, measure, |_, _, _| Xy::new_symm(0.0))
    }

    /// Solves the layout using a custom intrinsic content callback and zero text measurements.
    pub fn solve_layout_with_content_measure(
        &mut self,
        window_size: Xy<f32>,
        measure: impl FnMut(NodeId, Option<&mut T>, ContentMeasureInput) -> Xy<f32>,
    ) -> IncrementalRelayoutOutcome {
        self.solve_layout_with_measurers(window_size, |_, _, _| Xy::new_symm(0.0), measure)
    }

    /// Solves the layout using callbacks for both text and custom intrinsic content.
    pub fn solve_layout_with_measurers(
        &mut self,
        window_size: Xy<f32>,
        text: impl FnMut(NodeId, Option<&mut T>, Option<f32>) -> Xy<f32>,
        content: impl FnMut(NodeId, Option<&mut T>, ContentMeasureInput) -> Xy<f32>,
    ) -> IncrementalRelayoutOutcome {
        self.warnings.clear();
        Adapter { tree: self, text, content }.solve_layout_incremental(window_size)
    }

    fn add_node_inner(&mut self, parent: NodeId, params: LayoutParams, context: Option<T>) -> NodeId {
        let mut node = LayoutNode::new(params);
        node.context = context;
        let i = self.nodes.insert(node);
        let last = self.nodes[parent].last_child;
        self.link(i, parent, last, None);
        i
    }

    fn link(&mut self, i: NodeId, parent: NodeId, prev: Option<NodeId>, next: Option<NodeId>) {
        let node = &mut self.nodes[i];
        node.parent = Some(parent);
        node.prev_sibling = prev;
        node.next_sibling = next;
        match prev {
            Some(prev) => self.nodes[prev].next_sibling = Some(i),
            None => self.nodes[parent].first_child = Some(i),
        }
        match next {
            Some(next) => self.nodes[next].prev_sibling = Some(i),
            None => self.nodes[parent].last_child = Some(i),
        }
        if self.nodes[parent].params.disabled {
            self.set_subtree_disabled(i, true);
        }
        self.layout_data.request_full_solve(IncrementalRelayoutOutcome::FallbackStructuralChange);
    }

    /// Takes a node out of the children of its parent.
    fn unlink(&mut self, i: NodeId) {
        let parent = self.nodes[i].parent.take().expect("The root has no parent.");
        let prev = self.nodes[i].prev_sibling.take();
        let next = self.nodes[i].next_sibling.take();
        match prev {
            Some(prev) => self.nodes[prev].next_sibling = next,
            None => self.nodes[parent].first_child = next,
        }
        match next {
            Some(next) => self.nodes[next].prev_sibling = prev,
            None => self.nodes[parent].last_child = prev,
        }
    }

    fn set_subtree_disabled(&mut self, root: NodeId, disabled: bool) {
        let mut next = Some(root);
        while let Some(i) = next {
            self.nodes[i].params.disabled = disabled;
            next = self.next_in_subtree(root, i, true);
        }
    }

    // Visit siblings last-to-first, the same order used to paint the SVG.
    fn next_in_subtree(&self, root: NodeId, mut i: NodeId, descend: bool) -> Option<NodeId> {
        if descend && let Some(child) = self.nodes[i].last_child {
            return Some(child);
        }
        while i != root {
            let node = &self.nodes[i];
            if let Some(sibling) = node.prev_sibling {
                return Some(sibling);
            }
            i = node.parent?;
        }
        None
    }
}

impl<T> LayoutNode<T> {
    fn new(params: LayoutParams) -> Self {
        LayoutNode {
            parent: None,
            first_child: None,
            last_child: None,
            prev_sibling: None,
            next_sibling: None,
            params,
            layout: NodeLayoutData::new(),
            rect: Xy::new([0.0, 0.0], [0.0, 0.0]),
            context: None,
        }
    }
}

/// Gives a `LayoutTree` and a measure function to the solver.
struct Adapter<'a, T, M, C> {
    tree: &'a mut LayoutTree<T>,
    text: M,
    content: C,
}

impl<T, M, C> TreeAdapter for Adapter<'_, T, M, C>
where
    M: FnMut(NodeId, Option<&mut T>, Option<f32>) -> Xy<f32>,
    C: FnMut(NodeId, Option<&mut T>, ContentMeasureInput) -> Xy<f32>,
{
    type NodeId = NodeId;

    #[inline(always)]
    fn root(&self) -> NodeId {
        self.tree.root
    }

    #[inline(always)]
    fn parent(&self, i: NodeId) -> Option<NodeId> {
        self.tree.nodes[i].parent
    }

    #[inline(always)]
    fn first_child(&self, i: NodeId) -> Option<NodeId> {
        self.tree.nodes[i].first_child
    }

    #[inline(always)]
    fn next_sibling(&self, i: NodeId) -> Option<NodeId> {
        self.tree.nodes[i].next_sibling
    }

    #[inline(always)]
    fn node_layout_params(&self, i: NodeId) -> &LayoutParams {
        &self.tree.nodes[i].params
    }

    #[inline(always)]
    fn node_layout_data(&self, i: NodeId) -> &NodeLayoutData {
        &self.tree.nodes[i].layout
    }

    #[inline(always)]
    fn node_layout_data_mut(&mut self, i: NodeId) -> &mut NodeLayoutData {
        &mut self.tree.nodes[i].layout
    }

    #[inline(always)]
    fn layout_data(&mut self) -> &mut LayoutData<NodeId> {
        &mut self.tree.layout_data
    }

    fn measure_text_width(&mut self, i: NodeId) -> f32 {
        (self.text)(i, self.tree.nodes[i].context.as_mut(), None).x
    }

    fn measure_text_height(&mut self, i: NodeId, wrap_width: Option<f32>) -> f32 {
        (self.text)(i, self.tree.nodes[i].context.as_mut(), wrap_width).y
    }

    fn measure_content(&mut self, i: NodeId, input: ContentMeasureInput) -> Xy<f32> {
        (self.content)(i, self.tree.nodes[i].context.as_mut(), input)
    }

    #[inline(always)]
    fn write_output_rect(&mut self, i: NodeId, rect: XyRect, _local_rect: XyRect) {
        self.tree.nodes[i].rect = rect;
    }

    fn layout_warning(&mut self, warning: LayoutWarning<NodeId>) {
        self.tree.warnings.push(warning);
    }
}

const FONT_SIZE: f32 = 12.0;
const CHAR_WIDTH: f32 = 0.6 * FONT_SIZE;
const LINE_HEIGHT: f32 = 1.2 * FONT_SIZE;

/// A measure function for `solve_layout_with_measure` that matches the text of `LayoutTree::to_svg`.
pub fn measure_monospace_text<T: AsRef<str>>(_: NodeId, text: Option<&mut T>, wrap_width: Option<f32>) -> Xy<f32> {
    let text = text.as_deref().map_or("", T::as_ref);
    if text.is_ascii() {
        let bytes = text.as_bytes();
        if wrap_width.is_none() {
            let chars = normalized_ascii_width(bytes);
            return Xy::new(chars as f32 * CHAR_WIDTH, if chars == 0 { 0.0 } else { LINE_HEIGHT });
        }
        let words = bytes.split(|&byte| ascii_space(byte)).filter(|word| !word.is_empty());
        return measure_word_widths(words.map(|word| word.len()), wrap_width);
    }
    measure_word_widths(text.split_whitespace().map(|word| word.chars().count()), wrap_width)
}

#[inline]
fn ascii_space(byte: u8) -> bool {
    // Unicode White_Space includes vertical tab alongside the other ASCII whitespace.
    byte == b' ' || (b'\t'..=b'\r').contains(&byte)
}

fn normalized_ascii_width(bytes: &[u8]) -> usize {
    let Some((&first, rest)) = bytes.split_first() else { return 0 };
    let mut chars = usize::from(!ascii_space(first));
    let mut words = chars;
    // Limit each reduction to 64 byte pairs so the vectorized counters fit in byte lanes.
    let (preceding, preceding_tail) = bytes[..rest.len()].as_chunks::<64>();
    let (following, following_tail) = rest.as_chunks::<64>();
    for (left, right) in preceding.iter().zip(following) {
        let (letters, starts) = count_ascii_pairs(left, right);
        chars += usize::from(letters);
        words += usize::from(starts);
    }
    let (letters, starts) = count_ascii_pairs(preceding_tail, following_tail);
    chars += usize::from(letters);
    words += usize::from(starts);
    chars + words.saturating_sub(1)
}

#[inline]
fn count_ascii_pairs(preceding: &[u8], following: &[u8]) -> (u8, u8) {
    let mut chars = 0;
    let mut words = 0;
    for (&previous, &current) in preceding.iter().zip(following) {
        let is_text = !ascii_space(current);
        chars += u8::from(is_text);
        words += u8::from(ascii_space(previous) && is_text);
    }
    (chars, words)
}

fn measure_word_widths(widths: impl Iterator<Item = usize>, wrap_width: Option<f32>) -> Xy<f32> {
    let mut line_count = 0usize;
    let mut longest = 0;
    let mut line_chars = 0;
    let max = max_line_chars(wrap_width);
    for word in widths {
        let joined = line_chars + 1 + word;
        if line_chars == 0 || joined > max {
            line_count += 1;
            line_chars = word;
        } else {
            line_chars = joined;
        }
        longest = longest.max(line_chars);
    }
    Xy::new(longest as f32 * CHAR_WIDTH, line_count as f32 * LINE_HEIGHT)
}

fn max_line_chars(wrap_width: Option<f32>) -> usize {
    wrap_width.map_or(usize::MAX, |width| (width / CHAR_WIDTH) as usize)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn monospace_measurement_counts_normalized_unicode_lines() {
        let root = LayoutTree::<()>::new().root();
        let mut text = " \tÅβ\u{2003}猫  four\n";
        for (width, chars, lines) in [(None, 9, 1), (Some(CHAR_WIDTH * 4.0), 4, 2), (Some(0.0), 4, 3)] {
            assert_eq!(
                measure_monospace_text(root, Some(&mut text), width),
                Xy::new(chars as f32 * CHAR_WIDTH, lines as f32 * LINE_HEIGHT),
            );
        }
        assert_eq!(measure_monospace_text::<&str>(root, None, None), Xy::new_symm(0.0));
    }

    #[test]
    fn subtree_operations_preserve_siblings_and_context_drop_order() {
        struct Context<'a>(u8, &'a std::cell::RefCell<Vec<u8>>);
        impl Drop for Context<'_> {
            fn drop(&mut self) {
                self.1.borrow_mut().push(self.0);
            }
        }
        let dropped = std::cell::RefCell::new(Vec::new());
        let mut tree = LayoutTree::new();
        let root = tree.root();
        let mut add = |parent, label| tree.add_node_with_context(parent, LayoutParams::DEFAULT, Context(label, &dropped));
        let left = add(root, 0);
        let subtree = add(root, 1);
        let right = add(root, 2);
        let first = add(subtree, 3);
        let last = add(subtree, 4);
        let nested = add(last, 5);
        tree.update_node_params(subtree, LayoutParams { disabled: true, ..LayoutParams::DEFAULT });
        assert!([subtree, first, last, nested].iter().all(|&id| tree.params(id).disabled));
        assert!([root, left, right].iter().all(|&id| !tree.params(id).disabled));
        tree.remove(subtree);
        assert_eq!(dropped.borrow().as_slice(), &[1, 4, 5, 3]);
        assert!(tree.children(root).eq([left, right]));
    }
}
