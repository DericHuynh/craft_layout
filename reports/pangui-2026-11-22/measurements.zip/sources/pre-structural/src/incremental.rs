use crate::*;
use crate::Axis::{X, Y};

/// What `solve_layout_incremental` did. The `Fallback` variants give the reason for a full solve.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum IncrementalRelayoutOutcome {
    /// The relayout was incremental.
    Success {
        /// Slot computations.
        computed: u32,
    },
    /// In `solve_layout_incremental_checked()`, the incremental relayout gave a different result than the full relayout. The tree keeps the result of the full relayout. This should only be possible if a change wasn't registered with `register_node_change()`, `register_content_change()` or `register_structural_change()`.
    CheckedIncrementalRelayoutMismatch,
    /// The incremental relayout fell back to a full relayout because the full layout was never solved before.
    FallbackNeverSolved,
    /// The incremental relayout fell back to a full relayout because the tree had a structural change. Structural changes are not supported by the incremental solver.
    FallbackStructuralChange,
    /// The incremental relayout fell back to a full relayout because the last full solve found a cycle. With cycles, the incremental solver can't guarantee identical results to the full solver in all cases.
    FallbackCycle,
    /// A block or wrapping flow must rebuild its line or collapsed-margin data.
    FallbackFlow,
    /// The incremental relayout fell back to a full relayout because the changes affected a large part of the tree, and the solver estimated it would be faster to fall back to a full relayout.
    FallbackTooMuchWork,
    /// The incremental relayout fell back to a full relayout because `LayoutTree::invalidate()` was called explicitly.
    FallbackInvalidated,
}

impl<I> LayoutData<I> {
    /// Records a change in the params of a node. A structural change makes the next relayout a full solve.
    pub(crate) fn record_node_change(&mut self, i: I, old: &LayoutParams, new: &LayoutParams) {
        if self.tracks_structure() {
            self.record_change(i, NodeChange::between(old, new, self.tracks_sizes()));
        }
    }

    /// An explicit invalidation or structural edit takes priority over an inferred fallback.
    fn tracks_structure(&self) -> bool {
        use IncrementalRelayoutOutcome::*;
        matches!(self.pending_full_solve, None | Some(FallbackFlow | FallbackTooMuchWork))
    }

    fn tracks_sizes(&self) -> bool {
        self.pending_full_solve.is_none() && !self.has_cycle
    }

    fn record_change(&mut self, i: I, change: Option<NodeChange>) {
        match change {
            None => self.request_full_solve(IncrementalRelayoutOutcome::FallbackStructuralChange),
            Some(change) if change != NodeChange::default() && self.accept_sizing_change() => self.node_changes.push((i, change)),
            Some(_) => {}
        }
    }

    pub(crate) fn record_content_change(&mut self, i: I) {
        if self.accept_sizing_change() {
            self.content_changes.push(i);
        }
    }

    /// Check the fallback before growing a change list that the solver would discard.
    fn accept_sizing_change(&mut self) -> bool {
        if !self.tracks_sizes() {
            return false;
        }
        self.pending_full_solve = if self.has_flow {
            Some(IncrementalRelayoutOutcome::FallbackFlow)
        } else if self.node_changes.len() + self.content_changes.len() >= (self.n_nodes_solved / 2) as usize {
            Some(IncrementalRelayoutOutcome::FallbackTooMuchWork)
        } else {
            return true;
        };
        false
    }

    /// An explicit full solve takes priority over a fallback inferred from sizing edits.
    pub(crate) fn request_full_solve(&mut self, reason: IncrementalRelayoutOutcome) {
        if self.tracks_structure() {
            self.pending_full_solve = Some(reason);
        }
    }

    pub(crate) fn clear(&mut self) {
        self.node_changes.clear();
        self.content_changes.clear();
    }
}

/// The sizing inputs that changed. Placement reads the latest params directly.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub(crate) struct NodeChange {
    declared: u8,
    inner: Xy<bool>,
    margin: Xy<bool>,
    fill_weight: bool,
    content: bool,
}

impl NodeChange {
    /// A structural change invalidates the whole dependency graph.
    fn between(old: &LayoutParams, new: &LayoutParams, track_sizes: bool) -> Option<Self> {
        if is_structural(old, new) {
            return None;
        }

        let mut change = Self::default();
        if !track_sizes {
            return Some(change);
        }
        for axis in [X, Y] {
            for (kind, changed) in [
                (Kind::Regular, old.size[axis] != new.size[axis]),
                (Kind::Min, old.min_size[axis] != new.min_size[axis]),
                (Kind::Max, old.max_size[axis] != new.max_size[axis]),
            ] {
                if changed {
                    change.declared |= 1 << slot_index(axis, kind);
                }
            }
            change.inner[axis] = old.padding[axis] != new.padding[axis];
            change.margin[axis] = !new.free_placement && old.margin[axis] != new.margin[axis];
        }
        change.fill_weight = !new.free_placement && old.fill_weight != new.fill_weight;
        change.content = old.image != new.image || new.content_measure != ContentMeasure::None
            && (change.inner.x || change.inner.y || old.max_size != new.max_size);
        match (old.children_layout, new.children_layout) {
            (ChildrenLayout::Stack { spacing: a, .. }, ChildrenLayout::Stack { axis, spacing: b, .. }) if a != b => {
                change.inner[axis] = true;
            }
            (ChildrenLayout::Wrap { spacing: a, line_spacing: line_a, .. }, ChildrenLayout::Wrap { axis, spacing: b, line_spacing: line_b, .. }) => {
                change.inner[axis] |= a != b;
                change.inner[axis.other()] |= line_a != line_b;
            }
            (a @ ChildrenLayout::Grid { .. }, b @ ChildrenLayout::Grid { .. }) if a != b => {
                change.inner = Xy::new_symm(true);
            }
            _ => {}
        }
        Some(change)
    }
}

/// True if the change can change the dependencies between the slots.
fn is_structural(old: &LayoutParams, new: &LayoutParams) -> bool {
    use std::mem::discriminant;
    let same_kind = |a: Option<Size>, b: Option<Size>| a.map(|a| discriminant(&a)) == b.map(|b| discriminant(&b));
    let same_layout = match (old.children_layout, new.children_layout) {
        (ChildrenLayout::Free, ChildrenLayout::Free) => true,
        (ChildrenLayout::Block, ChildrenLayout::Block) => true,
        (ChildrenLayout::Stack { axis: a, .. }, ChildrenLayout::Stack { axis: b, .. }) => a == b,
        (ChildrenLayout::Wrap { axis: a, .. }, ChildrenLayout::Wrap { axis: b, .. }) => a == b,
        // The `Count` grid cells are assigned in `prepare`.
        (ChildrenLayout::Grid { columns: MainAxisCellSize::Count(a), main_axis: main_a, backfill: backfill_a, .. }, ChildrenLayout::Grid { columns: MainAxisCellSize::Count(b), main_axis: main_b, backfill: backfill_b, .. }) => a == b && main_a == main_b && backfill_a == backfill_b,
        (ChildrenLayout::Grid { columns: MainAxisCellSize::Width(_), main_axis: main_a, backfill: backfill_a, .. }, ChildrenLayout::Grid { columns: MainAxisCellSize::Width(_), main_axis: main_b, backfill: backfill_b, .. }) => main_a == main_b && backfill_a == backfill_b,
        _ => false,
    };
    old.disabled != new.disabled
        || old.free_placement != new.free_placement
        || old.grid_span != new.grid_span
        || old.text != new.text
        || old.content_measure != new.content_measure
        || old.image.is_some() != new.image.is_some()
        || ! same_layout
        || [X, Y].into_iter().any(|axis| {
            ! same_kind(Some(old.size[axis]), Some(new.size[axis]))
                || ! same_kind(old.min_size[axis], new.min_size[axis])
                || ! same_kind(old.max_size[axis], new.max_size[axis])
        })
}

/// Dependency levels are LIFO stacks into one shared array of entries. A zero link
/// ends a stack. Popping a slot returns its entry to the free list for any level.
#[derive(Debug, Clone)]
pub(crate) struct WorkQueue<I> {
    heads: Vec<usize>,
    entries: Vec<(Slot<I>, usize)>,
    free: usize,
    cursor: usize,
    first_level: u16,
}

impl<I> WorkQueue<I> {
    pub(crate) const fn new() -> Self {
        Self { heads: Vec::new(), entries: Vec::new(), free: 0, cursor: 0, first_level: 0 }
    }

    fn push(&mut self, level: u16, slot: Slot<I>) {
        if self.heads.is_empty() {
            self.first_level = level;
        } else if level < self.first_level {
            // Initial edits may arrive in any order. Dependents added while solving
            // always have a higher level than the slot being processed.
            debug_assert_eq!(self.cursor, 0);
            // Grow geometrically when prepending so descending edits amortize the copies.
            let missing = usize::from(self.first_level - level);
            let extra = missing.max(self.heads.len()).min(usize::from(self.first_level));
            self.heads.resize(self.heads.len() + extra, 0);
            self.heads.rotate_right(extra);
            self.first_level -= extra as u16;
        }
        let index = usize::from(level - self.first_level);
        debug_assert!(index >= self.cursor);
        if self.heads.len() <= index {
            self.heads.resize(index + 1, 0);
        }
        let head = &mut self.heads[index];
        let entry = (slot, *head);
        if self.free == 0 {
            self.entries.push(entry);
            *head = self.entries.len();
        } else {
            *head = self.free;
            self.free = std::mem::replace(&mut self.entries[self.free - 1], entry).1;
        }
    }

    fn pop(&mut self) -> Option<Slot<I>> where I: Copy {
        while let Some(head) = self.heads.get_mut(self.cursor) {
            if *head != 0 {
                let index = *head;
                let (slot, next) = &mut self.entries[index - 1];
                *head = *next;
                *next = self.free;
                self.free = index;
                return Some(*slot);
            }
            self.cursor += 1;
        }
        self.clear();
        None
    }

    fn clear(&mut self) {
        self.heads.clear();
        self.entries.clear();
        self.free = 0;
        self.cursor = 0;
    }
}

pub(crate) trait Incremental: Solve {
    fn measure_sizes_incremental(&mut self, window_size: Xy<f32>) -> IncrementalRelayoutOutcome {
        let root = self.root();
        let data = self.layout_data();
        let last_window_size = std::mem::replace(&mut data.window_size, window_size);
        if last_window_size == window_size && data.node_changes.is_empty() && data.content_changes.is_empty() {
            return IncrementalRelayoutOutcome::Success { computed: 0 };
        }
        let max_computed = data.n_nodes_solved / 2;

        // Borrow the change lists independently while queuing slots through the adapter.
        let mut changes = std::mem::take(&mut data.node_changes);
        let mut content_changes = std::mem::take(&mut data.content_changes);
        for axis in [X, Y] {
            if last_window_size[axis] != window_size[axis] {
                self.queue_declared(root, axis, |size| size.is_flex());
            }
        }
        for (i, change) in changes.drain(..) {
            self.queue_node_change(i, change);
        }
        for i in content_changes.drain(..) {
            self.queue_content_change(i);
        }
        let data = self.layout_data();
        data.node_changes = changes;
        data.content_changes = content_changes;
        self.run_queue(max_computed)
    }

    /// Records a change in the params of a node.
    fn incr_register_node_change(&mut self, i: Self::NodeId, old: &LayoutParams) {
        let data = self.layout_data();
        if data.tracks_structure() {
            let track_sizes = data.tracks_sizes();
            let change = NodeChange::between(old, self.node_layout_params(i), track_sizes);
            self.layout_data().record_change(i, change);
        }
    }

    /// Records that the text or the image of a node changed.
    fn incr_register_content_change(&mut self, i: Self::NodeId) {
        self.layout_data().record_content_change(i);
    }

    /// Does an incremental relayout, or a full solve if the registered changes need one. If `verify` is true, it also does a full solve and compares the sizes.
    fn solve_incremental(&mut self, window_size: Xy<f32>, verify: bool) -> IncrementalRelayoutOutcome {
        let data = self.layout_data();
        let outcome = if let Some(reason) = data.pending_full_solve {
            reason
        } else if data.has_cycle {
            IncrementalRelayoutOutcome::FallbackCycle
        } else if data.has_flow && data.window_size != window_size {
            IncrementalRelayoutOutcome::FallbackFlow
        } else {
            self.measure_sizes_incremental(window_size)
        };
        match outcome {
            IncrementalRelayoutOutcome::Success { .. } => match verify {
                true => {
                    if ! self.run_full_solve_and_compare(window_size) {
                        return IncrementalRelayoutOutcome::CheckedIncrementalRelayoutMismatch;
                    }
                }
                false => self.place_nodes(),
            },
            _ => self.solve_layout(window_size),
        }
        outcome
    }

    fn run_full_solve_and_compare(&mut self, window_size: Xy<f32>) -> bool {
        let data = self.layout_data();
        let mut incremental = std::mem::take(&mut data.checked_values);
        incremental.reserve(data.n_nodes_solved as usize);
        let mut next = Some(self.root());
        while let Some(i) = next {
            incremental.push((i, self.node_layout_data(i).values.map(f32::to_bits)));
            next = self.tree_traversal_next(i);
        }
        self.solve_layout(window_size);
        let matches = incremental.iter().all(|(i, values)| self.node_layout_data(*i).values.map(f32::to_bits) == *values);
        incremental.clear();
        self.layout_data().checked_values = incremental;
        matches
    }

    /// Queues the slots affected by the sizing inputs that changed.
    fn queue_node_change(&mut self, i: Self::NodeId, change: NodeChange) {
        if self.node_layout_params(i).disabled {
            return;
        }
        for axis in [X, Y] {
            for kind in DECLARED_SIZES {
                if change.declared & (1 << slot_index(axis, kind)) != 0 {
                    self.queue(Slot { node: i, axis, kind });
                }
            }
            // A FitContent stack reads its children's fractions directly from their params.
            let params = self.node_layout_params(i);
            if change.declared & (1 << slot_index(axis, Kind::Regular)) != 0
                && matches!(params.size[axis], Size::Frac(_)) && !params.free_placement && let Some(parent) = self.parent(i)
            {
                self.queue_declared(parent, axis, |size| size == Size::FitContent);
            }
        }
        if change.inner.x || change.inner.y {
            self.queue_inner_size_readers(i, change.inner);
        }
        for axis in [X, Y] {
            if change.margin[axis] && let Some(parent) = self.parent(i)
                && self.node_layout_params(parent).children_layout != ChildrenLayout::Free
            {
                self.queue_declared(i, axis, |size| size.is_fill());
                self.queue_declared(parent, axis, |size| size == Size::FitContent);
                if self.stack_axis(parent) == Some(axis) {
                    self.queue_even_share(parent);
                }
            }
        }
        if change.fill_weight && let Some(parent) = self.parent(i) && let Some(axis) = self.stack_axis(parent) {
            self.queue_declared(i, axis, |size| size.is_fill());
            self.queue_even_share(parent);
        }
        if change.content {
            self.queue_content_change(i);
        }
    }

    fn queue_content_change(&mut self, i: Self::NodeId) {
        if self.node_layout_params(i).disabled {
            return;
        }
        for axis in [X, Y] {
            self.queue_declared(i, axis, |size| size == Size::FitContent);
        }
    }

    fn queue_inner_size_readers(&mut self, i: Self::NodeId, mut changed: Xy<bool>) {
        let grid_main = self.width_grid_main_axis(i);
        if grid_main.is_some() {
            // Changing one cell dimension can change both axes of a width grid.
            changed = Xy::new_symm(true);
        }
        for axis in [X, Y] {
            if changed[axis] {
                self.queue_declared(i, axis, |size| size == Size::FitContent);
            }
        }
        let stack_axis = self.stack_axis(i);
        for_each_layout_child!(self, i, child, {
            let free = self.node_layout_params(child).free_placement;
            for axis in [X, Y] {
                if changed[axis] {
                    let in_stack = stack_axis == Some(axis) && !free;
                    self.queue_declared(child, axis, |size| matches!(size, Size::Frac(_)) || (size.is_fill() && !in_stack));
                }
            }
        });
        if let Some(main) = grid_main {
            self.queue(Slot { node: i, axis: main, kind: Kind::Final });
        }
        if changed.x && self.text_wraps(i, Y) {
            self.queue_declared(i, Y, |size| size == Size::FitContent);
        }
        if let Some(axis) = stack_axis {
            self.queue(Slot { node: i, axis, kind: Kind::EvenShare });
        }
    }

    fn queue_even_share(&mut self, i: Self::NodeId) {
        if let Some(axis) = self.stack_axis(i) {
            self.queue(Slot { node: i, axis, kind: Kind::EvenShare });
        }
    }

    fn queue(&mut self, slot: Slot<Self::NodeId>) {
        let Slot { node, axis, kind } = slot;
        let data = self.node_layout_data_mut(node);
        if data.flags.check_state(axis, kind) != SOLVED {
            return;
        }
        data.flags.set_state(axis, kind, UNSOLVED);
        let level = data.levels[slot_index(axis, kind)];
        self.layout_data().queue.push(level, slot);
    }

    /// Computes the queued slots in order of level, and queues the dependents of each slot that changes. The levels are exact, so each slot is computed once. It stops after `max_computed` slot computations.
    fn run_queue(&mut self, max_computed: u32) -> IncrementalRelayoutOutcome {
        let mut computed = 0;
        loop {
            let data = self.layout_data();
            let Some(slot) = data.queue.pop() else { break };
            computed += 1;
            if computed > max_computed {
                data.queue.clear();
                return IncrementalRelayoutOutcome::FallbackTooMuchWork;
            }
            let k = slot_index(slot.axis, slot.kind);
            let old = self.node_layout_data(slot.node);
            let (old_value, old_grid_lines) = (old.values[k], old.grid_lines());
            // The level of the slot stays the same.
            self.finish_slot(slot);
            let new = self.node_layout_data(slot.node);
            // The cells of a width grid can change while its size stays the same.
            if new.values[k].to_bits() != old_value.to_bits() || new.grid_lines() != old_grid_lines {
                self.queue_dependents(slot);
            }
        }
        IncrementalRelayoutOutcome::Success { computed }
    }

    /// Queues every slot that reads `slot`. It is the reverse of `solve_all_dependencies`, and it has to stay in sync with it.
    fn queue_dependents(&mut self, slot: Slot<Self::NodeId>) {
        let Slot { node: i, axis, kind } = slot;
        match kind {
            Kind::EvenShare => {
                for_each_layout_child!(self, i, child, {
                    if self.is_in_stack(child, axis) {
                        self.queue_declared(child, axis, |size| size.is_fill());
                    }
                });
            }
            Kind::Final => {
                let other = axis.other();
                self.queue_declared(i, other, |size| matches!(size, Size::AspectRatio(_)));
                let grid_main = self.width_grid_main_axis(i) == Some(axis);
                if grid_main || (axis == X && self.text_wraps(i, Y))
                    || self.node_layout_params(i).content_measure.reads_other_axis(other)
                {
                    self.queue_declared(i, other, |size| size == Size::FitContent);
                }
                if self.stack_axis(i) == Some(axis) {
                    self.queue(Slot { node: i, axis, kind: Kind::EvenShare });
                }
                for_each_layout_child!(self, i, child, {
                    for child_axis in [X, Y] {
                        // A placed child of a width grid also reads the main axis for its other axis.
                        if child_axis == axis || (grid_main && ! self.node_layout_params(child).free_placement) {
                            let in_stack = self.is_in_stack(child, child_axis);
                            self.queue_declared(child, child_axis, |size| matches!(size, Size::Frac(_)) || (size.is_fill() && ! in_stack));
                        }
                    }
                });
                if let Some(parent) = self.stack_parent(i, axis) && ! self.any_size_is_fill(i, axis) {
                    self.queue(Slot { node: parent, axis, kind: Kind::EvenShare });
                }
            }
            Kind::Flow => unreachable!("flow currently uses full measurement"),
            declared => {
                self.queue(Slot { node: i, axis, kind: Kind::Final });
                if ! self.node_layout_params(i).free_placement && let Some(parent) = self.parent(i) {
                    let size = self.read_size(i, axis, declared).unwrap();
                    if self.stack_axis(parent) == Some(axis) && self.any_size_is_fill(i, axis) && ! size.is_fill() {
                        self.queue(Slot { node: parent, axis, kind: Kind::EvenShare });
                    }
                    if ! size.is_flex() {
                        self.queue_declared(parent, axis, |size| size == Size::FitContent);
                    }
                }
            }
        }
    }

    /// Queues the declared slots of a node on `axis` whose size matches `filter`.
    #[inline(always)]
    fn queue_declared(&mut self, i: Self::NodeId, axis: Axis, filter: impl Fn(Size) -> bool) {
        for kind in DECLARED_SIZES {
            if let Some(size) = self.read_size(i, axis, kind) && filter(size) {
                self.queue(Slot { node: i, axis, kind });
            }
        }
    }
}

impl<T: TreeAdapter + ?Sized> Incremental for T {}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn queue_preserves_priority_and_lifo_order_when_reusing_entries() {
        let mut queue = WorkQueue::new();
        let slot = |node| Slot { node, axis: X, kind: Kind::Regular };
        for (level, id) in [(4000, 1), (3999, 2), (3990, 3), (3999, 4)] {
            queue.push(level, slot(id));
        }
        assert_eq!(queue.pop().unwrap().node, 3);
        queue.push(4001, slot(5));
        assert_eq!(queue.pop().unwrap().node, 4);
        queue.push(4000, slot(6));
        for expected in [2, 6, 1, 5] {
            assert_eq!(queue.pop().unwrap().node, expected);
        }
        assert!(queue.pop().is_none());

        queue.push(65535, slot(7));
        queue.clear();
        queue.push(0, slot(8));
        assert_eq!(queue.pop().unwrap().node, 8);
        assert!(queue.pop().is_none());
    }

    #[test]
    fn explicit_invalidations_take_priority_over_inferred_fallbacks() {
        use IncrementalRelayoutOutcome::*;
        let window = Xy::new_symm(100.0);
        for fallback in [FallbackFlow, FallbackCycle, FallbackTooMuchWork] {
            let mut tree: LayoutTree = LayoutTree::new();
            let root = tree.root();
            if fallback == FallbackFlow {
                tree.update_node_params(root, LayoutParams { children_layout: ChildrenLayout::Block, ..LayoutParams::DEFAULT });
            } else if fallback == FallbackCycle {
                tree.add_node(root, LayoutParams { size: Xy::new_symm(Size::AspectRatio(1.0)), ..LayoutParams::DEFAULT });
            }
            let item = tree.add_node(root, LayoutParams { size: Xy::new_symm(Size::Pixels(10.0)), ..LayoutParams::DEFAULT });
            tree.solve_layout(window);

            let mut params = *tree.params(item);
            params.size.x = Size::Pixels(11.0);
            tree.update_node_params(item, params);
            for _ in 0..4 {
                tree.mark_content_changed(item);
            }

            let mut invalidated = tree.clone();
            invalidated.invalidate();
            params.size.x = Size::Fill;
            invalidated.update_node_params(item, params);
            assert_eq!(invalidated.solve_layout(window), FallbackInvalidated);

            let mut structural = tree.clone();
            structural.update_node_params(item, params);
            structural.invalidate();
            assert_eq!(structural.solve_layout(window), FallbackStructuralChange);
            assert_eq!(tree.solve_layout(window), fallback);
        }
    }
}
