from pathlib import Path
from statistics import median
import subprocess
root=Path(__file__).resolve().parent
initial=root/'incoming'
now=root/'recovered-build/release/coupled'
modes='flat-zero flat-weighted flat-bounded flat-bounded-edit-dense flat-positive-crossfill panels-positive flat-independent full-control'.split()
def run(exe,mode,verify=False):
 argv=['taskset','-c','2',exe,mode,'12288']
 if verify:argv.append('verify')
 out=subprocess.check_output(argv,text=True).split()
 assert len(out)==11
 return out
with (root/'checks.tsv').open('w') as f:
 print('workload\tappend_before_us\tappend_after_us\tremove_before_us\tremove_after_us\talloc_before\talloc_after\tmeasured_before\tmeasured_after',file=f)
 for mode in modes:
  refs=[run(exe,mode,True) for exe in [initial,now]]
  assert refs[0][-2:]==refs[1][-2:], (mode,refs)
  assert refs[0][7:9]==refs[1][7:9],(mode,refs)
  results={exe:[] for exe in (initial,now)}
  for repeat in range(8):
   for exe in ([initial,now] if repeat%2==0 else [now,initial]):
    got=run(exe,mode)
    assert got[9:]==refs[0][9:] and got[5]=='0', (mode,got)
    results[exe].append(got)
  stats=[median(float(v[j]) for v in results[exe])/1000 for j in (3,4) for exe in (initial,now)]
  print(mode,*[f'{s:.2f}' for s in stats],refs[0][5],refs[1][5],refs[0][7],refs[1][7],file=f,sep='\t',flush=True)
