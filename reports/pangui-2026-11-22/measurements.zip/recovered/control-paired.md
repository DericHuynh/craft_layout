| Workload | Historical µs | Recovered µs | Median paired change |
|---|---:|---:|---:|
| grid 12 columns backfill=true | 55.072 | 40.697 | -26.4% |
| grid 12 columns backfill=false | 24.878 | 9.493 | -61.9% |
| grid 97 columns backfill=true | 212.360 | 157.693 | -25.9% |
| grid 97 columns backfill=false | 77.199 | 30.014 | -60.9% |
| grid 257 columns backfill=true | 196.488 | 131.721 | -33.1% |
| grid 257 columns backfill=false | 78.500 | 30.096 | -61.6% |
| free center | 110.019 | 106.426 | -3.9% |
| free start | 116.525 | 114.734 | +0.1% |
