from pathlib import Path
from statistics import median
import re,subprocess,sys,json
p=Path(__file__).resolve().parent
label,typ=sys.argv[1:3]
dirs=[p/'historical',p/('incoming-harness' if label=='incoming' else label)]
names=['wide_no_wrap_simple_many','fit_nesting']
if typ=='all':
 names += [f'grid {n} columns backfill={b}' for n in (12,97,257) for b in ('true','false')]+['free center','free start']
r={}
for i,n in enumerate(names):
    vals=[[],[]]; alloc=[{},{}]
    for lab in ((0,1,1,0) if i%2==0 else (1,0,0,1))*(2 if typ=='all' else 1):
        result=subprocess.check_output(['taskset','-c','6',dirs[lab]/'alloc/target/release/keru-perf',n],text=True)
        m=re.search(r'([\d.]+) ns\s+allocs/bytes cold (\d+)/(\d+) warm (\d+)/(\d+)',result)
        assert m,result
        vals[lab].append(float(m[1]))
        a={'cold_allocations':int(m[2]),'cold_bytes':int(m[3]),'warm_allocations':int(m[4]),'warm_bytes':int(m[5])}
        assert not alloc[lab] or alloc[lab]==a
        alloc[lab]=a
    l,h=[median(v)/1000 for v in vals]
    r[n]={'historical_us':l,'current_us':h,'historical_alloc':alloc[0],'current_alloc':alloc[1]}
    print(f'{n}\t{l:.3f}\t{h:.3f}\t{(h/l-1)*100:+.1f}%\t{list(alloc[0].values())}\t{list(alloc[1].values())}',flush=True)
    (dirs[1]/'alloc.json').write_text(json.dumps(r,indent=2)+'\n')
