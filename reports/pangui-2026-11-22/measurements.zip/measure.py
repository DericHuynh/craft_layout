import json,re,subprocess,sys,os
from pathlib import Path
from statistics import median,geometric_mean
out=Path(__file__).resolve().parent
label,kind=sys.argv[1:3]
p=out/('incoming-harness' if label=='incoming' else label)
cases=sorted(t.stem for t in (p/'criterion/pangui').glob('*.txt'))
targets=['wide_no_wrap_simple_many','fit_nesting']
if kind=='criterion':
    bins=[(p/'criterion-binary','keru_layout'),(p/'criterion-binary','Keru baseline')]
    rows={}
    for case in targets:
        rows[case]={name:[] for _,name in bins}
        for order in [bins,bins[::-1],bins,bins[::-1]]:
            for exe,name in order:
                cmd=['taskset','-c','6',exe,f'^PanGUI/{case}/{name}$','--bench','--sample-size','12','--warm-up-time','0.3','--measurement-time','1.0','--noplot']
                full=subprocess.check_output(cmd,text=True,stderr=subprocess.STDOUT,env={**os.environ,'CRITERION_HOME':str(p/'criterion-results')})
                r=re.search(r'time:\s+\[[\d.]+ ms ([\d.]+) ms',full)
                if not r: raise RuntimeError(full)
                rows[case][name].append(float(r[1]))
        med={k:median(v) for k,v in rows[case].items()}
        print(case,med,'ratio',med['keru_layout']/med['Keru baseline'],rows[case],flush=True)
        (p/'criterion-pairs.json').write_text(json.dumps(rows,indent=2)+'\n')
elif kind=='paired':
    def run(case,mode):
        n=2 if case in targets+['pixels_with_min_expand_constraint'] else 6
        if case=='padding_and_margin':n=1000
        if case=='wide_no_wrap_simple_few':n=400
        pairs=[]
        for a,b in [('before','after'),('after','before')]:
            result=subprocess.check_output(['taskset','-c','6',p/'paired/target/release/paired',case,a,b,str(n),mode],text=True)
            vv=[list(map(float,r.split())) for r in result.splitlines()[2:]]
            assert len(vv)==30
            pairs+=vv if a=='before' else [v[::-1] for v in vv]
        (p/f'{case}-{mode}.tsv').write_text('\n'.join(f'{a}\t{b}' for a,b in pairs)+'\n')
        left,right=[median(v)/1e6 for v in zip(*pairs)]
        ratio=median(b/a for a,b in pairs)
        print(f'{case}\t{mode}\t{left:.4f}\t{right:.4f}\t{100*(ratio-1):+.1f}%',flush=True)
        return ratio
    ratios=[run(case,'warm') for case in targets + [c for c in cases if c not in targets]]
    print('Geometric mean paired change',round((geometric_mean(ratios)-1)*100,1),flush=True)
    for c in targets: run(c,'cold')
