# Full-solve performance recovery

All measurements used the original PanGUI templates and native Keru adapter on logical CPU 6 of an AMD Ryzen 7 5800H. The compiler was stable Rust 1.97.0 with default x86-64 release code generation. Tree construction and template parsing were outside layout timing. Every measured call performed a full solve. The historical source was the saved working tree after the fit-nesting and wide-stack optimizations, immediately before structural-edit support. Incoming was the working tree at the start of this recovery.

## PanGUI Criterion

Each version ran in four separate processes per workload. Runs alternated versions and reversed the pair order. Each run used 12 samples, a 300 ms warm-up, and a one-second measurement target. Each table entry is the median of the four point estimates in milliseconds. The historical source was timed again alongside each comparison.

| Workload | Historical as previously reported | Historical alongside incoming | Incoming | Historical alongside recovery | Recovered | Recovered vs matched historical |
|---|---:|---:|---:|---:|---:|---:|
| wide_no_wrap_simple_many | 2.2238 | 2.2829 | 5.3547 | 2.7088 | 2.6551 | -2.0% |
| fit_nesting | 5.7764 | 6.4079 | 9.3551 | 6.9763 | 6.2706 | -10.1% |

## Paired full solves

The original paired native harness alternated adjacent batches within each process. Two runs reversed engine allocation order and retained 30 pairs each. Times are independent medians in milliseconds. Changes are medians of the 60 within-pair ratios. A cold measurement times the first solve on a freshly constructed tree.

| Workload | State | Historical vs incoming (ms) | Incoming (ms) | Incoming paired change | Historical vs recovery (ms) | Recovered (ms) | Recovered paired change |
|---|---|---:|---:|---:|---:|---:|---:|
| wide_no_wrap_simple_many | warm | 2.7064 | 5.2013 | +91.5% | 2.5175 | 2.6451 | +4.1% |
| fit_nesting | warm | 6.8608 | 9.8000 | +42.2% | 6.4049 | 5.7383 | -10.4% |
| expand_with_max_constraint | warm | 0.2123 | 0.1946 | -8.6% | 0.2135 | 0.1391 | -35.0% |
| expand_with_min_constraint | warm | 0.2113 | 0.1928 | -8.5% | 0.2137 | 0.1387 | -34.8% |
| flex_expand_equal_weights | warm | 1.1546 | 1.0290 | -11.1% | 1.1235 | 0.4098 | -64.3% |
| flex_expand_weights | warm | 1.0046 | 1.0041 | -0.5% | 0.9546 | 0.4465 | -53.9% |
| nested_vertical_stack | warm | 0.5346 | 0.7845 | +47.0% | 0.4971 | 0.1929 | -61.4% |
| padding_and_margin | warm | 0.0052 | 0.0076 | +46.4% | 0.0051 | 0.0023 | -55.5% |
| percentage_and_ratio | warm | 0.6793 | 0.9064 | +32.8% | 0.6635 | 0.2030 | -69.4% |
| perpendicular_expand_with_wrap | warm | 0.8505 | 1.1146 | +30.5% | 0.8286 | 0.7413 | -12.1% |
| pixels_with_min_expand_constraint | warm | 3.5254 | 4.7733 | +33.8% | 2.4682 | 2.4266 | -2.6% |
| wide_no_wrap_simple_few | warm | 0.0092 | 0.0262 | +185.2% | 0.0096 | 0.0086 | -11.5% |
| wide_wrapping | warm | 0.5453 | 0.7202 | +31.6% | 0.5639 | 0.5498 | -1.8% |
| wide_no_wrap_simple_many | cold | 3.1202 | 5.7146 | +82.3% | 3.0552 | 3.2497 | +7.1% |
| fit_nesting | cold | 6.2385 | 8.9326 | +45.2% | 6.2569 | 5.3044 | -16.7% |

The equal-workload geometric mean of the 13 warm paired time ratios was +32.2% for incoming versus historical and -36.8% for recovered versus historical.

## Allocation and placement controls

Times in this independent counting-allocator harness are medians of four process medians, with nine batches per process. Allocation counts include reallocations. Historical and recovered timings shown here were collected together. Cold allocation columns compare historical, incoming and recovered builds.

| Workload | Historical µs | Recovered µs | Time change | Cold allocations, historical / incoming / recovered | Cold requested bytes, historical / incoming / recovered | Recovered warm allocations / bytes |
|---|---:|---:|---:|---:|---:|---:|
| wide_no_wrap_simple_many | 2505.002 | 2584.735 | +3.2% | 0 / 2 / 0 | 0 / 3200736 / 0 | 0 / 0 |
| fit_nesting | 6314.870 | 5342.179 | -15.4% | 0 / 12 / 0 | 0 / 4611168 / 0 | 0 / 0 |
| grid 12 columns backfill=true | 56.600 | 39.866 | -29.6% | 5 / 5 / 5 | 4216 / 4216 / 4216 | 0 / 0 |
| grid 12 columns backfill=false | 24.897 | 9.706 | -61.0% | 3 / 3 / 3 | 224 / 224 / 224 | 0 / 0 |
| grid 97 columns backfill=true | 210.453 | 153.694 | -27.0% | 5 / 5 / 5 | 3472 / 3472 / 3472 | 0 / 0 |
| grid 97 columns backfill=false | 78.367 | 29.994 | -61.7% | 4 / 4 / 4 | 480 / 480 / 480 | 0 / 0 |
| grid 257 columns backfill=true | 194.923 | 128.872 | -33.9% | 5 / 5 / 5 | 3720 / 3720 / 3720 | 0 / 0 |
| grid 257 columns backfill=false | 77.851 | 30.336 | -61.0% | 5 / 5 / 5 | 1240 / 1240 / 1240 | 0 / 0 |
| free center | 118.844 | 116.249 | -2.2% | 0 / 0 / 0 | 0 / 0 / 0 | 0 / 0 |
| free start | 121.613 | 119.374 | -1.8% | 0 / 0 / 0 | 0 / 0 / 0 | 0 / 0 |

## Paired grid and free-placement confirmation

A second control run used both builds in the same process and alternated their order within each pair. Two processes reversed tree allocation order. Each retained 30 pairs of 20 invalidated full solves, for 60 time ratios per workload. The inputs match the allocation controls.

| Workload | Historical µs | Recovered µs | Median paired change |
|---|---:|---:|---:|
| grid 12 columns backfill=true | 55.072 | 40.697 | -26.4% |
| grid 12 columns backfill=false | 24.878 | 9.493 | -61.9% |
| grid 97 columns backfill=true | 212.360 | 157.693 | -25.9% |
| grid 97 columns backfill=false | 77.199 | 30.014 | -60.9% |
| grid 257 columns backfill=true | 196.488 | 131.721 | -33.1% |
| grid 257 columns backfill=false | 78.500 | 30.096 | -61.6% |
| free center | 110.019 | 106.426 | -3.9% |
| free start | 116.525 | 114.734 | +0.1% |

## Full-solve output verification

The original saved digests matched for all 13 PanGUI templates over four full solves per tree, including viewport and unregistered style changes. The same historical checks also matched on 10,000 randomized/weighted layouts, 2,000 mixed-flow trees, 2,400 floating-point placement cases and 6,208 fill solves. [Verification log](recovered/oracle.log)

The final verification also exercises coupled append/remove updates, randomized grid geometry, and registered batches with unknown edit locations. [Structural append/remove checks](structural-checks/checks.tsv) · [30,000 randomized grid frames](grid-oracle/oracle.log) · [86,400 unlocalized structural batches](transitions/final.log)

A separate oracle exercised 12,000 deliberately extreme three-frame trees. Every finite coordinate bit pattern, logical slot value, dependency level and warning sequence matched. On 31 trees, the sign bit of an output coordinate that was already NaN changed. [Floating-point oracle](float-oracle/run.log)


## Target workload engine comparison

The 12-sample PanGUI Criterion measurements compared the current checkout, the saved pre-structural Keru source, and all 11 registered peer configurations, including Taffy 0.3. The unchanged peer and pre-structural rows come from the preceding run. The current Keru row was refreshed after the wrapping optimization. Both templates and each adapter’s native layout semantics were preserved. Clay and Ply include declaration and render-command generation. Ply cannot represent the wide workload with 100,000 siblings. Values are arithmetic mean milliseconds per full solve.

| Implementation | fit_nesting | wide_no_wrap_simple_many |
|---|---:|---:|
| keru_layout | 5.8989 | 2.6901 |
| Keru baseline | 7.5273 | 2.9085 |
| Cephal | 13.1610 | 14.4746 |
| Backer | 16.2120 | 17.7233 |
| hooke | 23.8767 | 16.1536 |
| Torin | 28.6531 | 17.0716 |
| Clay | 29.0360 | 20.7980 |
| Taffy main | 45.8043 | 51.2855 |
| Ply | 46.1609 | Unsupported |
| Morphorm | 78.4727 | 10.0512 |
| ui_layout | 102.9894 | 65.9110 |
| Yoga | 127.8167 | 58.5591 |
| Taffy 0.3 | 180.2040 | 35.2814 |

## Measurement files

[Original incoming Criterion point estimates](incoming-harness/criterion-pairs.json) · [Recovered Criterion point estimates](recovered/criterion-pairs.json) · [Incoming paired summary](incoming-harness/paired.log) · [Recovered paired summary](recovered/paired.log) · [Incoming allocation counts](incoming-harness/alloc.json) · [Recovered allocation counts](recovered/alloc.json) · [Target peer Criterion run](recovered/peers.log)

The final current-Keru entries in the target peer comparison were timed again in the all-feature executable. [Final target peer log](recovered/peers-candidate.log)


## Complete 162-entry engine matrix

The full Criterion matrix includes all supported workloads for all 11 peer configurations, the published Keru 0.1.0 adapter, the pre-structural workspace snapshot, and the recovered solver. [All engine comparisons](all-engines/matrix.md) · [Means and confidence intervals](all-engines/timings.tsv)

